Image Dimensions are 640 x 448
palette data is a 256bit palette, 32bits per colour (rgba?) (256 x 4 = 1024bytes)
image data is 8bits per pixel (640 x 448 = 286720bytes)

includes files

texture_sample1.vpt	= file from game (texture container)
texture_sample1.tga	= image harvested from PCSX2 should be what the destination file should be
texture_sample1.pal	= palette data extracted from .vpt
texture_sample1.img	= image data extracted from .vpt
vpt_imp.ms		= maxscript i wrote to read the .vpt