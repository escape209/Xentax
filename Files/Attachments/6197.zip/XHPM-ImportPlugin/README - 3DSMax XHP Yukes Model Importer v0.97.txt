[3DS Max XHP Yukes Model Import plug-in v0.97]
==========================================================================
(c)2013 Brien L. Johnson (xhpcreations@att.net) http:///www.xhpcreations.com

Special thanks to chrrox for help on the model format


[Info]
======

This plug-in allows you to import Xbox 360 Yukes format model files in to 3DS Max.

[Supported versions]
====================

3DS Max 9 - 32/64bit (untested)
3DS Max 2010 - 32/64bit
3DS Max 2011 - 32/64bit

[Features]
==========

* All vertices, normals, and vertex colors imported
* Complete texture map UVs imported
* Complete skeleton imported
* All weights imported


[Installation]
==============

For 32-bit, copy the XHPMImport.dli into your 3DS Max plugins folder.
For 64-bit, copy the XHPMImport.dli into your 3DS Max plugins folder.

Once installed, you should find "XHPM Model File" as an import option from the file menu.
.YOBJ, .YMX, and a future .XHPM extensions supported.

[Instructions and Stuff]
========================

After selecting the import menu item in Max, select any .yobj or .ymx file in a folder.

Note: UFC .ymx models are compressed, you must first decompress them

A selection prompt will then come up, asking if you want to open every model file in the folder.

If you select yes, every .yobj or .ymx (depends on what you initially select) model will load that is in the folder.


[Known Bugs]
============

* None known at this time.

[Changes]
=========

0.97    * First official release.

0.10    * Initial beta release

[To Do]
=======

* Make at least a 2012 and 2013 version plugin, and hopefully also a 2008 and 2009 version.
* Add Materials.


License/Disclaimer
==================
This software is provided 'as-is', without any express or implied warranty. In no
event will the author be held liable for any damages arising from the use of this
software.

Permission is granted to anyone to use this software, subject to the following
restrictions:

1. The origin of this software must NOT be misrepresented; you must not claim that
   you wrote the original software.

2. This software is for PERSONAL USE ONLY and may not be used commercially or for
   any commercial application without prior permission.

3. This software may NOT be bundled with any other product, included in any
   compilation or made available from any internet site without the express
   permission of the author.

4. This notice must NOT be removed or altered from any distribution of this
   software.