

Lords of Midnight Wrapper v0.2
-============================-
2011, XeNTaX Foundation, http://www.xentax.com
Code and Music (sid) by Mr.Mouse

This is a Wrapper for CCS64 v3.8
To use: Start the game in CCS64, and then run Lomwrapper.exe


Manual:

Load/Save state: From the File menu you can save and then load the state of the game. Make sure you first load up the game when you start again in CCS64, before you load a saved state. 

The minimap can be sized up and down by the Size button in the Map Settings window. You can toggle between Area (domains) and Terrain view. Click to highlight lords, structures or nothing on the map in the Settings window. 

Use all other windows for your intelligence operations while playing the game ;-)

NOTE: Map updates only occur when pressing 0 or Y in CCS64, or when pressing Area or Terrain in the Map Settings window. 

AS you go, turns are saved. If you save the state, and reload it, you will also be able to Replay the game. 
You can even save the logs of eacht turn for further study. Just select the Replay->Tools option, or click Replay in the Map Info window. 

