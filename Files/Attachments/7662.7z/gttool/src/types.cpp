#include "types.h"
#include "util.h"

String* String::parse(const void* buffer)
{
	if (!buffer)
		return nullptr;

	length = extract_value_and_advance(&buffer);
	data = static_cast<const char*>(buffer);

	return this;
}

FileId* FileId::parse(const void* buffer)
{
	if (!buffer)
		return nullptr;

	flag = data_at<uint8_t>(buffer, 0);
	buffer = advance_pointer(buffer, 1);
	name_index = extract_value_and_advance(&buffer);
	extension_index = (flag & kFILE_FLAG) != 0 ? extract_value_and_advance(&buffer) : 0;
	entry_index = extract_value_and_advance(&buffer);

	return this;
}

FileInfo* FileInfo::parse(const void* buffer)
{
	if (!buffer)
		return nullptr;

	flag = data_at<uint8_t>(buffer, 0);
	buffer = advance_pointer(buffer, 1);
	entry_index = extract_value_and_advance(&buffer);
	size1 = extract_value_and_advance(&buffer);
	size2 = (flag & kFLAG) != 0 ? extract_value_and_advance(&buffer) : size1;
	segment_index = extract_value_and_advance(&buffer);

	return this;
}
