#pragma once

#include <cassert>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <inttypes.h>

#include <algorithm>
#include <exception>
#include <memory>
#include <type_traits>
#include <vector>

#define FZ_LITTLE_ENDIAN 0
#define FZ_BIG_ENDIAN 0

#ifdef FZ_LITTLE_ENDIAN
	#undef FZ_LITTLE_ENDIAN
	#define FZ_LITTLE_ENDIAN 1
#endif

#define FL_COUNT_OF(x) (sizeof(x) / sizeof(x[0]))

enum class Endianness
{
	kUNDEFINED,
	kLITTLE,
	kBIG,
	kNETWORK = kBIG,

	#if FZ_LITTLE_ENDIAN
		kHOST = kLITTLE
	#elif FZ_BIG_ENDIAN
		kHOST = kBIG
	#else
		#error Unknown system endianness
	#endif
};
