#pragma once

#include "common.h"
#include "util.h"

template<typename T>
inline T data_at(const void* const ptr, const intptr_t offset)
{
	const T* data = reinterpret_cast<const T*>(static_cast<const char*>(ptr) + offset);
	return swap_bytes<T>(*data);
}

inline uint16_t extract_twelve_bits(const void* ptr, const uint32_t offset)
{
	uint16_t result = data_at<uint16_t>(ptr, (offset * 16 - offset * 4) / 8);
	if ((offset & 0x1) == 0)
		result /= 16;
	return result & 0xFFF;
}

uint32_t extract_value_and_advance(const void** const ptr);

struct String
{
	uint32_t length;
	const char* data;

	String* parse(const void* buffer);
};

struct FileId
{
	static const uint32_t kDIRECTORY_FLAG = (1u << 0);
	static const uint32_t kFILE_FLAG = (1u << 1);

	uint32_t flag;
	uint32_t name_index;
	uint32_t extension_index;
	uint32_t entry_index;

	FileId* parse(const void* buffer);
};

struct FileInfo
{
	static const uint32_t kFLAG = (1u << 0);
	
	//static const uint32_t kCOMPRESSION_FLAG1 = (1u << 4);
	//static const uint32_t kCOMPRESSION_FLAG2 = (1u << 5);

	uint32_t flag;
	uint32_t entry_index;
	uint32_t size1;
	uint32_t size2;
	uint32_t segment_index;
	
	FileInfo* parse(const void* buffer);
};
