#pragma once

#include "common.h"
#include "packed_file.h"

enum class GameID
{
	UNKNOWN,
	GT5,
	GT6,
};

extern const uint32_t kGT5_VOLUME_KEY[];
extern const uint32_t kGT6_VOLUME_KEY[];

extern const char kGT5_VOLUME_SEED[];
extern const char kGT6_VOLUME_SEED[];

struct KeyContext
{
	char seed[32];
	uint32_t key[4];
};

class Volume
{
public:
	Volume();
	explicit Volume(const char* const path, const GameID game_id);
	~Volume();

	bool open(const char* const path, const GameID game_id);
	void close();

	bool extract(const char* const output_dir);

private:
	std::unique_ptr<PackedFile> packed_file_;
	GameID game_id_;
};

void crypt_header(void* const data, const uint32_t size);
void crypt_segment(void* const data, const uint32_t size, const uint32_t index);
