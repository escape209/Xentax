#pragma once

#include "common.h"

struct String;
struct FileId;
struct FileInfo;

class PackedFile
{
public:
	static const uint32_t kMAGIC = 0x5B74516Eu;

	static const size_t kHEADER_SIZE = 0x14;
	static const size_t kSEGMENT_SIZE = 0x800;

	PackedFile(const char* const file_path, const void* const data, const uint32_t data_size, const uint32_t segment_size);
	~PackedFile();

	void extract_entries(const char* const output_dir);

	bool get_file_info(const char* const file_path, FileInfo* const file_info) const;

	inline uint32_t name_table_offset() const
	{
		return name_table_offset_;
	}

	inline uint32_t extension_table_offset() const
	{
		return extension_table_offset_;
	}

	inline uint32_t file_info_table_offset() const
	{
		return file_info_table_offset_;
	}

	uint32_t file_id_table_offset(const uint32_t index) const;

	inline uint32_t num_file_id_trees() const
	{
		return num_file_id_trees_;
	}

	uint64_t data_offset() const;

	inline const void* file_data() const
	{
		return file_data_;
	}

	inline const char* file_path() const
	{
		return file_path_;
	}

private:
	const char* file_path_;
	char* file_data_;

	uint32_t segment_size_;
	uint32_t name_table_offset_;
	uint32_t extension_table_offset_;
	uint32_t file_info_table_offset_;
	uint32_t num_file_id_trees_;
};
