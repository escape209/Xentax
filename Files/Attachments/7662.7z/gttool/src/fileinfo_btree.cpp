#include "fileinfo_btree.h"

int FileInfoBTree::key_equal_op(const Key* const key, const void* const data)
{
	const void* ptr = advance_pointer(data, 1);
	const uint32_t entry_index = extract_value_and_advance(&ptr);
	if (key->entry_index < entry_index)
		return -1;
	else if (key->entry_index > entry_index)
		return 1;
	return 0;
}

int FileInfoBTree::key_less_than_op(const Key* const key, const void* const data)
{
	const void* ptr = data;
	const uint32_t entry_index = extract_value_and_advance(&ptr);
	if (key->entry_index < entry_index)
		return -1;
	else
		return 1;
}

const void* FileInfoBTree::skip_node_data(const void* const node) const
{
	return node;
}

int FileInfoBTree::traverse_callback(const void* const data, void* const arg)
{
	const TraverseCallbackArgs<TraverseFileInfoCallback>* const args = static_cast<const TraverseCallbackArgs<TraverseFileInfoCallback>*>(arg);

	int action = kTRAVERSE_CONTINUE;

	FileInfo file_info;
	if (file_info.parse(data) && args->callback)
		action = (*args->callback)(&file_info, args->arg);

	return action;
}
