#pragma once

#include "btree.h"

class FileIdBTree
	: public BTreeBase
{
public:
	typedef int TraverseFileIdCallback(const FileId* const file_id, void* const arg);

	struct Key
	{
		inline Key()
			: name_index(kINVALID_INDEX)
			, extension_index(kINVALID_INDEX)
		{
		}

		inline Key(const uint32_t name_index, const uint32_t extension_index)
			: name_index(name_index)
			, extension_index(extension_index)
		{
		}

		uint32_t name_index;
		uint32_t extension_index;
	};

	inline FileIdBTree(const void* const table_data)
		: BTreeBase(table_data, key_comparsion_op(&key_less_than_op), key_comparsion_op(&key_equal_op))
	{
	}

	inline ~FileIdBTree()
	{
	}

	inline bool search_by_index(const uint32_t index, FileId* file_id) const
	{
		const void* const data = BTreeBase::search(index);
		if (!data)
			return false;
		return file_id->parse(data) != nullptr;
	}

	inline const void* search(const uint32_t name_index, const uint32_t extension_index, uint32_t* const index = nullptr) const
	{
		return BTreeBase::search(&Key(name_index, extension_index), index);
	}

	inline void traverse(TraverseFileIdCallback* const callback, void* const arg) const
	{
		TraverseCallbackArgs<TraverseFileIdCallback> args(callback, arg);
		BTreeBase::traverse(traverse_callback, &args);
	}

protected:
	virtual const void* skip_node_data(const void* const node) const;
	
private:
	static int key_equal_op(const Key* const key, const void* const data);
	static int key_less_than_op(const Key* const key, const void* const data);

	static int traverse_callback(const void* const data, void* const arg);
};
