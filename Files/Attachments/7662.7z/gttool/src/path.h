#include "common.h"

char* generate_file_path(const uint32_t id, char* const path, const uint32_t max_length);

bool file_exists(const char* const path);
bool directory_exists(const char* const path);

bool make_directory(const char* const path);
bool make_directories(const char* const path);

const char* path_get_delimeter(const char* const path);
const char* path_skip_delimeter(const char* const path);
