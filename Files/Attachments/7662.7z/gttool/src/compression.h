#pragma once

#include "common.h"

int inflate(const void* const in, const size_t in_size, void* const out, size_t* const out_size, int window_bits = 15);
int deflate(const void* const in, const size_t in_size, void* const out, size_t* const out_size, int window_bits = 15, int level = -1);