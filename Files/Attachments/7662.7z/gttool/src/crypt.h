#pragma once

#include "common.h"

bool block_crypt(const void* const src, void* const dst, const size_t size);

void data_keygen(const char* seed, const uint32_t* const key, const uint32_t x, uint32_t* const out_key);
void data_crypt(const uint32_t* key, const void* const src, void* const dst, const size_t size);