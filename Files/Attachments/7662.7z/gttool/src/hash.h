#include "common.h"

extern const uint32_t kCRC32_TAB_0x04C11DB7[];
extern const uint32_t kCRC32_TAB_0x77073096[];

uint32_t crc32_0x04c11db7(const uint32_t initial, const void* const data, const size_t size);
uint32_t crc32_0x77073096(const uint32_t initial, const void* const data, const size_t size);
