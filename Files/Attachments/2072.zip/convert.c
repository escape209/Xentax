/*
  Converter from the format used by Karl Morton's sound system (Psycho
  Pinball, Micro Machines II and probably other games too) to
  4-channel MOD by Patai Gergely.  Feel free to do whatever you want
  with this code.

  The format took a little while to figure out (zero documentation,
  you know), and I'm still not sure what all the effects
  do--fortunately all the ones used in the two games above are
  supported, and actually even more that I managed to identify by
  experimenting a bit.  Another stroke of luck is that the effects are
  100% compatible with traditional MOD effects, so an ordinary player
  can reproduce the songs perfectly after conversion (there are some
  special cases where conversion just isn't possible, as this format
  allows 8-bit parameters for certain effects where only 4 bits are
  available in MODs, but they are unlikely to occur in real life).
  0x14 is the null effect, so most likely values higher than that
  cannot possibly occur at all.

  Also, there are no patterns in the input format, so this program
  tries to reconstruct the order list assuming 64-line patterns and
  removing the duplicates, which will obviously not work if the
  original is built on, say, 48-line units.  It would be possible to
  add some heuristics to distinguish these, but it might not be worth
  the effort in the end.

  Usage: just pass the .mus file as a parameter. You'll get all the
  songs in separate .mod files in the same directory.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

int repetitions = 0;

typedef struct chunk_t {
  uint8_t tag[5];
  int size;
  uint8_t *data;
  struct chunk_t *next;
} chunk_t;

typedef struct sample_t {
  uint8_t name[33];
  int size;
  int lbeg, lend;
  int8_t *data;
  struct sample_t *next;
} sample_t;

typedef struct song_t {
  uint8_t title[33];
  struct {
    sample_t *info;
    int8_t fine;
    uint8_t volume;
  } samples[31];
  int cnum;
  int loop;
  int psize;
  uint8_t *pdata;
  struct song_t *next;
} song_t;

struct {
  chunk_t *first;
  chunk_t *cur;
} chunks = {NULL, NULL};

struct {
  sample_t *first;
  sample_t *cur;
} samples = {NULL, NULL};

struct {
  song_t *first;
  song_t *cur;
} songs = {NULL, NULL};

struct {
  int len, rlen;
  uint8_t *dat;
} songbuf = {0, 0, NULL};

void songbuf_init() {
  if (songbuf.dat) free(songbuf.dat);
  songbuf.len = 0;
  songbuf.rlen = 0x10000;
  songbuf.dat = malloc(0x10000);
}

void songbuf_append(uint8_t *dat, int len) {
  if (len + songbuf.len >= songbuf.rlen) {
    uint8_t *tmp = malloc(songbuf.rlen << 1);
    memcpy(tmp, songbuf.dat, songbuf.len);
    free(songbuf.dat);
    songbuf.dat = tmp;
    songbuf.rlen <<= 1;
  }
  memcpy(songbuf.dat + songbuf.len, dat, len);
  songbuf.len += len;
}

void read_chunk(FILE *fp) {
  uint8_t buf[4];

  if (!chunks.first) {
    chunks.first = chunks.cur = malloc(sizeof(chunk_t));
  }

  chunks.cur->tag[4] = 0;
  if (0 >= fread(&chunks.cur->tag, 4, 1, fp)) return;
  fread(&buf, 4, 1, fp);
  chunks.cur->size = (buf[0] + (buf[1] << 8) + (buf[2] << 16) + (buf[3] << 24)) - 8;
  chunks.cur->data = malloc(chunks.cur->size);
  fread(chunks.cur->data, chunks.cur->size, 1, fp);

  chunks.cur->next = malloc(sizeof(chunk_t));
  chunks.cur = chunks.cur->next;
  chunks.cur->next = NULL;
}

sample_t *find_sample(const uint8_t *name) {
  sample_t *sp;

  for (sp = samples.first; sp->next != NULL; sp = sp->next) {
    if (!strncmp(name, sp->name, 32)) return sp;
  }

  return NULL;
}

void process_sample_chunk(chunk_t *c) {
  if (strcmp("SMPL", c->tag)) return;

  if (!samples.first) {
    samples.first = samples.cur = malloc(sizeof(sample_t));
  }

  memcpy(&samples.cur->name, c->data, 32);
  samples.cur->name[32] = 0;
  samples.cur->size = c->size - 40;
  samples.cur->lbeg = c->data[32] + (c->data[33] << 8) + (c->data[34] << 16) + (c->data[35] << 24);
  samples.cur->lend = c->data[36] + (c->data[37] << 8) + (c->data[38] << 16) + (c->data[39] << 24);
  samples.cur->data = c->data + 40;

  samples.cur->next = malloc(sizeof(sample_t));
  samples.cur = samples.cur->next;
  samples.cur->next = NULL;
}

void song_init() {
  songbuf_init();
}

void generate_song_line(uint8_t *line) {
  uint8_t mline[16];
  int chn;

  /*
  static const char *nn[12] = {"C-", "C#", "D-", "D#", "E-", "F-", "F#", "G-", "G#", "A-", "A#", "B-"};

  for (chn = 0; chn < 4; chn++) {
    uint8_t *nd = line + (chn << 2);
    if (nd[0] && nd[1]) {
      printf("%s%d %02d", nn[(nd[0] - 1) % 12], (nd[0] - 1) / 12 + 1, nd[1] % 100);
    } else {
      printf("--- --");
    }
    if (nd[2] == 0x14) {
      printf(" --- ");
    } else {
      printf(" %c%02X ", nd[2] + 'A', nd[3]);
    }
    printf(chn == 3 ? "\n" : "| ");
  }
  */

  for (chn = 0; chn < 4; chn++) {
    static const uint16_t periods[37] = {
      0,
      856, 808, 762, 720, 678, 640, 604, 570, 538, 508, 480, 453,
      428, 404, 381, 360, 339, 320, 302, 285, 269, 254, 240, 226,
      214, 202, 190, 180, 170, 160, 151, 143, 135, 127, 120, 113
    };

    uint8_t *note = line + (chn << 2);
    uint8_t *mnote = mline + (chn << 2);

    mnote[0] = (note[1] & 0xf0) | (periods[note[0]] >> 8);
    mnote[1] = periods[note[0]];
    mnote[2] = note[1] << 4;
    mnote[3] = note[3];

    switch(note[2]) {
    case 0x00: // set volume
      mnote[2] |= 0x0c;
      break;
    case 0x03: // fine portamento up
      mnote[2] |= 0x0e;
      mnote[3] = 0x10 | (note[3] & 0xf);
      break;
    case 0x04: // fine portamento down
      mnote[2] |= 0x0e;
      mnote[3] = 0x20 | (note[3] & 0xf);
      break;
    case 0x06: // sample offset
      mnote[2] |= 0x09;
      break;
    case 0x09: // vibrato (speed + amplitude)
      mnote[2] |= 0x04;
      break;
    case 0x0a: // vibrato with volume slide (not used anywhere?)
      mnote[2] |= 0x06;
      break;
    case 0x0b: // arpeggio (only used a bit in Psycho Pinball, Abyss level)
      // note: the default zeroes the parameter!
      break;
    case 0x0c: // portamento up
      mnote[2] |= 0x01;
      break;
    case 0x0d: // portamento down
      mnote[2] |= 0x02;
      break;
    case 0x0e: // volume slide up/down
      mnote[2] |= 0x0a;
      break;
    case 0x10: // retrigger (cut if >=tempo)
      mnote[2] |= 0x0e;
      mnote[3] = 0x90 | (note[3] & 0xf);
      break;
    case 0x11: // cut (nothing if >=tempo)
      mnote[2] |= 0x0e;
      mnote[3] = 0xc0 | (note[3] & 0xf);
      break;
    case 0x12: // set tempo/bpm
      mnote[2] |= 0x0f;
      break;
    default: // nothing
      mnote[3] = 0;
    }
  }

  // Saving the converted line
  songbuf_append(mline, sizeof(mline));
}

void process_song_chunk(chunk_t *c, char *musfile) {
  if (strcmp("SONG", c->tag)) return;

  if (!songs.first) {
    songs.first = songs.cur = malloc(sizeof(song_t));
  }

  static char zs[30] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
  };
  int i, j;

  memcpy(&songs.cur->title, c->data, 32);
  songs.cur->title[32] = 0;

  int mfl = strlen(musfile);
  char fname[mfl + 34];
  strcpy(fname, musfile);
  sprintf(fname + mfl - 4, "_%s.mod", songs.cur->title);
  FILE *mfp = fopen(fname, "wb");

  char mtitle[21];
  strncpy(mtitle, songs.cur->title, 20);
  fwrite(mtitle, 1, 20, mfp);

  // Sample information
  for (i = 0; i < 31; i++) {
    songs.cur->samples[i].info = find_sample(c->data + 32 + i * 34);
    songs.cur->samples[i].fine = c->data[64 + i * 34] < 8 ? c->data[64 + i * 34] : c->data[64 + i * 34] - 16;
    songs.cur->samples[i].volume = c->data[65 + i * 34];

    sample_t *sinfo = songs.cur->samples[i].info;
    if (sinfo == NULL) {
      fwrite(zs, 1, 30, mfp);      
    } else {
      char sname[23];
      strncpy(sname, sinfo->name, 22);
      fwrite(sname, 1, 22, mfp);
      fputc(sinfo->size >> 9, mfp);
      fputc(sinfo->size >> 1, mfp);
      fputc(songs.cur->samples[i].fine & 0xf, mfp);
      fputc(songs.cur->samples[i].volume, mfp);
      fputc(sinfo->lbeg >> 9, mfp);
      fputc(sinfo->lbeg >> 1, mfp);
      fputc((sinfo->lend - sinfo->lbeg) >> 9, mfp);
      fputc((sinfo->lend - sinfo->lbeg) >> 1, mfp);
    }
  }

  /*
    1086-1087: pad to 4 bytes (always two zeroes)
  */

  songs.cur->cnum = c->data[1088] + (c->data[1089] << 8) + (c->data[1090] << 16) + (c->data[1091] << 24);
  songs.cur->loop = c->data[1092] + (c->data[1093] << 8) + (c->data[1094] << 16) + (c->data[1095] << 24);
  songs.cur->psize = c->data[1096] + (c->data[1097] << 8) + (c->data[1098] << 16) + (c->data[1099] << 24);
  songs.cur->pdata = c->data + 1100;

  uint8_t ccnt[4] = {0, 0, 0, 0};
  uint8_t lpos = 0;
  uint8_t *pdat = songs.cur->pdata;
  uint8_t line[16];
  uint32_t iend = 0;
  song_init();

  for (i = 0; i < 16; i++) {
    line[i] = (i & 3) == 2 ? 0x14 : 0x00;
  }

  // Uncompress notes and convert them to MOD patterns
  for (;;) {
    // Replicate note data from the previous line
    while (ccnt[lpos]) {
      ccnt[lpos]--;
      if (lpos == songs.cur->cnum - 1) generate_song_line(line);
      lpos = (lpos + 1) % songs.cur->cnum;
    }

    // End of compressed song data
    if (pdat >= songs.cur->pdata + songs.cur->psize) break;

    // End of non-looping intro part
    if ((songs.cur->loop > 0) && (pdat - songs.cur->pdata == songs.cur->loop)) {
      // Add jump command to the last line and pad the pattern to 64 rows
      if (songbuf.len & 0x3ff) {
	int chn;
	for (chn = 0; chn < 4; chn++) {
	  uint8_t *epos = songbuf.dat + (songbuf.len - 14 + (chn << 2));
	  if ((epos[0] & 0x0f) == 0) {
	    epos[0] |= 0x0d;
	    epos[1] = 0x00;
	    break;
	  }
	}
	while (songbuf.len & 0x3ff) {
	  songbuf_append(zs, 16);
	}
      }
      iend = songbuf.len >> 10;
    }

    // Initialise replication counter for the current channel
    if (*pdat & 0x80) {
      ccnt[lpos] = *pdat - 0x7f;
      pdat++;
      continue;
    }

    // Decompress a single note
    line[(lpos << 2) + 0] = (*pdat++) & 0x7f;
    line[(lpos << 2) + 1] = *pdat & 0x7f;
    if (!(*pdat++ & 0x80)) {
      line[(lpos << 2) + 2] = *pdat++;
      line[(lpos << 2) + 3] = *pdat++;
    }

    // Output a MOD pattern line when applicable
    if (lpos == songs.cur->cnum - 1) generate_song_line(line);
    lpos = (lpos + 1) % songs.cur->cnum;
  }

  // Add loop command or pattern break to the end if necessary
  int chn;
  for (chn = 0; chn < 4; chn++) {
    uint8_t *epos = songbuf.dat + (songbuf.len - 14 + (chn << 2));
    if ((epos[0] & 0x0f) == 0) {
      if ((repetitions == 0) && (iend != 0)) {
	epos[0] |= 0x0b;
	epos[1] = iend;
      } else {
	epos[0] |= 0x0d;
	epos[1] = 0;
      }
      break;
    }
  }

  // Pad the last pattern to 64 rows
  while (songbuf.len & 0x3ff) {
    songbuf_append(zs, 16);
  }

  // Create order list by merging identical patterns
  uint8_t ord[128], olen = songbuf.len >> 10;
  uint8_t pats = 1;
  uint8_t npats[songbuf.len];
  memcpy(npats, songbuf.dat, 1024);
  ord[0] = 0;

  for (i = 1; i < olen; i++) {
    for (j = 0; j < pats; j++) {
      if (!memcmp(npats + (j << 10), songbuf.dat + (i << 10), 0x400)) {
	break;
      }
    }
    ord[i] = j;
    if (j == pats) {
      memcpy(npats + (j << 10), songbuf.dat + (i << 10), 1024);
      pats++;
    }
  }

  int replen = i - iend;

  for (; i < 128; i++) {
    ord[i] = (repetitions > 0) ? ord[i - replen] : 0;
  }

  if (repetitions > 0) {
    olen += (repetitions - 1) * replen;
    if (olen > 128) olen = 128;
  }

  fputc(olen, mfp);
  fputc(0x7f, mfp);

  for (i = 0; i < 128; i++) {
    fputc(ord[i], mfp);
  }

  fputc('M', mfp);
  fputc('.', mfp);
  fputc('K', mfp);
  fputc('.', mfp);

  // Patterns
  fwrite(npats, 1, pats << 10, mfp);

  // Samples
  for (i = 0; i < 31; i++) {
    sample_t *sinfo = songs.cur->samples[i].info;
    if (sinfo != NULL) {
      fwrite(sinfo->data, 1, sinfo->size & ~1, mfp);
    }
  }

  fclose(mfp);

  songs.cur->next = malloc(sizeof(song_t));
  songs.cur = songs.cur->next;
  songs.cur->next = NULL;
}

int main(int argc, char **argv) {
  char *musfile = "title.mus";

  if (argc > 1) {
    musfile = argv[1];
  }

  if (argc > 2) {
    repetitions = atoi(argv[2]);
  }
  
  FILE *fp = fopen(musfile, "rb");
  if (!fp) return 1;

  while (!feof(fp)) {
    read_chunk(fp);
  }

  fclose(fp);

  chunk_t *cp;
  for (cp = chunks.first; cp->next != NULL; cp = cp->next) {
    process_sample_chunk(cp);
  }
  for (cp = chunks.first; cp->next != NULL; cp = cp->next) {
    process_song_chunk(cp, musfile);
  }

  return 0;
}
