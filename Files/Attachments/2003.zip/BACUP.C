//FASTSCAN
#include "system.h"
#include <dir.h>
#include <stdlib.h>
#include <process.h>

typedef 		unsigned char BYTE;
typedef			const BYTE * DirNameType1;
typedef			struct {
				int   Length;
				int   ParentDir;
				int   StSub;
				int   EnSub;
				BYTE  Name[MAXDIR];
			       } 	TreeType;
typedef			struct {
				int Start;
				int End;
			       } 	SubListType;
typedef			struct {
				char WinNum;
				char DriveNum;
				int  UnitLn;
				int  UnitMaxX;
				int  UnitMaxY;
				int  MaxUnits;
				void *MaxL;
				int  CursorX;
				int  CursorY;
				int  CurWinUnit;
				int  CurBufUnit;
				int  FileToWinNum;
				}	TABtype;


TABtype		TAB[4];
TreeType	CurTree;
SubListType     TmpSubList;
char 		TABCnt;
char 		TABS, TABE;
char	       *argv[1];
int 		argc;
char		Xit;
BYTE 		ch;
BYTE 	       *ErrMess[20];
BYTE		TreeBuf[64000];
BYTE 		Abort=0;
BYTE	       *RootDirT="xxxxxxxxx";
BYTE		RootDirA[MAXDIR];
BYTE		RootDirMain[MAXDIR];
BYTE		SaveTreeFile;
BYTE	       *FileFile="xxxxxxxxx";
BYTE	       *TreeFile="xxxxxxxxx";
BYTE	       *String="xxxxxxxxx";
//BYTE	       *DirBuf[30];
int 		DirCnt;
int 		DirS;
int 		DirE;
int 		CXWidth, XLength, CYWidth;
int 		FileSpaceX;
int 		FileSpaceY;
int 		DirSpaceY;
int		CurWinFPosX;
int		CurWinFPosY;
int		CurWinDPosX;
int		CurWinDPosY;
int 		CurWinFCnt;
int 		CurWinDCnt;
int 		CtFileCnt;
int 		CtDirCnt;
int 		FileCnt;
int 		BufPos=-1;
int		CurAlloc;
int 		DirNum;
int 		CurDirNum;
struct          WindowBound {int x1; int y1; int x2; int y2;} WinBound[5];

//========================================================
int Init(void);
//========================================================
int GetTree(BYTE RootDir[MAXDIR], int Action);
//========================================================
int GetRoot(int Num);
//========================================================
void FillInDir(BYTE Fill[MAXDIR], int Action);
//========================================================
void SaveTree(const char * TreeFile);
//========================================================
void UserRequest(void);
//========================================================
void Terminate(int Error);
//========================================================
void OSGODScreenUp(void);
//========================================================
void TextRectangle(int x1, int y1, int x2, int y2, int Color);
//========================================================
void GetFiles(int CurDirNum);
//========================================================
void FilesToWindow(int WNum, int StrtFile);
//========================================================
BYTE *RetrieveFile(int FNum);
//========================================================
void ClearWindow(int WNum, int Color);
//========================================================
void GetDirs(int DNum);
//========================================================
BYTE *RetrieveDir(int DNum);
//========================================================
void KeyInterface(void);
//========================================================
void ScreenInit();
//========================================================
void ResetTab(char TABCnt);
//========================================================
void MoveCursor(char Dire);
//========================================================
void ExecStuff(void);
//========================================================
void ResetCursor(int TABCnt);
//========================================================
void UnLightSel(int TABCnt);
//========================================================
void LightSel(int TABCnt);
//========================================================


//********************************************************
int Init(void)
//********************************************************
{
 char M;
 FILE *DUM;
 int WNum;
 ErrMess[0]="Now way I am going to find that Root directory! Retype it!";
 ErrMess[1]="Unable to create DUM.FSC";
 ErrMess[2]="Unable to allocate memory for TreeBuf";
 ErrMess[3]="Unable to reallocate memory for TreeBuf";
 ErrMess[4]="Unable to change directory";
 ErrMess[5]="Frankly, the program shouldn't have reached this far!";
 ErrMess[6]="Unable to create TreeFile";
 ErrMess[7]="Unable to write to TreeFile";
 ErrMess[8]="Unable to create TEMPFILE.FSC";
 ErrMess[9]="Unable to throw files to window";
 ErrMess[10]="Unable to open TEMPFILE.FSC";

 OSGODScreenUp();
 strcpy(RootDirMain, "c:\\");
 TreeFile="c:\\temptree.fsc";
 FileFile="c:\\tempfile.fsc";
 if (chdir(RootDirMain)) 			Terminate(0);
 if ((DUM= fopen("DUM.FSC", "w+")) == NULL) 	Terminate(1);
 fclose(DUM);
 RootDirT = searchpath("DUM.FSC");
 M=8;
 if (strlen(RootDirT)==10) {M=7;};
 strncpy(RootDirA, RootDirT, strlen(RootDirT)-M);
 RootDirA[strlen(RootDirT)-M]='\0';

 SaveTreeFile=1;
 TABCnt=0; TABS=0; TABE=1;
 WNum=2;
 TAB[0].WinNum=2;
 TAB[0].UnitLn=12;
 TAB[0].UnitMaxX=(WinBound[WNum].x2-WinBound[WNum].x1)/13;
 TAB[0].UnitMaxY=(WinBound[WNum].y2-WinBound[WNum].y1);
 TAB[0].MaxUnits=TAB[0].UnitMaxX*TAB[0].UnitMaxY;
 TAB[0].CursorX=WinBound[WNum].x1;
 TAB[0].CursorY=WinBound[WNum].y1;
 TAB[0].CurWinUnit=1;
 TAB[0].CurBufUnit=1;
 TAB[0].MaxL = &FileCnt;
 TAB[0].FileToWinNum=2;
 DirCnt=0;

 WNum=3;
 TAB[1].WinNum=3;
 TAB[1].UnitLn=8;
 TAB[1].UnitMaxX=1;//(WinBound[WNum].x2-WinBound[WNum].x1)/8;
 TAB[1].UnitMaxY=(WinBound[WNum].y2-WinBound[WNum].y1)+1;
 TAB[1].MaxUnits=TAB[1].UnitMaxX*TAB[1].UnitMaxY;
 TAB[1].CursorX=WinBound[WNum].x1;
 TAB[1].CursorY=WinBound[WNum].y1;
 TAB[1].CurWinUnit=1;
 TAB[1].CurBufUnit=1;
 TAB[1].MaxL = &DirCnt;
 TAB[1].FileToWinNum=1;
 ResetCursor(TABCnt);
 DirNum = 1;
 CurDirNum = 1;

 FillInDir(RootDirA, 0);
   GetTree(RootDirA, 2);
   gotoxy(3, 7); printf("Tree Gotten...");
   gotoxy(3, 8); printf("%d bytes needed out of 64000 allocated.", CurAlloc);
   gotoxy(3, 9);printf("%d directories found.\n", DirNum);
   if (SaveTreeFile) {
     SaveTree(TreeFile);
     gotoxy(3, 10); printf("Tree saved.");
   }
 CurDirNum=1;
 return 0;
}

//********************************************************
int GetRoot(int Num)
//********************************************************
{
 int Cnt=1;  int Ln;
 BYTE Tmp[MAXDIR];
 BYTE T2[1];
 DirNameType1 RootDir;
 int Cnt2=0;
 while (Cnt<Num)
 {
  Ln = TreeBuf[Cnt2];
  Cnt2+=Ln+6;
  Cnt++;
 }
  Ln=TreeBuf[Cnt2];
  Cnt2+=6;
  for (Cnt=0; Cnt<=Ln-1; Cnt++)
  {
   RootDirA[Cnt]=TreeBuf[Cnt+Cnt2];
  }
  RootDirA[Cnt]='\0';
  T2[0]=RootDirA[Cnt-1];
   if (T2[0]=='.') {return 1;}
   else {return 0;}
}

//********************************************************
void FillInDir(BYTE Fill[MAXDIR], int Action)
//********************************************************
{
 int Cnt2=0;
 int Ln;
 int Cnt=1;
 int Cnt3;
 //---------------------------------------------------------//
 if (Action==0)
 {
  CurAlloc=BufPos+strlen(Fill)+10;
  BufPos++;
  TreeBuf[BufPos] = (BYTE) strlen(Fill);
  //-------
  BufPos++;
  TreeBuf[BufPos] = CurDirNum;
  //-------
  for (Cnt3=0; Cnt3<=strlen(Fill)-1; Cnt3++)
  {
   TreeBuf[BufPos+5+Cnt3]=Fill[Cnt3];
  }
  BufPos+=strlen(Fill)+4;
 } //Action 0
 //---------------------------------------------------------//
 if (Action==1)
 {
 while (Cnt<=CurDirNum-1)
 {
  Ln = TreeBuf[Cnt2];
  Cnt2+=Ln+6;
  Cnt++;
 }
  Cnt2+=2;  //----- Cnt2++;
  TreeBuf[Cnt2+1]=(BYTE) TmpSubList.Start / 256;
  TreeBuf[Cnt2]=(BYTE) TmpSubList.Start - TmpSubList.Start / 256;
  TreeBuf[Cnt2+3]=(BYTE) TmpSubList.End / 256;
  TreeBuf[Cnt2+2]=(BYTE) TmpSubList.End - TmpSubList.End / 256;
  TmpSubList.Start=0;
  TmpSubList.End=0;
 } //Action 1
}

//********************************************************
int GetTree(BYTE RootDir[MAXDIR], int Action)
//********************************************************
{
 int 		Done;
 BYTE 		Sw=0;
 BYTE 		TDir[MAXDIR];
 struct 	ffblk ffblk;
 //---------------------------------------------------------//
 if (Action==0)
  {
   CurDirNum++;
   if (Abort) return 0;
   if (CurDirNum>=DirNum) {Abort=1; return 0;}
   while ((GetRoot(CurDirNum)!=0)) {CurDirNum++;}
   if (CurDirNum>=DirNum) {Abort=1; return 0;}
   GetTree(RootDirA, 2);
 }
 //---------------------------------------------------------//
 if (Action==2)
  {
   if (chdir(RootDir)) Terminate(4);

   Done=findfirst("*.*", &ffblk, 0x10);
   while (!Done)
   {
     if ((ffblk.ff_attrib==0x10) || (ffblk.ff_attrib==0x11))
     {
     strset(TDir, 0);
     strcpy(TDir, RootDir);
     if (strlen(RootDir)>3) strcat(TDir, "\\");
     strcat(TDir, ffblk.ff_name);
     DirNum++;
     if (Sw==0)
      { TmpSubList.Start=DirNum;}
     else
      { TmpSubList.End=DirNum;}
     if (Sw==0) Sw=1;
     FillInDir(TDir, 0);
     }
    Done = findnext(&ffblk);
   } // done searching subs
   FillInDir(RootDir, 1);
   GetTree(RootDir, 0);
   if (Abort) return 0;
 } //Action 2
 //---------------------------------------------------------//
 if (Abort) return 0;
 Terminate(5);
 return 0;
}

//********************************************************
void SaveTree(const char * TreeFile)
//********************************************************
{
 int Tree;
 unsigned C;
 if (_dos_creat(TreeFile, _A_NORMAL, &Tree)!=0) Terminate(6);
 if (_dos_write(Tree, TreeBuf, CurAlloc, &C)!=0) Terminate(7);
 _dos_close(Tree);
}

//********************************************************
void UserRequest(void)
//********************************************************
{
 char ch;
 printf("\nPlease type start directory (ie: C:\\, C:\\FSCAN, etc..)\n");
 gets(RootDirMain);
 printf("Do you wish to save the DirectoryTree?\n");
 ch = getch();
 SaveTreeFile=0;
 if (ch=='y') {
   SaveTreeFile=1;
   printf("Please type TreeFile's path and name\n");
   gets(TreeFile);
 }
}

//********************************************************
void Terminate(int Error)
//********************************************************
{
 clrscr();
 printf(ErrMess[Error]);
 chdir("c:\\tc30\\programs\\fscan");
 exit(1);
}

//********************************************************
void TextRectangle(int x1, int y1, int x2, int y2, int Color)
//********************************************************
{
 int x, y; textcolor(Color);
 for (x=x1+1; x<=x2-1; x++) {gotoxy(x, y1); putch('�'); gotoxy(x, y2); putch('�');}
 for (y=y1+1; y<=y2-1; y++) {gotoxy(x1, y); putch('�'); gotoxy(x2, y); putch('�');}
 gotoxy(x1, y1); putch('�'); gotoxy(x2, y1); putch('�');
 gotoxy(x1, y2); putch('�'); gotoxy(x2, y2); putch('�');
}

//********************************************************
void GetFiles(int CuDiNu)
//********************************************************
{
 FILE *Files;
 BYTE F[14];
 struct ffblk File;
 int Done=0;
 FileCnt=0;
 GetRoot(CuDiNu);
 if (chdir(RootDirA)) Terminate(4);

 if ((Files = fopen(FileFile, "w+")) == NULL) Terminate(8);
 Done = findfirst("*.*", &File, 0);
 while (!Done)
 {
  if (File.ff_attrib!=10)
  {
   FileCnt++;
   strcpy(F, File.ff_name);
   strcat(F, "\n");
   fputs(F, Files);
  }
  Done = findnext(&File);
 }
 fclose(Files);
}


//********************************************************
void OSGODScreenUp(void)
//********************************************************
{
 textbackground(1);
 clrscr();
 textcolor(1);
 TextRectangle(2,1,79,4,15);
 TextRectangle(2,1,79,25,15);
 TextRectangle(2,4,52,6,14);
 WinBound[0].x1=3; WinBound[0].y1=5; WinBound[0].x2=51; WinBound[0].y2=5;
 TextRectangle(52,4,70,6,14);
 WinBound[1].x1=53; WinBound[1].y1=5; WinBound[1].x2=69; WinBound[1].y2=5;
 TextRectangle(2,6,52,25,14);
 WinBound[2].x1=3; WinBound[2].y1=7; WinBound[2].x2=51; WinBound[2].y2=24;
 TextRectangle(52,6,70,25,14);
 WinBound[3].x1=53; WinBound[3].y1=7; WinBound[3].x2=69; WinBound[3].y2=24;
 gotoxy(52,6); putch('�');
 gotoxy(70,6); putch('�');
 gotoxy(52,25); putch('�');
 gotoxy(70,25); putch('�');
 gotoxy(52,4); putch('�');
 gotoxy(70,4); putch('�');
 gotoxy(2,4); putch('�');
 gotoxy(2,6); putch('�');
 textbackground(15); gotoxy(3,2); cprintf("OSGOD v1.0 1997 by MR.MOUSE/SadCom Ltd.");
}

//********************************************************
void ClearWindow(int WNum, int Color)
//********************************************************
{
 BYTE XLINE[80];
 int X, Y;
 for (X=0; X<=(WinBound[WNum].x2-WinBound[WNum].x1)-1; X++) XLINE[X]=32;
 XLINE[X]=0; X=WinBound[WNum].x1;
 textbackground(Color);
 for (Y=WinBound[WNum].y1; Y<=WinBound[WNum].y2; Y++)
 {
  gotoxy(X, Y); cprintf("%s", XLINE);
 }
}

//********************************************************
void StuffToWindow(int WNum, int StrtFile, int Stuff)
//********************************************************
{
 int X, Y;
 int Dl, Ds, DCnt, D;
 BYTE Tmp[MAXDIR];
 char Done=0;
 BYTE *File;
 BYTE Dir[MAXDIR];
 File="xxxxxx";
 ClearWindow(WNum, 1);
 GetRoot(CurDirNum);
 gotoxy(3, 5); printf("%s", RootDirA);
// if (FileSpaceX==0) Terminate(9);
// if (FileSpaceY==0) Terminate(9);
 if (StrtFile>FileCnt) Done=1;
 X=WinBound[WNum].x1;
 Y=WinBound[WNum].y1;
 textcolor(15);
 while (!Done)
 {

 if (Stuff==2) File = RetrieveFile(StrtFile);
 if (Stuff==1) {
		File = RetrieveDir(CurTree.StSub-1+StrtFile);
		strcpy(Tmp, File);
		Dl=strlen(Tmp);
		DCnt=Dl; Ds=-1;
		while (Ds==-1)
		{
		 if (Tmp[DCnt]=='\\') Ds=DCnt+1;
		 DCnt--;
		 if (DCnt<0) Ds=0;
		}
		DCnt=0;
		for (D=Ds; D<=Dl; D++)
		{
		 File[DCnt]=Tmp[D];
		 DCnt++;
		}
	       }

 gotoxy(X, Y); cprintf("%s", File);
 StrtFile++;
 if (Stuff==2) {if (StrtFile>FileCnt) Done=1; }
 if (Stuff==1) {if (StrtFile>DirCnt)  Done=1; }
 Y++;
 if (Y>WinBound[WNum].y2)
 {
 X+=13; Y=WinBound[WNum].y1;
 }
 if (X+13>WinBound[WNum].x2) {Done=1;}
 }
  if (chdir("c:\\tc30\\programs\\fscan")) Terminate(4);
// getch();
}

//********************************************************
BYTE *RetrieveFile(int FNum)
//********************************************************
{
 FILE *DUM;
 int Cnt;
 BYTE File[13];
 BYTE *RetFile;
 RetFile="xxxxxxxxxxxxxx";
 File[0]=0x0;
 if ((DUM = fopen(FileFile, "r"))==NULL) Terminate(10);
 for (Cnt=1; Cnt<=FNum; Cnt++)
 {
  fgets(File, 14, DUM);
 }
 fclose(DUM);
 File[strlen(File)-1]=0;
 strcpy(RetFile, File);
 return RetFile;
}

//********************************************************
void GetDirs(int DNum)
//********************************************************
{
 int Cnt=1;  int Ln;
 BYTE Tmp[MAXDIR];
 int Cnt2=0;
 Tmp[0]=0x0;
 while (Cnt<DNum)
 {
  Ln = TreeBuf[Cnt2];
  Cnt2+=Ln+6; //----..Ln+5
  Cnt++;
 }
 Cnt2++;
 CurTree.Length=Ln;
 CurTree.ParentDir=TreeBuf[Cnt2];
 CurTree.StSub=TreeBuf[Cnt2+1]+(TreeBuf[Cnt2+2]*256);
 CurTree.EnSub=TreeBuf[Cnt2+3]+(TreeBuf[Cnt2+4]*256);
 Cnt2+=5;
 for (Cnt=0; Cnt<=Ln-1; Cnt++)
 {
  CurTree.Name[Cnt]=TreeBuf[Cnt+Cnt2];
 }
 CurTree.Name[Cnt]='\0';
 DirCnt=CurTree.EnSub-CurTree.StSub+1;

}

//********************************************************
BYTE *RetrieveDir(int DNum)
//********************************************************
{
 int Ln; int Cnt3;
 BYTE Tmp[MAXDIR];
 BYTE *Tmp2;
 int Cnt, Cnt2;
 Tmp[0] =0x0;
 Tmp2="xxxxxxxx";
 Cnt=1;
 Cnt2=0;
 while (Cnt<DNum)
 {
  Ln = TreeBuf[Cnt2];
  Cnt2+=Ln+6;
  Cnt++;
 }
 Ln=TreeBuf[Cnt2];
 Cnt2+=6;
 for (Cnt=0; Cnt<=Ln-1; Cnt++)
 {
  Tmp[Cnt]=TreeBuf[Cnt+Cnt2];
 }
 Tmp[Cnt]='\0';
 strcpy(Tmp2, Tmp);
 return Tmp2;
}

void ScreenInit()
{
   GetDirs(CurDirNum);
   GetFiles(CurDirNum);
   StuffToWindow(2, 1, 2);
   StuffToWindow(3, 1, 1);
   ResetTab(TABCnt);
   ResetCursor(TABCnt);
   LightSel(TABCnt);

}

void KeyInterface(void)
{
 char Xit=0;
 while (!Xit)
 {
 ch = getch();
 if (ch==9 ) {UnLightSel(TABCnt); TABCnt++; if (TABCnt>TABE) TABCnt=TABS; ResetTab(TABCnt);}
 if (ch==27) {Xit=1;}
 if (ch==13) {ExecStuff(); ScreenInit();}
 if (!ch)
  {
   ch = getch();
   if (ch==72) MoveCursor(1);
   if (ch==80) MoveCursor(2);
   if (ch==75) MoveCursor(3);
   if (ch==77) MoveCursor(4);
  }
 }
}

void MoveCursor(char Dire)
{
 char More=1;
 if (Dire==1)
   {
    UnLightSel(TABCnt);
    if ((TAB[TABCnt].CurWinUnit==1) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y1))
	{if (TAB[TABCnt].CurBufUnit!=1)
	 {TAB[TABCnt].CursorY+=TAB[TABCnt].UnitMaxY+1;
	  TAB[TABCnt].CurWinUnit=TAB[TABCnt].UnitMaxY;
	  TAB[TABCnt].CurBufUnit--;
	  StuffToWindow(TAB[TABCnt].WinNum, TAB[TABCnt].CurBufUnit-TAB[TABCnt].UnitMaxY+1, TAB[TABCnt].FileToWinNum);
	  More=0;
	 }
	}
    if (More) {
    if ((TAB[TABCnt].CurWinUnit>1) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y1))
	{TAB[TABCnt].CursorY+=TAB[TABCnt].UnitMaxY;
	 TAB[TABCnt].CursorX-=TAB[TABCnt].UnitLn+1;
	 TAB[TABCnt].CurWinUnit--;
	 TAB[TABCnt].CurBufUnit--;
	} else {
    if ((TAB[TABCnt].CurWinUnit>1) &&
	(TAB[TABCnt].CursorY>WinBound[TAB[TABCnt].WinNum].y1))
	{TAB[TABCnt].CursorY--;
	 TAB[TABCnt].CurWinUnit--;
	 TAB[TABCnt].CurBufUnit--;
	}  }
     } //More
    LightSel(TABCnt);
   }

 if (Dire==2)
   {
    UnLightSel(TABCnt);
    if ((TAB[TABCnt].CurWinUnit==TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y2))
	{if (TAB[TABCnt].CurBufUnit!= * (int *) TAB[TABCnt].MaxL)
	 {TAB[TABCnt].CurWinUnit=1;
	  TAB[TABCnt].CurBufUnit++;
	  TAB[TABCnt].CursorY-=TAB[TABCnt].UnitMaxY-1;
	  StuffToWindow(TAB[TABCnt].WinNum, TAB[TABCnt].CurBufUnit, TAB[TABCnt].FileToWinNum);
	  More=0;
	 }
	}
    if (More) {
    if ((TAB[TABCnt].CurWinUnit<TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y2))
	{if (TAB[TABCnt].CurBufUnit!= * (int *) TAB[TABCnt].MaxL)
	{TAB[TABCnt].CursorY-=TAB[TABCnt].UnitMaxY;
	 TAB[TABCnt].CursorX+=TAB[TABCnt].UnitLn+1;
	 TAB[TABCnt].CurWinUnit++;
	 TAB[TABCnt].CurBufUnit++;
	}}  else {
    if ((TAB[TABCnt].CurWinUnit<TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY<WinBound[TAB[TABCnt].WinNum].y2))
	{if (TAB[TABCnt].CurBufUnit!=  * (int *) TAB[TABCnt].MaxL)
	{TAB[TABCnt].CursorY++;
	 TAB[TABCnt].CurWinUnit++;
	 TAB[TABCnt].CurBufUnit++;
	}}   }
     }
    LightSel(TABCnt);
   }
}

void ResetTab(char TABCnt)
{
 TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
 TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
 TAB[TABCnt].CurWinUnit=1;
 TAB[TABCnt].CurBufUnit=1;
 ResetCursor(TABCnt);
 LightSel(TABCnt);
}

void ResetCursor(int TABCnt)
{
 TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
 TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
}

void UnLightSel(int TABCnt)
{
// BYTE *String;
 BYTE Tmp[MAXDIR];
 int Dl, DCnt, Ds, D;
 Tmp[0]=0x0;
 String="xxxxxxx";
 textbackground(1); textcolor(15);
 if (TABCnt==0) String = RetrieveFile(TAB[TABCnt].CurBufUnit);
 if (TABCnt==1) {
		String = RetrieveDir(CurTree.StSub-1+TAB[TABCnt].CurBufUnit);
		strcpy(Tmp, String);
		Dl=strlen(Tmp);
		DCnt=Dl; Ds=-1;
		while (Ds==-1)
		{
		 if (Tmp[DCnt]=='\\') Ds=DCnt+1;
		 DCnt--;
		 if (DCnt<0) Ds=0;
		}
		DCnt=0;
		for (D=Ds; D<=Dl; D++)
		{
		 String[DCnt]=Tmp[D];
		 DCnt++;
		}
	       }

 gotoxy(TAB[TABCnt].CursorX, TAB[TABCnt].CursorY);
 cprintf("%s", String);
 textbackground(1); textcolor(15);
}

void LightSel(int TABCnt)
{
// BYTE *Str;
 BYTE Tmp[MAXDIR];
 int Dl, DCnt, Ds, D;
 String="xxxxxx";
 Tmp[0]=0x0;
 textbackground(7); textcolor(1);
 if (TABCnt==0) String = RetrieveFile(TAB[TABCnt].CurBufUnit);
 if (TABCnt==1) {
		String = RetrieveDir(CurTree.StSub-1+TAB[TABCnt].CurBufUnit);
		strcpy(Tmp, String);
		Dl=strlen(Tmp);
		DCnt=Dl; Ds=-1;
		while (Ds==-1)
		{
		 if (Tmp[DCnt]=='\\') Ds=DCnt+1;
		 DCnt--;
		 if (DCnt<0) Ds=0;
		}
		DCnt=0;
		for (D=Ds; D<=Dl; D++)
		{
		 String[DCnt]=Tmp[D];
		 DCnt++;
		}
	       }

 gotoxy(TAB[TABCnt].CursorX, TAB[TABCnt].CursorY);
 cprintf("%s", String);
 textbackground(1); textcolor(15);
}

void ExecStuff()
{
 if (TABCnt==1)
 {
  if (  ((strcmp(String, ".."))==0) ||
	((strcmp(String, "."))==0)   )
  {CurDirNum=CurTree.ParentDir;
  ScreenInit();}
  else {CurDirNum=CurTree.StSub-1+TAB[TABCnt].CurBufUnit;
	ScreenInit();}
 }

}

//********************************************************
//********************************************************
int main(void)
//********************************************************
//********************************************************
{
   Xit=0;
   clrscr();
   Init();
   OSGODScreenUp();
   ScreenInit();
   KeyInterface();
   textbackground(0);
   clrscr();
   return 0;
}




