//test mousefunc
#include "system.h"
#include "defs.h"
#include "mouse.h"

#pragma inline

typedef struct  {int ButtonX1;
		 int ButtonY1;
		 int ButtonX2;
		 int ButtonY2;
		 BYTE Attrib;
		 BYTE ButtonColor;
		 BYTE ButtonTXTColor;
		 BYTE ButtonBKColor;
		 BYTE ButtonBKTxtColor;
		 BYTE ButtonText[13];
		 void *Function;
		} ButtonObj;

ButtonObj Button[10];
BYTE      ButtonHit;

void ShowFile(BYTE* FileName)
{
 int Y;
 FILE *Str;
 BYTE String1[80];
 textcolor(14);
 textbackground(0);
 clrscr();
 Str = fopen(FileName, "rt+");
 Y=0;
 while ((fgets(String1, 80 ,  Str))!=NULL)
 {
  Y++; if (Y==23) {Y=0; getch();}
  printf("%s", String1);
 }
  cprintf("===----End of File ----===\n");
 fclose(Str);
 getch();

}

void CreateButtons(void)
{
 Button[0].ButtonX1=10;
 Button[0].ButtonY1=20;
 Button[0].ButtonX2=18;
 Button[0].ButtonY2=20;
 Button[0].Attrib=FALSE;
 Button[0].ButtonColor=2;
 Button[0].ButtonTXTColor=14;
 Button[0].ButtonBKColor=1;
 Button[0].ButtonBKTxtColor=0;
 strcpy(Button[0].ButtonText, "Start");
 Button[1].ButtonX1=20;
 Button[1].ButtonY1=20;
 Button[1].ButtonX2=28;
 Button[1].ButtonY2=20;
 Button[1].Attrib=FALSE;
 Button[1].ButtonColor=2;
 Button[1].ButtonTXTColor=14;
 Button[1].ButtonBKColor=1;
 Button[1].ButtonBKTxtColor=0;
 strcpy(Button[1].ButtonText, "Exit");
}

void DrawTXTBlock(BYTE ch, int x, int y, int W, int L)
{
 int xx, yy;
 for (yy=y; yy<=y+L; yy++)
 {
 for (xx=x; xx<=x+W; xx++)
 {gotoxy(xx, y); cprintf("%c", ch);
 }
 }
}


void DrawButton(int But, BYTE Pressed)
{
 int x, y;

 if (!Pressed)
 {
 Button[But].Attrib=Pressed;
 textcolor(Button[But].ButtonColor);
 DrawTXTBlock(219, Button[But].ButtonX1, Button[But].ButtonY1,
		  Button[But].ButtonX2-Button[But].ButtonX1,
		  Button[But].ButtonY2-Button[But].ButtonY1
		  );
 gotoxy(Button[But].ButtonX1+1, Button[But].ButtonY1);
 textcolor(Button[But].ButtonTXTColor);
 textbackground(Button[But].ButtonColor);
 cprintf("%s", Button[But].ButtonText);
 }
 if (Pressed)
 {
 Button[But].Attrib=Pressed;
 textcolor(Button[But].ButtonBKColor);
 DrawTXTBlock(219, Button[But].ButtonX1, Button[But].ButtonY1,
		  Button[But].ButtonX2-Button[But].ButtonX1,
		  Button[But].ButtonY2-Button[But].ButtonY1
		  );
 gotoxy(Button[But].ButtonX1+1, Button[But].ButtonY1);
 textcolor(Button[But].ButtonBKTxtColor);
 textbackground(Button[But].ButtonBKColor);
 cprintf("%s", Button[But].ButtonText);
 }
}

void SetUpScreen(void)
{
 textbackground(0);
 clrscr();
 DrawButton(0, 0);

 DrawButton(1, 0);
}
void CheckButtons(void)
{
 if (ButtonHit==1) { ShowFile("mtest.c");  SetUpScreen();}
 if (ButtonHit==2) { textbackground(0);
		     textcolor(7);
		     clrscr();
		     HideMouse();
		     ResetMouse();
		     exit(1); }
}


int MouseLeft(void)
{
 if (CheckTXTMouseArea(Button[0].ButtonX1,
		     Button[0].ButtonY1,
		     Button[0].ButtonX2,
		     Button[0].ButtonY2) == TRUE) {
		     ButtonHit=1;
		     if (Button[0].Attrib==FALSE)
		     DrawButton(0, TRUE); }
 if (CheckTXTMouseArea(Button[1].ButtonX1,
		     Button[1].ButtonY1,
		     Button[1].ButtonX2,
		     Button[1].ButtonY2) == TRUE) {
		     ButtonHit=2;
		     DrawButton(1, TRUE);}
 return 0;
}



int main(void)
{
 TObj Mouse;
 BYTE Xit=0;
 BYTE ch;
 BYTE LstMseAct;

 CheckMouse();
 CreateButtons();
 InitTxtMouse();
 ShowMouse();
 SetUpScreen();
 AsnFnctToMseAct(MouseLeft, MOUSE_LEFT);

 while (!Xit)
 {
  while (kbhit())
  {
   ch =getch();
   if (ch==27) Xit=1;
  }
  ButtonHit=0;
  Mouse = TrackTXTMouse();
  if (ButtonHit) CheckButtons();
  if (Mouse.LastAction!=LstMseAct)
  {
   LstMseAct=Mouse.LastAction;
   if (LstMseAct==MOUSE_IDLE) {HideMouse();
			       DrawButton(ButtonHit, FALSE);
			       ShowMouse();}
  }
 }

 DrawButton(1, TRUE);
 delay(200);

 return 0;
}

