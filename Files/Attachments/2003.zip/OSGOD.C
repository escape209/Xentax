/*
--------------------------------------------------------------------------

			      M A K E D A T

				V 0 . 0 5

				   B Y

			       S A D C O M

				  L T D

		    Copyright 1997 Mr.Mouse/SadCom Ltd.

--------------------------------------------------------------------------
*/

#include <sys\stat.h>

#include <bios.h>
#include <string.h>
#include <dos.h>
#include <io.h>
#include <stdio.h>
#include <dir.h>
#include <process.h>
#include "mouse.h"
#include "makedat.h"
#include "osgod.h"
#include <conio.h>
#include <fcntl.h>

BYTE 			MCMode;
char			OldBuf[4096];
char 			WinBuf[WIN_BUFSIZE];
int 			MC, ML;
int 			argc;
int			PrioCnt[18];
int 			FileCnt;
int 			TFCnt;
int 			DriveCnt=2;
int			SelCnt=0;
int 			ExtCnt=0;
char 			TABCnt;
char 			TABS, TABE;
BYTE            	ButtonHit;
BYTE 	        	WinOn;
BYTE	       	        argv0[90];
BYTE	       	        argv1[90];
BYTE 	       	       *ErrMess[20];
BYTE			SaveTreeFile;
BYTE	       	       *String="xxxxxxxxx";
EXTBYTE	        	Ext; //="xxx";
int			PrioList[18];
TABtype			TAB[4];
DIRBYTE	        	CurRoot;
DIRBYTE   		SelectFile;
DIRBYTE   		INIFile="makedat.ini";
BYTE	        	FileFile[90];
BYTE	        	MainView[90];
BYTE 	  		ExtFile[90];
extern SelectType 	SelectList[100];
WinType			Windows[7];
BYTE            	OSGODRoot[90];
BYTE 			DosError=0;
BYTE	        	Tmp[83];
extern FileObj  	FileList[100];
ButtonObj        	Button[10];

const DIRBYTE   	PreDir="x:\\";

typedef 		struct	{
			BYTE Filename[20];
			long FileStart;
			long FileEnd;
			long FileSize;
			} MExtractType;


struct          	WindowBound {
			int x1;
			int y1;
			int x2;
			int y2;} WinBound[6];

struct 			Extens {
			BYTE Ext[4];
			BYTE AsPath[MAXDIR];} ExtAss[30];

MExtractType		CurrentMex;

//--------------------------------------------------------

int ReturnAndReset(void)
{
  chdir(String);
  strcpy(CurRoot, "xxxxxx");
  GetCurRoot(CurRoot);
  GetFiles();
  MCMode=_NORMAL;
  ClearSelectList();
  OSGODScreenUp();
  gotoxy(51,24); cprintf("%d", TFCnt);
  ScreenInit();
 return 0;
}

void far handler(unsigned deverr, unsigned errval, unsigned far *devhdr)
{
//  static char msg[80];
  int number;
  int drive;
  int errorno;

  /* if this not disk error then another device having trouble */
  if (deverr & 0x8000) {
    SystemMessage("Drive Not Ready", 1); DriveCnt--;

   _hardresume(_HARDERR_IGNORE);
    /* return to the program directly requesting abort */
   // _hardretn(5);                  /* 5 = DOS "access denied" error */
  }
   SystemMessage("Drive Not Ready", 1);
   DriveCnt--;
   setdisk(DriveCnt);
   strcpy(CurRoot, "xxxxxx");
   GetCurRoot(CurRoot);
   GetFiles();
   OSGODScreenUp();
   gotoxy(51,24); cprintf("%d", TFCnt);
   ScreenInit();
   DosError=1;
  _hardresume(_HARDERR_IGNORE);
//    drive = deverr & 0x00FF;          /* otherwise it was disk error */
//  errorno = errval & 0x00FF;

  /* report which error it was */

  /* return to program via dos interrupt 0x23 with abort, retry */
  /* or ignore as input by the user */
  _hardresume(_HARDERR_IGNORE);
// return 0;
}

int Init(void)
{
 char M;
 int WNum;
 ErrMess[0]="No way I am going to find that Root directory! Retype it!";
 ErrMess[1]="Unable to create DUM.FSC";
 ErrMess[2]="Unable to allocate memory for TreeBuf";
 ErrMess[3]="Unable to reallocate memory for TreeBuf";
 ErrMess[4]="Unable to change directory";
 ErrMess[5]="Frankly, the program shouldn't have reached this far!";
 ErrMess[6]="Unable to create TreeFile";
 ErrMess[7]="Unable to write to TreeFile";
 ErrMess[8]="Unable to create TEMPFILE.FSC";
 ErrMess[9]="Unable to throw files to window";
 ErrMess[10]="Unable to open TEMPFILE.FSC";
 ErrMess[11]="Unable to open file";
 ErrMess[12]="String is NULL!";
 ErrMess[13]="Unable to find MAKEDAT.INI";
 ErrMess[14]="Fault in MAKEDAT.INI: EXTtension formulated incorrectly";
 ErrMess[15]="Unable to spawn program";
 ErrMess[16]="Incomplete MAKEDAT.INI File";

 MCMode=_NORMAL;

 SetDefaultPrioCnts();

 _setcursortype(0);

 _harderr(handler);

 DriveCnt=1;

// argv[0]="x";

 ReadINI(INIFile);

 CreateButtons();

 strset(CurRoot, 0);
 GetCurRoot(CurRoot);
 if (chdir(CurRoot)) 			Terminate(0);

 WinBound[0].x1=3;
 WinBound[0].y1=3;
 WinBound[0].x2=42;
 WinBound[0].y2=3;

 WinBound[1].x1=44;
 WinBound[1].y1=3;
 WinBound[1].x2=69;
 WinBound[1].y2=3;

 WinBound[2].x1=3;
 WinBound[2].y1=5;
 WinBound[2].x2=42;
 WinBound[2].y2=22;

 WinBound[3].x1=44;
 WinBound[3].y1=5;
 WinBound[3].x2=70;
 WinBound[3].y2=22;

 WinBound[4].x1=44;
 WinBound[4].y1=5;
 WinBound[4].x2=70;
 WinBound[4].y2=22;

 TABCnt=0; TABS=0; TABE=1;

 TAB[0].WinNum=2;
 TAB[0].UnitLn=12;
 TAB[0].CurWinUnit=1;
 TAB[0].CurBufUnit=1;
 TAB[0].FileToWinNum=2;

 TAB[1].WinNum=3;
 TAB[1].UnitLn=12;
 TAB[1].CurWinUnit=0;
 TAB[1].CurBufUnit=0;
 TAB[1].FileToWinNum=1;

 SetDrive(1);  //SetDrive also start initializing FileGetting and
	       //OSGODScreenUp etc, therefore the lower TAB settings
	       //can ONLY follow AFTER these INIs!!

 WNum=2;
 TAB[0].MaxL     = &FileCnt;
 TAB[1].MaxL 	 = &SelCnt;
 TAB[0].UnitMaxX = (WinBound[WNum].x2-WinBound[WNum].x1)/13;
 TAB[0].UnitMaxY = (WinBound[WNum].y2-WinBound[WNum].y1)+1;
 TAB[0].MaxUnits = TAB[0].UnitMaxX*TAB[0].UnitMaxY;
 TAB[0].CursorX  = WinBound[WNum].x1;
 TAB[0].CursorY  = WinBound[WNum].y1;

 WNum=3;
 TAB[1].UnitMaxX = (WinBound[WNum].x2-WinBound[WNum].x1)/13;
 TAB[1].UnitMaxY = (WinBound[WNum].y2-WinBound[WNum].y1)+1;
 TAB[1].MaxUnits = TAB[1].UnitMaxX*TAB[1].UnitMaxY;
 TAB[1].CursorX  = WinBound[WNum].x1;
 TAB[1].CursorY  = WinBound[WNum].y1-1;

 MakeWindow(1, 25, 10, 55, 14, 0, 4, 4, "System Error:");
 MakeWindow(2, 25, 10, 55, 14, 0, 2, 7, "System Message:");
 MakeWindow(3, 4 , 10, 74, 16, 0, 2, 7, "System Request:");
 MakeWindow(4, 43, 4 , 70, 23, 1, 0, 1, "MakeDat v1.07 Output:");
 MakeWindow(5, 05, 5, 35, 9, 2, 2, 1, "Completion of ");

 return 0;
}
//--------------------------------------------------------

void ClearSelectList(void)
{
 int i, j;
 for (i=0; i<=100; i++)
 {
  for (j=0; j<=90; j++);
  {
  SelectList[i].FileName[j]=0;
  FileList[i].FileName[j]=0;}
 }
  SelCnt=0;
  ClearWinBuf();
  Windows[4].TopMessOff=0;
  Windows[4].NewMessOff=0;
}

//--------------------------------------------------------

int CompletionWindow(BYTE *ExtraMess, int Percent, BYTE New)
{
 int x, y;
 int Nu;
 textbackground(Windows[5].InColor);
 textcolor(0);
 y=Windows[5].y1;
 x=Windows[5].x1;
 if (New) {gotoxy(x+4, y+2); cprintf("                      ");}
 textbackground(Windows[5].OutColor);
 gotoxy(x+15, y); cprintf("             ");
 gotoxy(x+15, y); cprintf("%s", ExtraMess);
 Nu=0;
 textcolor(15);
 while (Nu<=Percent/10)
 {
  gotoxy(x+4+(Nu*2), y+2); cprintf("��");
  Nu++;
 }
 textbackground(0);
 return 0;
}





void SystemMessage(BYTE *Message, int WNum)
{
 PlaceWindow(WNum);
 textbackground(Windows[WNum].InColor);
 gotoxy(Windows[WNum].x1+
	((Windows[WNum].x2-Windows[WNum].x1)-strlen(Message))/2,
	 Windows[WNum].y1+(Windows[WNum].y2-Windows[WNum].y1)/2);
 cprintf("%s", Message);
 if (WNum==1) BeepError();
 if (WNum==2) BeepOk();
 getch();
 textbackground(1); textcolor(1);
 RemoveWindow(WNum);
}

//--------------------------------------------------------

BYTE* SystemRequest(BYTE *Request, int WNum, int L)
{
 int Y, i;
 char *p;
 char k=0;
 PlaceWindow(WNum);
 textbackground(Windows[WNum].InColor);
 textcolor(15);
 Y=Windows[WNum].y1+(Windows[WNum].y2-Windows[WNum].y1)/2-1;
 gotoxy(Windows[WNum].x1+
	((Windows[WNum].x2-Windows[WNum].x1)-strlen(Request))/2, Y);

 if (Request[0]==27) { k=1; cprintf("%s", &Request[1]); }
 else {cprintf("%s", Request); }


 textbackground(0); textcolor(14);
 if (L)
 {
 for (i=Windows[WNum].x1+2; i<=Windows[WNum].x1+2+L; i++)
 {gotoxy(i, Y+2); cprintf(" "); }
 }
 else  { textbackground(Windows[WNum].InColor);
	 gotoxy(Windows[WNum].x1+2, Y+2);
	 cprintf("[Y]es / [N]o"); }

 gotoxy(Windows[WNum].x1+2, Y+2);
 Tmp[0]=L;

 //if k then request is for yes and no

 if (!k) {p = cgets(Tmp);}
  else { k=getch();
	 p[0]=0;
	 if (k=='y') p[0]=1;
       }
 RemoveWindow(WNum);
 return p;

}


//--------------------------------------------------------

void MakeWindow(int Wnum, int x1, int y1,
		int x2,   int y2, int Type,
		char LColor, char DColor, BYTE Title[30])
{
Windows[Wnum].x1=x1;
Windows[Wnum].y1=y1;
Windows[Wnum].x2=x2;
Windows[Wnum].y2=y2;
Windows[Wnum].Type=Type;
if (Type==1)
{
 Windows[Wnum].Buf=WinBuf;
 Windows[Wnum].TopMessOff=0;
 Windows[Wnum].GlMessY=y1;
 Windows[Wnum].NewMessOff=0;
}

Windows[Wnum].InColor=LColor;
Windows[Wnum].OutColor=DColor;
strcpy(Windows[Wnum].Title, Title);
}

//--------------------------------------------------------

void PlaceWindow(int WNum)
{
 int x, y;
 int BNum;
 WinOn=WNum;
 gettext(Windows[WNum].x1,
	 Windows[WNum].y1,
	 Windows[WNum].x2+1,
	 Windows[WNum].y2+1, OldBuf);

 textcolor(15); textbackground(Windows[WNum].OutColor);

 for (x=Windows[WNum].x1; x<=Windows[WNum].x2; x++)
 {gotoxy(x, Windows[WNum].y1); cprintf("�");
  gotoxy(x, Windows[WNum].y2); cprintf("�");}

 for (y=Windows[WNum].y1; y<=Windows[WNum].y2; y++)
 {gotoxy(Windows[WNum].x1, y); cprintf("�");
  gotoxy(Windows[WNum].x2, y); cprintf("�");}

 gotoxy(Windows[WNum].x1, Windows[WNum].y1); cprintf("�");
 gotoxy(Windows[WNum].x2, Windows[WNum].y1); cprintf("�");
 gotoxy(Windows[WNum].x1, Windows[WNum].y2); cprintf("�");
 gotoxy(Windows[WNum].x2, Windows[WNum].y2); cprintf("�");

 gotoxy(Windows[WNum].x1+1,Windows[WNum].y1);
 cprintf("%s", Windows[WNum].Title);

 textbackground(0);

 for (x=Windows[WNum].x1+1; x<=Windows[WNum].x2+1; x++)
 {gotoxy(x, Windows[WNum].y2+1); cprintf(" ");}

 for (y=Windows[WNum].y1+1; y<=Windows[WNum].y2; y++)
 {gotoxy(Windows[WNum].x2+1, y); cprintf(" ");}

 textcolor(15); textbackground(Windows[WNum].InColor);

 for (y=Windows[WNum].y1+1; y<=Windows[WNum].y2-1; y++)
 {
  for (x=Windows[WNum].x1+1; x<=Windows[WNum].x2-1; x++)
  {
   gotoxy(x,y); cprintf(" ");
  }
 }
}

//--------------------------------------------------------

void ClearWinBuf(void)
{
 int i;
 for (i=0; i<=WIN_BUFSIZE; i++) WinBuf[i]=0;
}


//--------------------------------------------------------

int MessageToWindow(int WNum, BYTE *Message)
{
 BYTE *P;
 BYTE CheckOff=0;
 int y, x;
 int Off;
 int NewMessOff;
 int TopMessOff;


 if (Windows[WNum].Type!=1) return 0;

 NewMessOff=Windows[WNum].NewMessOff;
 TopMessOff=Windows[WNum].TopMessOff;

 if (NewMessOff!=0)
 {
 if ((strlen(Message)+1+NewMessOff)>4096)
    {
     ClearWinBuf();
     Windows[WNum].NewMessOff=0;
     Windows[WNum].TopMessOff=0;
     NewMessOff=0;
     P = &WinBuf[NewMessOff];
    }
    else
    {P = &WinBuf[NewMessOff];
     Windows[WNum].NewMessOff+=strlen(Message)+1;
     NewMessOff+=strlen(Message)+1;
    }
 }
 else {
 P = &WinBuf[NewMessOff];
 Windows[WNum].NewMessOff+=strlen(Message)+1;
 Windows[WNum].TopMessSize=strlen(Message)+1;
 }

     if (Windows[WNum].GlMessY>=Windows[WNum].y2-1)
     {
     TopMessOff+=Windows[WNum].TopMessSize;
     Windows[WNum].TopMessOff=TopMessOff;
     Windows[WNum].GlMessY-=1;
     CheckOff=1;
     }

 strcpy(P, Message);

 textcolor(15);

 Off = TopMessOff;
 y=Windows[WNum].y1+1;

 while ((y<=(Windows[WNum].y2)-1) && (Off!=NewMessOff+strlen(Message)+1))
 {
   x=Windows[WNum].x1+1;
   while (x<=Windows[WNum].x2-1)
   {
     gotoxy(x, y);
     if (WinBuf[Off]!=0)
      {cprintf("%c", WinBuf[Off]); Off++;}
     else {cprintf(" ");}
     x++;
   }


  if (CheckOff)
  {
   Windows[WNum].TopMessSize=(Off)-TopMessOff+1;
   CheckOff=0;
  }
  Off++;
  y++;
 }
  Windows[WNum].GlMessY++;
 return 0;
}


int ResetMessWindow(int WNum)
{
 Windows[WNum].GlMessY=Windows[WNum].y1;
 Windows[WNum].TopMessOff=0;
 Windows[WNum].NewMessOff=0;
 return 0;
}

//--------------------------------------------------------

int UpdateFileInfo(void)
{
 BYTE *File;
 FILE *Str;
 long Size;
 struct ftime ff;

 textcolor(15);
 textbackground(1);

 gotoxy(3, 24);

 cprintf("                                     ");

 if (TAB[TABCnt].CurBufUnit<=PrioCnt[1]) return 0;
 if (TAB[TABCnt].CurBufUnit<=PrioCnt[2]) return 0;
 if (TAB[TABCnt].CurBufUnit<=PrioCnt[3]) return 0;
 if (TABCnt==1) return 0;

 File = RetrieveFile(TAB[TABCnt].CurBufUnit);

if (MCMode==_NORMAL) Size = GetFileSize(File);
if (MCMode==_EXTRACT) {
			Size = GetMEFileSize(TAB[TABCnt].CurBufUnit);
			strcpy(CurrentMex.Filename, File);
		      }
 Str = fopen(File, "r");

 getftime (fileno(Str), &ff);

 fclose(Str);

 gotoxy(3, 24);

 cprintf("%lu",	 Size);

 gotoxy(16, 24);

 if (MCMode==_NORMAL) cprintf("%d/%d/%d", ff.ft_year+80, ff.ft_month, ff.ft_day);
 if (MCMode==_EXTRACT) cprintf("??/??/??");

 gotoxy(29, 24);

 if (MCMode==_NORMAL) cprintf("%d:%d:%d",ff.ft_hour, ff.ft_min, ff.ft_tsec );
 if (MCMode==_EXTRACT) cprintf("??/??/??");

 return 0;
}

//--------------------------------------------------------

void RemoveWindow(int WNum)
{
 if (WNum==WinOn)
 {
 puttext(Windows[WNum].x1, Windows[WNum].y1, Windows[WNum].x2+1, Windows[WNum].y2+1, OldBuf);
 }
}

//--------------------------------------------------------

void ReadINI(BYTE *FileName)
{
 FILE *INI;
 BYTE Buffer[80];
 BYTE *Buf;
 int EqPos;
 ExtCnt=0;

 if ((INI = fopen(FileName, "rt"))==NULL) Terminate(13);

 while ((fgets(Buffer, 80, INI))!=NULL)
 {
  if ((Buffer[0]!=';') && (Buffer!="\n"))
  {

   if ((EqPos = strncmp(Buffer, "ROUT=", 5))==0)
   {
   Buf = &Buffer[5];
   strcpy(OSGODRoot, Buf);
   EqPos=strlen(OSGODRoot);
   OSGODRoot[EqPos-1]=0;
   }
   if ((strncmp(Buffer, "FILEFILE=", 9))==0)
   {
   Buf = &Buffer[9];
   strcpy(FileFile, Buf);
   EqPos=strlen(FileFile);
   FileFile[EqPos-1]=0;
   }

   if ((strncmp(Buffer, "SELECTFILE=", 11))==0)
   {
   Buf = &Buffer[11];
   strcpy(SelectFile, Buf);
   EqPos=strlen(SelectFile);
   SelectFile[EqPos-1]=0;
    }
   if ((strncmp(Buffer, "MAINVIEWER=", 11))==0)
   {
   Buf = &Buffer[11];
   strcpy(MainView, Buf);
   EqPos=strlen(MainView);
   MainView[EqPos-1]=0;
    }
   if ((strncmp(Buffer, "EXT=", 4))==0)
   {
    ClearExtStruct(ExtCnt);
    for (EqPos=0; EqPos<=2; EqPos++)
    {
     if (Buffer[4+EqPos]>63)
     ExtAss[ExtCnt].Ext[EqPos]=Buffer[4+EqPos];
    }
    EqPos=0;
    while ((Buffer[4+EqPos]!='>') && (EqPos<=80))
    {
     EqPos++;
    }
    if (EqPos>80) Terminate(14);
    Buf = &Buffer[4+EqPos+2];
    strcpy(ExtAss[ExtCnt].AsPath, Buf);
    EqPos=strlen(ExtAss[ExtCnt].AsPath);
    ExtAss[ExtCnt].AsPath[EqPos-1]=0;
    ExtCnt++;
   }

  }
 }
 if (SelectFile==NULL) Terminate (16);
 if (OSGODRoot==NULL)  Terminate (16);
 if (FileFile==NULL)  Terminate (16);

}


//--------------------------------------------------------

void Terminate(int Error)
{
 clrscr();
 perror(ErrMess[Error]);
// chdir("c:\\tc30\\programs\\fscan");
 _setcursortype(_NORMALCURSOR);

 exit(1);
}

//--------------------------------------------------------

void TextRectangle(int x1, int y1, int x2, int y2, int Color)
{
 int x, y; textcolor(Color);

 for (x=x1+1; x<=x2-1; x++)
  {
  gotoxy(x, y1); putch('�');
  gotoxy(x, y2); putch('�');
 }

 for (y=y1+1; y<=y2-1; y++)
  {
   gotoxy(x1, y); putch('�');
   gotoxy(x2, y); putch('�');
  }
 gotoxy(x1, y1); putch('�');
 gotoxy(x2, y1); putch('�');
 gotoxy(x1, y2); putch('�');
 gotoxy(x2, y2); putch('�');
}

//--------------------------------------------------------

int GetFiles()
{
 FILE *Files;
 BYTE F[14];
 struct find_t ffblk;
 int Done=0;
 char PCnt=0; char Xit=0;
 ClearPrioCnts();
 FileCnt=0; TFCnt=0;
 if ((Files = fopen(FileFile, "w")) == NULL) Terminate(8);
 while (!Xit)
 {
 Done = _dos_findfirst("*.*",PrioList[PCnt],&ffblk);
 if (DosError) {Done=1; Xit=1; DosError=0; }
 while (!Done)
 {
  if (ffblk.attrib==PrioList[PCnt])
  {

   FileCnt++; PrioCnt[PCnt]++; if (PCnt>2) TFCnt++;
   strcpy(F, ffblk.name);
   strcat(F, "\n");
   fputs(F, Files);
  }
  Done = _dos_findnext(&ffblk);
// textbackground(0); textcolor(15);
 }
 PCnt++;
 if (PCnt>16){ Xit=1;}
 else {PrioCnt[PCnt]+=PrioCnt[PCnt-1];}
 }
 fclose(Files);
 return TFCnt;
}


//--------------------------------------------------------

void OSGODScreenUp(void)
{
 textbackground(1);
 clrscr();
 textcolor(1);
 textbackground(1);
 TextRectangle(2, 1, 79, 2 ,15);
 TextRectangle(2, 1, 79, 25,15);
 textbackground(1);
 textcolor(1);
// TextRectangle(2, 1, 79, 23,15);
 textbackground(1);
 TextRectangle(2, 2, 43, 4 ,14);
 TextRectangle(43,2,70,4,14);
 TextRectangle(2,4,42,23,14);
 TextRectangle(43,4,70,23,14);
 TextRectangle(2,23,42,25,14);
 TextRectangle(43,23,70,25,14);
 gotoxy(43, 4); putch('�');
 gotoxy(42, 4); putch('�');
 gotoxy(42, 3); putch('�');
 gotoxy(70, 4); putch('�');
 gotoxy(43,23); putch('�');
 gotoxy(70,23); putch('�');
 gotoxy(70,25); putch('�');
 gotoxy(43, 2); putch('�');
 gotoxy(42, 2); putch('�');
 gotoxy(42, 23);putch('�');
 gotoxy(43, 23);putch('�');
 gotoxy(70, 2); putch('�');
 gotoxy(2 , 2); putch('�');
 gotoxy(2 , 23); putch('�');
 gotoxy(2 , 4); putch('�');

 textcolor(15);
 gotoxy(79 , 2); putch('�');
 gotoxy(44, 3); cprintf("Selected:");
 textbackground(0);
 gotoxy(17,1);
 cprintf("Multiex Commander v1.07 by Mr.Mouse/XeNTaX");
 textbackground(1); textcolor(15);
 gotoxy(44, 24); cprintf("Files:     ");

 DrawButtons();

}

//--------------------------------------------------------

void ClearWindow(int WNum, int Color)
{
 BYTE XLINE[80];
 int X, Y;
 for (X=0; X<=(WinBound[WNum].x2-WinBound[WNum].x1)-1; X++) XLINE[X]=32;
 XLINE[X]=0; X=WinBound[WNum].x1;
 textbackground(Color);
 for (Y=WinBound[WNum].y1; Y<=WinBound[WNum].y2; Y++)
 {
  gotoxy(X, Y); cprintf("%s", XLINE);
 }
}

//--------------------------------------------------------

void StuffToWindow(int far Win, int far StrtFile, int far Stuff)
{
 int X, Y;
 char Done=0;
 BYTE *RootText;
 BYTE Color;
 BYTE *File;
 File="-------";
 ClearWindow(Win, 1);

if (Win==2)
{
 textcolor(15);
 gotoxy(3,3);cprintf("                                       ");
 gotoxy(3, 3);
 RootText = ReducePath(CurRoot, 39);
 cprintf("%s", RootText);
 if (StrtFile>FileCnt) Done=1;
 X=WinBound[Win].x1;
 Y=WinBound[Win].y1;
 while (!Done)
 {

 if (Stuff==2) File = RetrieveFile(StrtFile);

 if (StrtFile<=PrioCnt[3]) Color=15;
 if ((StrtFile>PrioCnt[3]) && (StrtFile<=PrioCnt[4])) Color=10;
 if ((StrtFile>PrioCnt[4]) && (StrtFile<=PrioCnt[8])) Color=8;
 if ((StrtFile>PrioCnt[8]) && (StrtFile<=PrioCnt[15])) Color=14;
// if ((StrtFile>PrioCnt[15]) && (StrtFile<=PrioCnt[12])) Color=11;
 if (StrtFile>PrioCnt[15]) Color=12;
 textcolor(Color);
 gotoxy(X, Y); cprintf("%s", File);
 StrtFile++;
 if (Stuff==2) {if (StrtFile>FileCnt) Done=1; }
 Y++;
 if (Y>WinBound[Win].y2)
 {
 X+=13; Y=WinBound[Win].y1;
 }
 if (X+13>WinBound[Win].x2) {Done=1;}
 }
}
 if (Win==3)
 {
 textcolor(12);
 X=WinBound[Win].x1;
 Y=WinBound[Win].y1;
 while ((!Done) && (StrtFile<SelCnt+1))
 {
 if (StrtFile<100) {gotoxy(X, Y);
		    cprintf("%s", SelectList[StrtFile].FileName); }
 StrtFile++;
 Y++;
 if (Y>WinBound[Win].y2)
 {
 X+=13; Y=WinBound[Win].y1;
 }
 if (X+13>WinBound[Win].x2) {Done=1;}
 }
 }

}

//--------------------------------------------------------

BYTE *RetrieveFile(int FNum)
{
 FILE *DUM;
 int Cnt;
 BYTE File[13];
 BYTE *RetFile;
 RetFile="xxxxxxxxxxxxxx";
 File[0]=0x0;
 if ((DUM = fopen(FileFile, "r"))==NULL) Terminate(10);
 for (Cnt=1; Cnt<=FNum; Cnt++)
 {
  fgets(File, 14, DUM);
 }
 fclose(DUM);
 File[strlen(File)-1]=0;
 strcpy(RetFile, File);
 return RetFile;
}

//--------------------------------------------------------

void ScreenInit()
{
   ShowMouse();
   StuffToWindow(2, 1, 2);
   ResetTab(TABCnt);
   ResetCursor(TABCnt);
   LightSel(TABCnt);
  _setcursortype(0);
   if (MCMode==_NORMAL)
    { UpdateFileInfo();
      gotoxy(56, 24); cprintf("Mode: Normal ");
    }
    if (MCMode==_EXTRACT)
    {
      UpdateFileInfo();
      gotoxy(56, 24); cprintf("Mode: Extract");
    }
}

//--------------------------------------------------------

int MoveTab(void)
{
 if ((TABCnt+1==1) && (SelCnt==0)) {return 0;}
 UnLightSel(TABCnt);
 TABCnt++;
 if (TABCnt>TABE) TABCnt=TABS;
 LightSel(TABCnt);
 return 0;
}

//--------------------------------------------------------

int PageUp(void)
{
 int i;

 if (TAB[TABCnt].CurBufUnit-TAB[TABCnt].MaxUnits>0)
 {
  UnLightSel(TABCnt);

  TAB[TABCnt].CursorY    = WinBound[TAB[TABCnt].WinNum].y1;
  TAB[TABCnt].CursorX    = WinBound[TAB[TABCnt].WinNum].x1;
  TAB[TABCnt].CurBufUnit-= TAB[TABCnt].MaxUnits+TAB[TABCnt].CurWinUnit-1;
  TAB[TABCnt].CurWinUnit = 1;

 i=TAB[TABCnt].CurBufUnit;

  if (TABCnt==1) i--;


  StuffToWindow(TAB[TABCnt].WinNum,
		i,
		TAB[TABCnt].FileToWinNum);
  LightSel(TABCnt);
 }
 return 0;
}

//--------------------------------------------------------

int PageDown(void)
{
 int i;


 if (TAB[TABCnt].CurBufUnit+
   (TAB[TABCnt].MaxUnits-
    TAB[TABCnt].CurWinUnit)
    <=
    * (int *) TAB[TABCnt].MaxL)
 {
  UnLightSel(TABCnt);

  TAB[TABCnt].CurBufUnit+=TAB[TABCnt].MaxUnits-TAB[TABCnt].CurWinUnit+1;
  TAB[TABCnt].CurWinUnit =1;
  TAB[TABCnt].CursorX    =WinBound[TAB[TABCnt].WinNum].x1;
  TAB[TABCnt].CursorY    =WinBound[TAB[TABCnt].WinNum].y1;

  i=TAB[TABCnt].CurBufUnit;

  if (TABCnt==1) i--;

  StuffToWindow(TAB[TABCnt].WinNum,
		i,
		TAB[TABCnt].FileToWinNum);
  LightSel(TABCnt);
 }
 return 0;
}

//--------------------------------------------------------

void KeyInterface(void)
{
 BYTE 		ch;
 char 		Xit=0;
 int number;
 while (!Xit)
 {
 while (!kbhit())
 {
  ButtonHit=0;
  TrackTXTMouse();
  if (ButtonHit)
   CheckButtons();
 }

 ch = getch();
 if (ch==9 ) MoveTab();

 if (ch==27) {if (MCMode==_NORMAL) Xit=1;
		 if (MCMode==_EXTRACT) {
			   chdir(String);
			   strcpy(CurRoot, "xxxxxx");
			   GetCurRoot(CurRoot);
			   GetFiles();
			   MCMode=_NORMAL;
			   ClearSelectList();
			   OSGODScreenUp();
			   gotoxy(51,24); cprintf("%d", TFCnt);
			   ScreenInit();
			   }
	      }
 if (ch==13) ExecStuff();

 if (!ch)
  {
   ch = getch();
   if (ch==120) SetDrive(2);
   if (ch==121) SetDrive(1);

   if (ch==82) {
		if (TAB[TABCnt].WinNum==2)
		{
		AddFileToSelList();
		MoveCursor(2);
		}
	       }
   if (ch==83) {
		if (TAB[TABCnt].WinNum==3)
		RemoveFileFromSelList();
	       }

   if (ch==59) GoMake();
   if (ch==60) ViewFile();
   if (ch==62) {
		if (TAB[TABCnt].WinNum==3)
		{
		MoveTab();
		 }
		    TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
		    TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
		    TAB[1].CurBufUnit=0;
		    TAB[1].CurWinUnit=0;
		ClearWindow(4, 1);
		ClearSelectList();
	       }

   if (ch==63) DeleteFiles();

   if (ch==65) ExtractFiles();

   if (ch==66) ImportFiles();

   if (ch==67) { if (MCMode==_NORMAL) NormalExit();
		 if (MCMode==_EXTRACT) {
			   chdir(String);
			   strcpy(CurRoot, "xxxxxx");
			   GetCurRoot(CurRoot);
			   GetFiles();
			   MCMode=_NORMAL;
			   OSGODScreenUp();
			   gotoxy(51,24); cprintf("%d", TFCnt);
			   ScreenInit();
			   getch();
			   }
		}

   if (ch==72) MoveCursor(1);
   if (ch==80) MoveCursor(2);
   if (ch==75) MoveCursor(3);
   if (ch==77) MoveCursor(4);

   if (ch==73) PageUp();
   if (ch==81) PageDown();
  }
 }
}

//--------------------------------------------------------

void BeepError(void)
{
 sound(500); delay(100); nosound();
 sound(400); delay(100); nosound();
 sound(300); delay(100); nosound();
}

//--------------------------------------------------------

void BeepOk(void)
{
 sound(400); delay(100); nosound();
 sound(500); delay(100); nosound();
 sound(600); delay(100); nosound();
}

//--------------------------------------------------------

int AddFileToSelList(void)
{
  BYTE File[99];
  BYTE Len;
  BYTE T;

 if (MCMode==_NORMAL) if (TAB[TABCnt].CurBufUnit<=PrioCnt[3]) return 0;

 if (SelCnt<100)
 {
  strcpy(File, CurRoot);
  Len = strlen(File);

 if (File[Len-1]!=92) {File[Len]=92; File[Len+1]=0;}

  T=(SelCnt/TAB[1].MaxUnits)*TAB[1].MaxUnits;

  TAB[1].CurBufUnit++;
  TAB[1].CurWinUnit++;
  TAB[1].CursorY++;

  if (TAB[1].CursorY>WinBound[TAB[1].WinNum].y2+1)
  {
   TAB[1].CursorY=WinBound[TAB[1].WinNum].y1+1;
   TAB[1].CursorX+=13;

   if (TAB[1].CursorX+13>WinBound[TAB[1].WinNum].x2)
   {
    TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
   }
  }
   if (TAB[1].CurWinUnit>TAB[1].MaxUnits)
   {
    TAB[1].CurWinUnit=1;
    TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
    TAB[1].CursorY=WinBound[TAB[1].WinNum].y1;
   }
  strcat(File,
	 RetrieveFile(TAB[TABCnt].CurBufUnit));
  strcpy(
	 SelectList[SelCnt].FileName,
	 RetrieveFile(TAB[TABCnt].CurBufUnit));
  strcpy(FileList[SelCnt].FileName,
	 File);

  if (MCMode==_NORMAL) FileList[SelCnt].FileSize=GetFileSize(File);
  if (MCMode==_EXTRACT) {
			FileList[SelCnt].FileSize=CurrentMex.FileSize;
			FileList[SelCnt].FileOffset=CurrentMex.FileStart;
			}

  StuffToWindow(TAB[1].WinNum,
		T,
		TAB[1].FileToWinNum);
  SelCnt++;
 }
 else {SystemMessage("Max File Buffer Reached!", 1);}

 if (TAB[1].CursorY>WinBound[TAB[1].WinNum].y2)
 {
  TAB[1].CursorY=WinBound[TAB[1].WinNum].y1;
  TAB[1].CursorX+=13;

  if (TAB[1].CursorX+13>WinBound[TAB[1].WinNum].x2)
  {
   TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
  }
 }
 return 0;
}

//--------------------------------------------------------

void RemoveFileFromSelList(void)
{
 int i;
 if (SelCnt>0)
 {
  for (i=TAB[TABCnt].CurBufUnit-1; i<=SelCnt; i++)
  {
   strcpy(FileList[i].FileName,
	  FileList[i+1].FileName);
   strcpy(SelectList[i].FileName,
	  SelectList[i+1].FileName);
if (MCMode==_EXTRACT)
	{ FileList[i].FileSize=FileList[i+1].FileSize;
	  FileList[i].FileOffset=FileList[i+1].FileOffset;
	}
  }

  FileList[i-2].FileName[0]=0;
  SelectList[i-2].FileName[0]=0;

  SelCnt--;

  StuffToWindow(TAB[TABCnt].WinNum,
	       (TAB[TABCnt].CurBufUnit-1)-((TAB[TABCnt].CurWinUnit)-1),
		TAB[TABCnt].FileToWinNum);

  if (TAB[TABCnt].CurBufUnit>SelCnt)
  {
   TAB[TABCnt].CurWinUnit--;
   if ((TAB[TABCnt].CurWinUnit<1) && (SelCnt>=0))
   {
    TAB[TABCnt].CurWinUnit=1;
    PageUp();
   }
   else
   {
    TAB[TABCnt].CurBufUnit--;
    TAB[TABCnt].CursorY--;
    if (TAB[1].CursorY==WinBound[TAB[1].WinNum].y1-1)
    {
     if (TAB[1].CursorX!=WinBound[TAB[1].WinNum].x1)
     {
     TAB[1].CursorY+=TAB[TABCnt].UnitMaxY;
     TAB[1].CursorX-=13;
     }
    }
   }
  }
 LightSel(TABCnt);
 }
 if (SelCnt<=0) {MoveTab();
		 TAB[1].CurBufUnit--;
		 TAB[1].CurWinUnit--;
		 TAB[1].CursorY--;
		 UpdateFileInfo();
		 }
}

//--------------------------------------------------------

void MoveCursor(char Dire)
{
 char More=1;


 if (Dire==1)
   {

    UnLightSel(TABCnt);
   if (TABCnt==0)
   {
    if ((TAB[TABCnt].CurWinUnit==1) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y1))
       {
	 if (TAB[TABCnt].CurBufUnit!=1)
	 {TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
	  TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
	  TAB[TABCnt].CurWinUnit=1;//TAB[TABCnt].UnitMaxY;
	  TAB[TABCnt].CurBufUnit-=TAB[TABCnt].MaxUnits;
	  StuffToWindow(TAB[TABCnt].WinNum,
	    TAB[TABCnt].CurBufUnit,
	    TAB[TABCnt].FileToWinNum);
	 }
	  More=0;
       }

    } //major if

   if (TABCnt==1)
   {
    if ((TAB[TABCnt].CurWinUnit==1) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y1))
       {
	 if (TAB[TABCnt].CurBufUnit!=1)
	 {TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
	  TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
	  TAB[TABCnt].CurWinUnit=1; //=TAB[TABCnt].UnitMaxY;
	  TAB[TABCnt].CurBufUnit-=TAB[TABCnt].MaxUnits;
	  StuffToWindow(TAB[TABCnt].WinNum,
	    TAB[TABCnt].CurBufUnit-1,
	    TAB[TABCnt].FileToWinNum);
	 }
	  More=0;
	}
       } // major if
    if (More) {
    if ((TAB[TABCnt].CurWinUnit>1) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y1))

	{TAB[TABCnt].CursorY+=TAB[TABCnt].UnitMaxY-1;
	 TAB[TABCnt].CursorX-=TAB[TABCnt].UnitLn+1;
	 TAB[TABCnt].CurWinUnit--;
	 TAB[TABCnt].CurBufUnit--;
	} else {
    if ((TAB[TABCnt].CurWinUnit>1) &&
	(TAB[TABCnt].CursorY>WinBound[TAB[TABCnt].WinNum].y1))
	{TAB[TABCnt].CursorY--;
	 TAB[TABCnt].CurWinUnit--;
	 TAB[TABCnt].CurBufUnit--;
	}  }
     } //More
    LightSel(TABCnt);
   }

 if (Dire==2)
   {
    UnLightSel(TABCnt);
    if ((TAB[TABCnt].CurWinUnit==TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y2))
	{

	if (TABCnt==0)
	{
	if (TAB[TABCnt].CurBufUnit!= * (int *) TAB[TABCnt].MaxL)
	 {TAB[TABCnt].CurWinUnit=1;
	  TAB[TABCnt].CurBufUnit++;
	  TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
	  TAB[TABCnt].CursorY-=TAB[TABCnt].UnitMaxY-1;
	  StuffToWindow(TAB[TABCnt].WinNum,
			TAB[TABCnt].CurBufUnit,
			TAB[TABCnt].FileToWinNum);
	  More=0;
	 }
	} //major if
	if (TABCnt==1)
	{
	if (TAB[TABCnt].CurBufUnit!= * (int *) TAB[TABCnt].MaxL)
	 {TAB[TABCnt].CurWinUnit=1;
	  TAB[TABCnt].CurBufUnit++;
	  TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
	  TAB[TABCnt].CursorY-=TAB[TABCnt].UnitMaxY-1;
	  StuffToWindow(TAB[TABCnt].WinNum,
			TAB[TABCnt].CurBufUnit-1,
			TAB[TABCnt].FileToWinNum);
	  More=0;
	 }
	} //major if



       }
    if (More) {
    if ((TAB[TABCnt].CurWinUnit<TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY==WinBound[TAB[TABCnt].WinNum].y2))
	{if (TAB[TABCnt].CurBufUnit!= * (int *) TAB[TABCnt].MaxL)
	{TAB[TABCnt].CursorY-=TAB[TABCnt].UnitMaxY-1;
	 TAB[TABCnt].CursorX+=TAB[TABCnt].UnitLn+1;
	 TAB[TABCnt].CurWinUnit++;
	 TAB[TABCnt].CurBufUnit++;
	}}  else {
    if ((TAB[TABCnt].CurWinUnit<TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorY<WinBound[TAB[TABCnt].WinNum].y2))
	{if (TAB[TABCnt].CurBufUnit!=  * (int *) TAB[TABCnt].MaxL)
	{TAB[TABCnt].CursorY++;
	 TAB[TABCnt].CurWinUnit++;
	 TAB[TABCnt].CurBufUnit++;
	}}   }
     }
    LightSel(TABCnt);
   }
 if (Dire==3)
   {
    UnLightSel(TABCnt);
    if ((TAB[TABCnt].CurWinUnit!=1) &&
	(TAB[TABCnt].CursorX!=WinBound[TAB[TABCnt].WinNum].x1))
	 {
	  TAB[TABCnt].CursorX-=TAB[TABCnt].UnitLn+1;
	  TAB[TABCnt].CurWinUnit-=TAB[TABCnt].UnitMaxY;
	  TAB[TABCnt].CurBufUnit-=TAB[TABCnt].UnitMaxY;
	}
    LightSel(TABCnt);
   }
 if (Dire==4)
   {
    UnLightSel(TABCnt);
    if ((TAB[TABCnt].CurWinUnit!=TAB[TABCnt].MaxUnits) &&
	(TAB[TABCnt].CursorX+TAB[TABCnt].UnitLn+1<WinBound[TAB[TABCnt].WinNum].x2-TAB[TABCnt].UnitLn+1))
	{if (TAB[TABCnt].CurBufUnit+TAB[TABCnt].UnitMaxY<= * (int *) TAB[TABCnt].MaxL)
	 {
	  TAB[TABCnt].CursorX+=TAB[TABCnt].UnitLn+1;
	  TAB[TABCnt].CurWinUnit+=TAB[TABCnt].UnitMaxY;
	  TAB[TABCnt].CurBufUnit+=TAB[TABCnt].UnitMaxY;
	 }
	}
    LightSel(TABCnt);
   }
 if ((TABCnt!=FA_DIREC) && (TABCnt!=FA_HIDDEN+FA_DIREC)) UpdateFileInfo();
}

//--------------------------------------------------------

void ResetTab(char TABCnt)
{
 TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
 TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
 TAB[TABCnt].CurWinUnit=1;
 TAB[TABCnt].CurBufUnit=1;
}

//--------------------------------------------------------

void ResetCursor(int TABCnt)
{
 TAB[TABCnt].CursorX=WinBound[TAB[TABCnt].WinNum].x1;
 TAB[TABCnt].CursorY=WinBound[TAB[TABCnt].WinNum].y1;
}

//--------------------------------------------------------

void UnLightSel(int TABCnt)
{
 BYTE Tmp[MAXDIR];
 BYTE Color;
 int Dl, DCnt, Ds, D;
 Tmp[0]=0x0;
 String="xxxxxxx";
 textbackground(1);
if (TAB[TABCnt].WinNum==2)
{
 D = TAB[TABCnt].CurBufUnit;
 if (TABCnt==0) String = RetrieveFile(D);

 if  (D<=PrioCnt[3]) 			       Color=15;
 if ((D>PrioCnt[3]) && (D<=PrioCnt[4])) Color=10;
 if ((D>PrioCnt[4]) && (D<=PrioCnt[8])) Color=8;
 if ((D>PrioCnt[8]) && (D<=PrioCnt[15])) Color=14;
 if  (D>PrioCnt[15]) 			       Color=12;

 textcolor(Color);
 gotoxy(TAB[TABCnt].CursorX, TAB[TABCnt].CursorY);
 cprintf("%s", String);
 textbackground(1); textcolor(15);
}

if (TAB[TABCnt].WinNum==3)
{
 textbackground(1); textcolor(12);
 D = TAB[TABCnt].CurBufUnit;
 gotoxy(TAB[TABCnt].CursorX, TAB[TABCnt].CursorY);
 cprintf("%s", SelectList[D-1].FileName);
 textbackground(1); textcolor(15);
}
}

//--------------------------------------------------------

void LightSel(int TABCnt)
{
 BYTE Tmp[MAXDIR];
 int D; //l, DCnt, Ds, D;
 String="xxxxxx";
 Tmp[0]=0x0;
if (TAB[TABCnt].WinNum==2)
{
 textbackground(7); textcolor(1);
 if (TABCnt==0) String = RetrieveFile(TAB[TABCnt].CurBufUnit);
 gotoxy(TAB[TABCnt].CursorX, TAB[TABCnt].CursorY);
 cprintf("%s", String);
 textbackground(1); textcolor(15);
}
if (TAB[TABCnt].WinNum==3)
{
 textbackground(7); textcolor(1);
 D = TAB[TABCnt].CurBufUnit;
 gotoxy(TAB[TABCnt].CursorX, (TAB[TABCnt].CursorY));
 cprintf("%s", SelectList[D-1].FileName);
 textbackground(1); textcolor(15);
}
}

//--------------------------------------------------------

void ExecStuff()
{
 int D;
 if (TABCnt==0)
 {
  D = TAB[TABCnt].CurBufUnit;

 if  (D<=PrioCnt[3])
  {
   chdir(String);
   strcpy(CurRoot, "xxxxxx");
   GetCurRoot(CurRoot);
   GetFiles(); D=0;
  }

 if ((D>PrioCnt[3]) && (D<=PrioCnt[4]))
  {
   GetExt(Ext);
   if (strcmp(Ext, "EXE")==0)
   {
    textbackground(0); clrscr();

    strcpy(argv0, String);

    if ((spawnl(P_WAIT, String,(void *) argv0, NULL))!=0)
     {
      getch();
     }

    OSGODScreenUp();
    gotoxy(51,24); cprintf("%d", TFCnt);
   }
   else
   {
    CheckPresetExt(Ext);
   }
  }

 if ((D>PrioCnt[3]) && (D<=PrioCnt[4])) {}
 if ((D>PrioCnt[4]) && (D<=PrioCnt[5])) {}
 if  (D>PrioCnt[4]) 			{}

  gotoxy(51,24); cprintf("    ", TFCnt);
  gotoxy(51,24); cprintf("%d", TFCnt);
  ScreenInit();}
}

//--------------------------------------------------------

BYTE *GetCurRoot(DIRBYTE path)
{
   strcpy(path, PreDir);
   path[0] = 'A' + getdisk();
   getcurdir(0, path+3);
   return(path);
}

//--------------------------------------------------------

BYTE *GetExt(BYTE *Ext)
{
 int Le;
 int C; char CD;
 BYTE SPos;
 BYTE Tmp[13];
 Le = strlen(String);
 SPos = strchr(String, '.')-String;
 if ((int) SPos<Le)
 {
 strcpy(Tmp, String);
 CD=0;
 for (C=SPos+1; C<=Le-1; C++)
 {
  Ext[CD]=String[C];
  CD++;
 }
 Ext[CD]=0x0;
 }
 return Ext;
}

//--------------------------------------------------------

int SetDrive(char D)
{
 int Avail;
 char buffer[512];
 int number;
 int Dr;
 FILE *F;
 Dr=getdisk();


 if (D==1) {if (DriveCnt<26) { DriveCnt++;
			       setdisk(DriveCnt);

//			       result = _chdrive(DriveCnt+3);
//			     if (result) {DriveCnt--; setdisk(DriveCnt); return 1;}
			      setdisk(DriveCnt);
			      if (DriveCnt==getdisk()) {
				strcpy(CurRoot, "xxxxxx");
				GetCurRoot(CurRoot);
				GetFiles();
				OSGODScreenUp();
				gotoxy(51,24); cprintf("%d", TFCnt);
				ScreenInit();
				}
			       else {setdisk(Dr); DriveCnt--;}
			      }
	   }
 if (D==2) {if (DriveCnt>2) { DriveCnt--;
			      setdisk(DriveCnt);
			      if (DriveCnt==getdisk()) {
				strcpy(CurRoot, "xxxxxx");
				GetCurRoot(CurRoot);
				GetFiles();
				OSGODScreenUp();
				gotoxy(51,24); cprintf("%d", TFCnt);
				ScreenInit();
				}
			       else {setdisk(Dr); DriveCnt++;}
			      }
	      }
 return 0;
}

//--------------------------------------------------------

void ClearExtStruct(int E)
{
 int C;
 for (C=0; C<=3; C++) ExtAss[E].Ext[C]=0x0;
 for (C=0; C<=MAXDIR; C++) ExtAss[E].AsPath[C]=0x0;
}

//--------------------------------------------------------

void ViewFile(void)
{
  BYTE File[90];
  delay(50);
  DrawButton(0, FALSE);
  strcpy(File, RetrieveFile(TAB[TABCnt].CurBufUnit));
  strcpy(argv0, (BYTE * ) MainView);
  strcpy(argv1, (BYTE *) File);
  strcpy(File, OSGODRoot);
  strcat(File, "mcview.exe");
  if (MCMode==_NORMAL) {
  if ((spawnl(P_WAIT, MainView, (void *) argv0, (void *) argv1, NULL))!=0) {Terminate(15); getch();}
  }
  if (MCMode==_EXTRACT) {
  ltoa(CurrentMex.FileStart,argv0, 10);
  ltoa(CurrentMex.FileEnd,argv1, 10);
  if ((spawnl(P_WAIT, File, File, ExtFile, (void *) argv0, (void *) argv1, CurrentMex.Filename, NULL))!=0) { Terminate(15); getch();}
  }
  OSGODScreenUp();
  gotoxy(51,24); cprintf("%d", TFCnt);
  ScreenInit();
}

//--------------------------------------------------------


void CheckPresetExt(EXTBYTE Ext)
{
 char E=0; char A;
 int B;
 BYTE File[90];
 while (E<=ExtCnt)
 {
  if ((strcmp(Ext, ExtAss[E].Ext))==0) {A=E; E=50;}
  else {E++;}
 }
 if (E==50)
 {
  textbackground(0); clrscr();
  strcpy(argv0, ExtAss[A].AsPath);
  strcpy(argv1, CurRoot);
  strcat(argv1, "\\");
  strcat(argv1, String);
  argc=2;
  if ((spawnl(P_WAIT, ExtAss[A].AsPath, (void *) argv0, (void *) argv1, NULL))!=0)
   {
    printf("%s\n",argv0);
    printf("%s\n",argv1);
    getch();
    Terminate(15); getch();}
  OSGODScreenUp();
  gotoxy(51,24); cprintf("%d", TFCnt);
 }
 else {
  argv0[0]=0;
  argv1[0]=0;
  strcpy(argv0, OSGODRoot);
  strcpy(File, OSGODRoot);
  strcat(File, "\\");
  strcat(File, "multiex.exe");
  strcpy(argv1, CurRoot);
  strcat(argv1, "\\");
  strcat(argv1, String);
  textbackground(0);
  textcolor(7);
  clrscr();
  B=spawnl(P_WAIT, File, (void *) argv0, (void *) argv1, "-l", NULL);
  if (B!=0)
  {
   strcpy(argv0, "MultiEx returned error:");
   itoa(B, argv1, 10);
   strcat(argv0, argv1);
   SystemMessage(argv0, 1);
  }
  else {
   strcpy(ExtFile, argv1);
   ConvertLSTtoTEMP();
   ClearPrioCnts();
   MCMode=_EXTRACT;
  }
 }
 OSGODScreenUp();
  gotoxy(51,24); cprintf("%d", TFCnt);
}

int ClearPrioCnts(void)
{
 int i;
 for (i=0; i<=18; i++)
 {
  PrioCnt[i]=0;
 }
 return 0;
}
int SetDefaultPrioCnts(void)
{
 PrioList[0]=FA_DIREC;
 PrioList[1]=FA_DIREC+FA_HIDDEN;
 PrioList[2]=FA_DIREC+FA_RDONLY;
 PrioList[3]=FA_DIREC+FA_ARCH;
 PrioList[4]=FA_ARCH;
 PrioList[5]=FA_HIDDEN;
 PrioList[6]=FA_SYSTEM;
 PrioList[7]=FA_RDONLY;
 PrioList[8]=0;
 PrioList[9]=FA_ARCH+FA_RDONLY;
 PrioList[10]=FA_ARCH+FA_HIDDEN;
 PrioList[11]=FA_ARCH+FA_SYSTEM;
 PrioList[12]=FA_ARCH+FA_SYSTEM+FA_HIDDEN;
 PrioList[13]=FA_ARCH+FA_SYSTEM+FA_RDONLY;
 PrioList[14]=FA_ARCH+FA_HIDDEN+FA_RDONLY;
 PrioList[15]=FA_HIDDEN+FA_SYSTEM+FA_RDONLY;
 PrioList[16]=FA_HIDDEN+FA_SYSTEM;
 PrioList[17]=FA_HIDDEN+FA_RDONLY;
 return 0;
}
//--------------------------------------------------------

int ConvertLSTtoTEMP(void)
{
 FILE *F;
 FILE *F2;
 BYTE Name[20];
 long Size;
 int Re,H;
 unsigned B;
 int Cnt;
// Name[19]=0x13;
 Size = GetFileSize("multiex.lst");
 FileCnt=0;
 FileCnt=Size / 26;
 PrioCnt[0]=FileCnt;
 PrioCnt[1]=0;
 PrioCnt[2]=0;
 PrioCnt[3]=0;
 for (Re=4; Re<=17; Re++) PrioCnt[Re]=FileCnt;
  _dos_open("multiex.lst", O_RDWR, &H);
 F2= fopen(FileFile, "w+");
 for (Cnt=0; Cnt<FileCnt; Cnt++)
 {
  _dos_read(H, Name, 18, &B);
  strcat(Name, "\n");
  fputs(Name, F2);
  _dos_read(H, Name, 8, &B);
 }
 _dos_close(H);
 fclose(F2);
 return 0;
}

//--------------------------------------------------------

long GetMEFileSize(int Number)
{
 int H;
 FILE *F;
 long Start, End ;
 long Size;
 long skip;
 Size=0;
 skip=26*((long) Number-1)+18;
 F= fopen("multiex.lst", "r");
 fseek(F, skip, SEEK_SET);
 fread(&Start, 4, 1, F);
 fread(&End, 4, 1, F);
 CurrentMex.FileStart=Start;
 CurrentMex.FileEnd=End;
 Size=End-Start;
 CurrentMex.FileSize=Size;
 fclose(F);
 return Size;
}


//--------------------------------------------------------

void CreateButtons(void)
{
 Button[0].ButtonX1=71;
 Button[0].ButtonY1=3;
 Button[0].ButtonX2=78;
 Button[0].ButtonY2=3;
 Button[0].Attrib=FALSE;
 Button[0].ButtonColor=7;
 Button[0].ButtonTXTColor=15;
 Button[0].ButtonBKColor=1;
 Button[0].ButtonBKTxtColor=0;
 strcpy(Button[0].ButtonText, "F1:Start");
 Button[1].ButtonX1=71;
 Button[1].ButtonY1=5;
 Button[1].ButtonX2=78;
 Button[1].ButtonY2=5;
 Button[1].Attrib=FALSE;
 Button[1].ButtonColor=7;
 Button[1].ButtonTXTColor=15;
 Button[1].ButtonBKColor=1;
 Button[1].ButtonBKTxtColor=0;
 strcpy(Button[1].ButtonText, "F2:View");
 Button[2].ButtonX1=71;
 Button[2].ButtonY1=7;
 Button[2].ButtonX2=78;
 Button[2].ButtonY2=7;
 Button[2].Attrib=FALSE;
 Button[2].ButtonColor=7;
 Button[2].ButtonTXTColor=15;
 Button[2].ButtonBKColor=1;
 Button[2].ButtonBKTxtColor=0;
 strcpy(Button[2].ButtonText, "F3:Edit");
 Button[3].ButtonX1=71;
 Button[3].ButtonY1=9;
 Button[3].ButtonX2=78;
 Button[3].ButtonY2=9;
 Button[3].Attrib=FALSE;
 Button[3].ButtonColor=7;
 Button[3].ButtonTXTColor=15;
 Button[3].ButtonBKColor=1;
 Button[3].ButtonBKTxtColor=0;
 strcpy(Button[3].ButtonText, "F4:ClrA");
 Button[4].ButtonX1=71;
 Button[4].ButtonY1=11;
 Button[4].ButtonX2=78;
 Button[4].ButtonY2=11;
 Button[4].Attrib=FALSE;
 Button[4].ButtonColor=7;
 Button[4].ButtonTXTColor=15;
 Button[4].ButtonBKColor=1;
 Button[4].ButtonBKTxtColor=0;
 strcpy(Button[4].ButtonText, "F5:Del");
 Button[5].ButtonX1=71;
 Button[5].ButtonY1=13;
 Button[5].ButtonX2=78;
 Button[5].ButtonY2=13;
 Button[5].Attrib=FALSE;
 Button[5].ButtonColor=7;
 Button[5].ButtonTXTColor=15;
 Button[5].ButtonBKColor=1;
 Button[5].ButtonBKTxtColor=0;
 strcpy(Button[5].ButtonText, "F6:Move");
 Button[6].ButtonX1=71;
 Button[6].ButtonY1=15;
 Button[6].ButtonX2=78;
 Button[6].ButtonY2=15;
 Button[6].Attrib=FALSE;
 Button[6].ButtonColor=7;
 Button[6].ButtonTXTColor=15;
 Button[6].ButtonBKColor=1;
 Button[6].ButtonBKTxtColor=0;
 strcpy(Button[6].ButtonText, "F7:Extr");
 Button[7].ButtonX1=71;
 Button[7].ButtonY1=17;
 Button[7].ButtonX2=78;
 Button[7].ButtonY2=17;
 Button[7].Attrib=FALSE;
 Button[7].ButtonColor=7;
 Button[7].ButtonTXTColor=15;
 Button[7].ButtonBKColor=1;
 Button[7].ButtonBKTxtColor=0;
 strcpy(Button[7].ButtonText, "F8:Impt");
 Button[8].ButtonX1=71;
 Button[8].ButtonY1=19;
 Button[8].ButtonX2=78;
 Button[8].ButtonY2=19;
 Button[8].Attrib=FALSE;
 Button[8].ButtonColor=7;
 Button[8].ButtonTXTColor=15;
 Button[8].ButtonBKColor=1;
 Button[8].ButtonBKTxtColor=0;
 strcpy(Button[8].ButtonText, "F9:Exit");
}

//--------------------------------------------------------

void DrawTXTBlock(BYTE ch, int x, int y, int W, int L)
{
 int xx, yy;
 for (yy=y; yy<=y+L; yy++)
 {
 for (xx=x; xx<=x+W; xx++)
 {gotoxy(xx, y); cprintf("%c", ch);
 }
 }
}

//--------------------------------------------------------

void DrawButton(int But, BYTE Pressed)
{
 int x, y;

 if (!Pressed)
 {
 Button[But].Attrib=Pressed;
 textcolor(Button[But].ButtonColor);
 DrawTXTBlock(219, Button[But].ButtonX1, Button[But].ButtonY1,
		  Button[But].ButtonX2-Button[But].ButtonX1,
		  Button[But].ButtonY2-Button[But].ButtonY1
		  );
 gotoxy(Button[But].ButtonX1, Button[But].ButtonY1);
 textcolor(Button[But].ButtonTXTColor);
 textbackground(Button[But].ButtonColor);
 cprintf("%s", Button[But].ButtonText);
 }
 if (Pressed)
 {
 Button[But].Attrib=Pressed;
 textcolor(Button[But].ButtonBKColor);
 DrawTXTBlock(219, Button[But].ButtonX1, Button[But].ButtonY1,
		  Button[But].ButtonX2-Button[But].ButtonX1,
		  Button[But].ButtonY2-Button[But].ButtonY1
		  );
 gotoxy(Button[But].ButtonX1, Button[But].ButtonY1);
 textcolor(Button[But].ButtonBKTxtColor);
 textbackground(Button[But].ButtonBKColor);
 cprintf("%s", Button[But].ButtonText);
 }
}

//--------------------------------------------------------

int GoMake(void)
{
  BYTE *DatFile;

  if (MCMode==_EXTRACT) {SystemMessage("Not In Make-Mode", 1); return 0;}

  DrawButton(0, FALSE);

  if (TABCnt==1) MoveTab();

  if (SelCnt>0)
  {

  DatFile = SystemRequest("DAT File Output Name:", 3, 67);

  if (StartCreatingDATFile(DatFile, SelCnt))
  {
   SystemMessage("Unable to create DATfile", 1);
   ResetTab(1);
  }
  else
  {
   SystemMessage("DATFile Completed!", 2);
   ClearWindow(3, 1);
   ClearSelectList();
   ResetMessWindow(4);
   TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
   TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
   TAB[1].CurWinUnit=0;
   TAB[1].CurBufUnit=0;
   SelCnt=0;



//   TAB[1].CursorY--;
  }

  }
  else { SystemMessage("No Files Selected!", 1); }

  return 0;
}

//--------------------------------------------------------

int CheckButtons(void)
{
 if (ButtonHit==1) GoMake();

 if (ButtonHit==2) ViewFile();

 if (ButtonHit==4) {
		   if (TAB[TABCnt].WinNum==3)
		   {
		   MoveTab();
		   }
		    TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
		    TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
		    TAB[1].CurBufUnit=0;
		    TAB[1].CurWinUnit=0;
		   ClearWindow(4, 1);
		   ClearSelectList();
		   }
 if (ButtonHit==5) DeleteFiles();

 if (ButtonHit==7) ExtractFiles();

 if (ButtonHit==8) ImportFiles();

 if (ButtonHit==9) NormalExit();

 return 0;
}

//--------------------------------------------------------

int MouseLeft(void)
{
 if (CheckTXTMouseArea(Button[0].ButtonX1,
		     Button[0].ButtonY1,
		     Button[0].ButtonX2,
		     Button[0].ButtonY2) == TRUE) {
		     ButtonHit=1;
		     if (Button[0].Attrib==FALSE)
		     DrawButton(0, TRUE); }
 if (CheckTXTMouseArea(Button[1].ButtonX1,
		     Button[1].ButtonY1,
		     Button[1].ButtonX2,
		     Button[1].ButtonY2) == TRUE) {
		     ButtonHit=2;
		     DrawButton(1, TRUE);}
 if (CheckTXTMouseArea(Button[2].ButtonX1,
		     Button[2].ButtonY1,
		     Button[2].ButtonX2,
		     Button[2].ButtonY2) == TRUE) {
		     ButtonHit=3;
		     DrawButton(2, TRUE);}
 if (CheckTXTMouseArea(Button[3].ButtonX1,
		     Button[3].ButtonY1,
		     Button[3].ButtonX2,
		     Button[3].ButtonY2) == TRUE) {
		     ButtonHit=4;
		     DrawButton(3, TRUE);}
 if (CheckTXTMouseArea(Button[4].ButtonX1,
		     Button[4].ButtonY1,
		     Button[4].ButtonX2,
		     Button[4].ButtonY2) == TRUE) {
		     ButtonHit=5;
		     DrawButton(4, TRUE);}
 if (CheckTXTMouseArea(Button[5].ButtonX1,
		     Button[5].ButtonY1,
		     Button[5].ButtonX2,
		     Button[5].ButtonY2) == TRUE) {
		     ButtonHit=6;
		     DrawButton(5, TRUE);}
 if (CheckTXTMouseArea(Button[6].ButtonX1,
		     Button[6].ButtonY1,
		     Button[6].ButtonX2,
		     Button[6].ButtonY2) == TRUE) {
		     ButtonHit=7;
		     DrawButton(6, TRUE);}
 if (CheckTXTMouseArea(Button[7].ButtonX1,
		     Button[7].ButtonY1,
		     Button[7].ButtonX2,
		     Button[7].ButtonY2) == TRUE) {
		     ButtonHit=8;
		     DrawButton(7, TRUE);}
 if (CheckTXTMouseArea(Button[8].ButtonX1,
		     Button[8].ButtonY1,
		     Button[8].ButtonX2,
		     Button[8].ButtonY2) == TRUE) {
		     ButtonHit=9;
		     DrawButton(8, TRUE);}
 return 0;
}

//--------------------------------------------------------

void DrawButtons(void)
{
 DrawButton(0, FALSE);
 DrawButton(1, FALSE);
 DrawButton(2, FALSE);
 DrawButton(3, FALSE);
 DrawButton(4, FALSE);
 DrawButton(5, FALSE);
 DrawButton(6, FALSE);
 DrawButton(7, FALSE);
 DrawButton(8, FALSE);
}

//--------------------------------------------------------

void NormalExit(void)
{
 textbackground(0);
 textcolor(7);
 clrscr();
 HideMouse();
 ResetMouse();
 _setcursortype(_NORMALCURSOR);
 exit(1);
}

//--------------------------------------------------------

int ImportFiles(void)
{
 int i;
 int Err=0;
 BYTE File[90];
 BYTE *DatFile;
 BYTE ImpFile[90];

 DrawButton(7, FALSE);

 if (SelCnt>0)
 {
  DatFile =  SystemRequest("Import Files into:", 3, 67);

  SystemMessage("Switching to Multiex...", 2);

  _setcursortype(0);
  textbackground(0);
  clrscr();

  i=0;

 while ((i<=SelCnt-1) && (!Err))
 {
  argv0[0]=0;
  argv1[0]=0;
  strcpy(argv0, OSGODRoot);
  strcpy(File, OSGODRoot);
  strcat(File, "\\");
  strcat(File, "multiex.exe");
  strcpy(argv1, "-all");
//  strcat(argv1, "\\");
//  strcat(argv1, String);*/

  strcpy(ImpFile, "-i");
  strcat(ImpFile, SelectList[i].FileName);
  Err=spawnl(P_WAIT, File, (void *) argv0, (void *) DatFile, ImpFile, argv1, NULL);
  if (Err)
   {
     OSGODScreenUp();
     ScreenInit();
     gotoxy(51,24); cprintf("%d", TFCnt);
    strcpy(argv0, "MultiEx returned error:");
    itoa(Err, argv1, 10);
    strcat(argv0, argv1);
    SystemMessage(argv0, 1);
   }
  i++;
  }
  if (!Err)
   {
     ClearSelectList();
     ResetMessWindow(4);
     TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
     TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
     TAB[1].CurWinUnit=0;
     TAB[1].CurBufUnit=0;
     SelCnt=0;
     OSGODScreenUp();
     ScreenInit();
     gotoxy(51,24); cprintf("%d", TFCnt);
     SystemMessage("All Files Imported!", 2);
    }

 }
 else { SystemMessage("No Files Selected!", 1); }


 return 0;
}

//--------------------------------------------------------

int DeleteFiles(void)
{
  BYTE Mess[90];
  BYTE *Temp;
  BYTE Prompt=1;
  int i;

  DrawButton(4, FALSE);


  if (MCMode==_EXTRACT) {SystemMessage("Not In Normal Mode", 1); return 0;}
  if (TABCnt==1) MoveTab();

  if (SelCnt>0)
  {
    Prompt = DelFiles(SelCnt);
    if (Prompt==2) {SystemMessage("Unable To Delete File!", 1); return 0;}
    if (!Prompt)
    {
     ClearWindow(3, 1);
     ClearSelectList();
     ResetMessWindow(4);
     TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
     TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
     TAB[1].CurWinUnit=0;
     TAB[1].CurBufUnit=0;
     SystemMessage("All Files Deleted!", 2);
    }
    SelCnt=0;
    ReturnAndReset();
 }
 else { SystemMessage("No Files Selected!", 1); }

 return 0;
}

//--------------------------------------------------------


int ExtractFiles(void)
{
  BYTE *ExtractDir;
  DrawButton(6, FALSE);

  if (MCMode==_NORMAL) {SystemMessage("Not In Extract-Mode", 1); return 0;}


  if (TABCnt==1) MoveTab();

 if (SelCnt>0)
 {

  ExtractDir = SystemRequest("Extract to Directory:", 3, 67);



  if (StartExtractingDATFile(ExtractDir, ExtFile, SelCnt))
  {
   SystemMessage("Unable to open DATfile", 1);
   ResetTab(1);
  }
  else
  {
   SystemMessage("All Files Extracted!", 2);
   ClearWindow(3, 1);
   ClearSelectList();
   ResetMessWindow(4);
   TAB[1].CursorX=WinBound[TAB[1].WinNum].x1;
   TAB[1].CursorY=WinBound[TAB[1].WinNum].y1-1;
   TAB[1].CurWinUnit=0;
   TAB[1].CurBufUnit=0;
   SelCnt=0;
//   TAB[1].CursorY--;
  }

  }
  else { SystemMessage("No Files Selected!", 1); }

  return 0;
}
//--------------------------------------------------------

BYTE *ReducePath(BYTE *F, BYTE Num)
{
 BYTE New[90];
 BYTE t, a, b, d;
 BYTE Xit=0;
 int l;
 l = strlen(F);
 t=l; a=0; b=0; d=0;
 if (l<=Num) return F;
 l-=2;
 while (l>0)
 {
  if (F[l]=='\\')
  {
   l--; b=l;

   while (t-(d)>Num)
   {
    while ((F[l]!='\\') && (!Xit))
    {
     a=l;
     l--; if (l<0) Xit=1;
    }
    d=b-a-3;
   Xit=0; l--;
   }

  }
  if (t-(d)<=Num) l=0;
  l--;
 }
 strncpy(New, F, a);
 New[a]=0;
 strcat(New, "...");
 strcat(New, &F[b+1]);
 return New;
}
int test(void)
{
  struct find_t ffblk;
  int done;
  BYTE B[80];
  BYTE *buf;
  int handle, bytes;

  buf = (BYTE *) malloc(200);

/*
   Create a file name TEST.$$$ in the current directory and writes
   200 bytes to it. If TEST.$$$ already exists, it's overwritten.
*/

if ((handle = _open("TEST.$$$", O_CREAT | O_WRONLY | O_BINARY)) == -1)
{
   printf("Error Opening File\n");
   exit(1);
}

if ((bytes = _write(handle, buf, 200)) == -1) {
   printf("Write Failed.\n");
   exit(1);
}
printf("_write: %d bytes written.\n",bytes);

 _close(handle);
if ((handle = _open("TEST.$$$", O_APPEND | O_RDWR | O_BINARY))==-1)
  { printf("Write Failed.\n"); exit(1); }


  memset(buf, 255,200);
if ((bytes = _write(handle, buf, 200)) == -1) {
   printf("Write Failed.\n");
   exit(1);
}
printf("_write: %d bytes written.\n",bytes);
_close(handle);

  return 0;
}

int main()//(int argc, BYTE *argv[1])
{
//   test();
//   exit(0);

   clrscr();
   Init();
   if (!CheckMouse())
     {SystemMessage("No Mouse Installed!", 1);
     }
   CreateButtons();
   InitTxtMouse();
   ShowMouse();
   AsnFnctToMseAct(MouseLeft, MOUSE_LEFT);
   SystemMessage("Multiex Commander v1.07", 2);
   KeyInterface();
   NormalExit();
   textbackground(0);
   clrscr();
   return 0;
}




