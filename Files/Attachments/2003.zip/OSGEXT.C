#include <string.h>
#include <dos.h>
#include <stdio.h>
#include <dir.h>
#include <process.h>
#include <conio.h>
#include <setjmp.h>
typedef 	unsigned char BYTE;
typedef 	struct {int WNum;
			BYTE TXT[30];
			int WinX; int WinY;
			char LColor; char DColor;} ButtonType;
typedef		struct {
			char FileAs;
			BYTE File[66];
			int x1;	int y1;
			int x2;	int y2;
			int ButtonCnt;
			char InColor;
			char OutColor;
			BYTE Title[30];
		       } WinType;

char		OldBuf[4096];
BYTE		Xit;
ButtonType	Buttons[9];
WinType		Windows[3];
BYTE		WinOn;
int		ActiveWin;

void MakeWindow(int WNum, int x1, int y1, int x2, int y2, int ButtonCnt, char LColor, char DColor, BYTE Title[30]);
void MakeButton(int BNum, int WNum, int WinX, int WinY, char LColor, char DColor, BYTE TXT[30]);
void PlaceWindow(int WNum);
void RemoveWindow(int WNum);
void PlaceButtons(int WNum);
void SetWinAsFile(int WNum, BYTE FName[66]);
void ClearWindow(int WNum);
void SetActiveWin(int WNum);

void MakeWindow(int Wnum, int x1, int y1, int x2, int y2, int ButtonCnt, char LColor, char DColor, BYTE Title[30])
{
Windows[Wnum].x1=x1;
Windows[Wnum].y1=y1;
Windows[Wnum].x2=x2;
Windows[Wnum].y2=y2;
Windows[Wnum].ButtonCnt=ButtonCnt;
Windows[Wnum].InColor=LColor;
Windows[Wnum].OutColor=DColor;
strcpy(Windows[Wnum].Title, Title);
}

void MakeButton(int BNum, int WNum, int WinX, int WinY, char LColor, char DColor, BYTE TXT[30])
{
 Buttons[BNum].WNum=WNum;
 Buttons[BNum].WinX=WinX;
 Buttons[BNum].WinY=WinY;
 Buttons[BNum].LColor=LColor;
 Buttons[BNum].DColor=DColor;
 strcpy(Buttons[BNum].TXT, TXT);
}

void PlaceWindow(int WNum)
{
 int x, y;
 int BNum;
 WinOn=WNum;
 gettext(Windows[WNum].x1, Windows[WNum].y1, Windows[WNum].x2+1, Windows[WNum].y2+1, OldBuf);
 textcolor(15); textbackground(Windows[WNum].OutColor);
 for (x=Windows[WNum].x1; x<=Windows[WNum].x2; x++) {gotoxy(x, Windows[WNum].y1); cprintf("�");
						     gotoxy(x, Windows[WNum].y2); cprintf("�");}
 for (y=Windows[WNum].y1; y<=Windows[WNum].y2; y++) {gotoxy(Windows[WNum].x1, y); cprintf("�");
						     gotoxy(Windows[WNum].x2, y); cprintf("�");}
 gotoxy(Windows[WNum].x1+1,Windows[WNum].y1);
 cprintf("%s", Windows[WNum].Title);
 textbackground(0);
 for (x=Windows[WNum].x1+1; x<=Windows[WNum].x2+1; x++) {gotoxy(x, Windows[WNum].y2+1); cprintf(" ");}
 for (y=Windows[WNum].y1+1; x<=Windows[WNum].y2; y++) {gotoxy(Windows[WNum].x2+1, y); cprintf(" ");}
 textcolor(15); textbackground(Windows[WNum].InColor);
 for (y=Windows[WNum].y1+1; y<=Windows[WNum].y2-1; y++)
 {
  for (x=Windows[WNum].x1+1; x<=Windows[WNum].x2-1; x++)
  {
   gotoxy(x,y); cprintf(" ");
  }
 }
 for (BNum=1; BNum<=Windows[WNum].ButtonCnt; BNum++)
 {
  textcolor(15); textbackground(Buttons[BNum].DColor);
  gotoxy(Windows[WNum].x1+Buttons[BNum].WinX,Windows[WNum].y1+Buttons[BNum].WinY);
  cprintf("%s", Buttons[BNum].TXT);
 }
}

void RemoveWindow(int WNum)
{
 if (WNum==WinOn)
 {
 puttext(Windows[WNum].x1, Windows[WNum].y1, Windows[WNum].x2+1, Windows[WNum].y2+1, OldBuf);
 }
}

void SetWinAsFile(int WNum, BYTE FName[66])
{
 Windows[WNum].FileAs=1;
 strcpy(Windows[WNum].File, FName);
}

void ClearWindow(int WNum)
{
 int x, y;
 textcolor(15); textbackground(Windows[WNum].InColor);
 for (y=Windows[WNum].y1+1; y<=Windows[WNum].y2-1; y++)
 {
  for (x=Windows[WNum].x1+1; x<=Windows[WNum].x2-1; x++)
  {
   gotoxy(x,y); cprintf(" ");
  }
 }
}

void SetActiveWin(int WNum)
{
 if (ActiveWin>-1) RemoveWindow(ActiveWin);
 ActiveWin=WNum;
 PlaceWindow(ActiveWin);
}

int main(void)
{
 _setcursortype(_NOCURSOR);
 Xit=0;
 ActiveWin=-1;
 MakeWindow(0, 25, 5, 55, 15,0, 8, 3, "FileAssociated EXTensions");
 MakeButton(0, 1, 2, 8, 15, 12, "INSERT");
 MakeButton(1, 1, 9, 8, 15, 12, "DELETE");

 SetActiveWin(0);
 getch();
 RemoveWindow(0);
 getch();
 _setcursortype(_NORMALCURSOR);
 return 0;
}


