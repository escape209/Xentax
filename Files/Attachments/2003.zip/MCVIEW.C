// mcview, viewer used by Multiex Commander
// Special Ability: uses command line given start and end offsets in any file
// and shows that particular piece.

#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include  <stdlib.h>
#include <string.h>
#include "mcview.h"
#include <fcntl.h>

FileInfo	MainFile;
FileInfo	PackedFile;
long		ViewStart;
long		ViewEnd;
BYTE 		Wrap=0;
BYTE		Buffer[21*80];
#pragma inline

int ExitProgram(BYTE *Mess)
{
  clrscr();
 _setcursortype(_NORMALCURSOR);
 printf(Mess);
 exit(0);
 return 0;
}

int CheckMainFile(BYTE *MFile)
{
 int H;
 FILE *M;
 BYTE Error;
 if ((Error==_dos_open(MFile, O_RDONLY, &H))) return Error;
 _dos_close(H);
 M = fopen(MFile, "r");
 strcpy(MainFile.Filename, MFile);
 MainFile.StartOff=0l;
 fseek(M, 0l, SEEK_END);
 MainFile.EndOff=ftell(M);
 fclose(M);
 return 0;
}

int CheckViewPos(BYTE *S, BYTE *E)
{
 ViewStart=atol(S);
 ViewEnd=atol(E);
 if (ViewStart>=MainFile.EndOff) return 1;
 if (ViewEnd>MainFile.EndOff) return 1;
 if (ViewStart>=ViewEnd) return 1;
 return 0;
}

int CheckPages(long S, long E)
{
 long total;
 long o;
 int  P;
 total=E-S;
 P= (int) (total/(21*78));
 if ((long)P*(21*78)<total) P++;
 return P;
}

int SetUpScreen(void)
{
 int t;
 textbackground(0);
 textcolor(15);
 clrscr();
 _setcursortype(_NOCURSOR);
 textbackground(1);
 gotoxy(1,1); cprintf("������������������");
 gotoxy(63,1);cprintf("����������������ͻ");
 gotoxy(1,2);
 cprintf("������������������������������������������������������������������������������Ķ");
 for (t=3; t<=23; t++) {
 gotoxy(1, t); cprintf("�");
 gotoxy(80, t); cprintf("�");
 }
 gotoxy(1,24);
 cprintf("�");
 gotoxy(80,24);
 cprintf("�");
 for (t=2; t<=79; t++)
 {
  gotoxy(t, 24); cprintf("�");
 }
 textcolor(15);
 textbackground(0);
 gotoxy(17, 1); cprintf("Multiex Commander VIEW v1.0, 1999, SadCom Ltd.");
 textcolor(15);
 textbackground(7);
 gotoxy(1, 25); cprintf(MainFile.Filename);
 gotoxy(28, 2); cprintf(PackedFile.Filename);
 textbackground(15);
 textcolor(1);
   gotoxy(39, 24); cprintf("%");
return 0;
}

int View(int Pages)
{
 BYTE Xit=0;
 BYTE Ch, C;
 BYTE *P;
 FILE *F;
 void *p;
 int y,x,xl, ym;
 long total;
 int LSize, left;
 int sum=78*21;
 int Per;
 int CPage;
 CPage=0; C=1;
 total=ViewEnd-ViewStart;
 left=(int) ((21*78*Pages)-total);
 LSize=sum;
 F = fopen(MainFile.Filename, "rb");
 while (!Xit)
 {
  if (C)
  {
   memset(&Buffer, 0, 21*78);
   fseek(F, ViewStart+CPage*sum, SEEK_SET);
   fread(&Buffer, LSize, 1, F);
   p=&Buffer;
   y=2*160+2;
   ym=21;
   x=78;
   xl=160-x*2;
   asm {
   mov bx, 0xb800
   mov es, bx
   xor di, di
   push ds
   lds si, p
   mov dx, y
 // add dx, x
   mov di, dx
   mov dx, ym
   mov ax, 0x1e
   sub di, xl
   }
 Loop:
  asm {
  add di, xl
  cmp dx, 0x00
  je  End
  dec dx
  mov bx, x
  }
 Loop2:
 asm {
  cmp bx, 0x00
  je Loop
  dec bx
  movsb
  stosb
  jmp Loop2
  }
 End:
 asm {pop ds }
   Per=(int)(((float)((CPage+1)*sum)/(float) total)*100);
   if (CPage+1==Pages) {Per=100;}
   gotoxy(36, 24); cprintf("   ", Per);
   gotoxy(36, 24); cprintf("%d", Per);

   C=0;
  }
  Ch=getch();
  switch (Ch) {
   case 81: { CPage++; C=1; LSize=sum;
	      if (CPage>Pages-1) {CPage--; C=0; }
	      if (CPage==Pages-1){LSize=left;}
	      break;
	    }
   case 73: { CPage--; C=1; LSize=sum;
	      if (CPage<0) {CPage++; C=0; }
	      break;
	    }
   case 27: { Xit=1;
	      break;
	    }
   }
  }
  fclose(F);
 return 0;
}

int main(int argc, BYTE *argv[])
{
 int Pages;

 if (argc<=3) ExitProgram("Not enough arguments to do anything!\n");
 if (CheckMainFile(argv[1])) ExitProgram("File given that does not exist!\n");
 if (CheckViewPos(argv[2], argv[3])) ExitProgram("Wrong position in MainFile given to view!\n");
 if (strcmp(argv[4], "-wrap")==0) Wrap=1;
 strcpy(PackedFile.Filename, "No Name Given By MC");
 if (argc>=5) strcpy(PackedFile.Filename, argv[4]);
 Pages=CheckPages(ViewStart, ViewEnd);
 SetUpScreen();
 View(Pages);
 ExitProgram("ended.\n");
 return 0;
}