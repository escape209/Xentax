//Make Dat File...
// SC Ltd.
// 1997

#include "system.h"
#include "defs.h"
#include "makedat.h"

 BYTE  LBuf[32768];
 void *LoadBuf;
 int   FileNumb=0;
 int   i, OutHandle, DatHandle;
 long  HeaderSize=0;
 BYTE  HeaderName[13]="SadCom Ltdat ";

 FileObj     FileList[100];
 SelectType  SelectList[100];
 unsigned count;

int GetFileNames(BYTE *FileListName)
{
 FILE *F;
 int Error=0;
 BYTE FN[13];
 BYTE *FF;
 if ((F = fopen(FileListName, "r"))==NULL) return 0;
 while (!Error)
 {
  if (fgets(FN, 13, F)==NULL) Error=1;
  FN[strlen(FN)-1]=0;
  strcpy(FileList[FileNumb].FileName, FN);
  FileNumb++;
 }
 return 1;
}

void PrintFileNames(void)
{
 for (i=0; i<=FileNumb-3; i++)
 {
  printf("FileName %d = %s\n", i, FileList[i].FileName);
 }
}

long GetHeaderSize(void)
{
 return (12+3+((FileNumb)*sizeof(FileList[0])));
}

long GetFileSize(BYTE *FileName)
{
 FILE *Str;
 BYTE mess[80];
 long FLength;
 Str=fopen(FileName, "r");          // Get File Length
 if (Str==NULL)
 {strcpy(mess, "Cannot open ");
  strcat(mess, FileName);
  SystemMessage(mess, 1);
  return -1;
 } //printf("\nCannot open %s, check your listfile...\n", FileName); exit(1);}
 fseek(Str, 0L, SEEK_END);
 FLength = ftell(Str);
 fclose(Str);
 return FLength;
}

int GetFileSizes(void)
{
 for (i=0; i<=FileNumb-1; i++)
 {
 FileList[i].FileSize=GetFileSize(FileList[i].FileName);
 }
 return 0;
}

int GetOffsets(void)
{
 FileList[0].FileOffset=HeaderSize+1;
 for (i=1; i<=FileNumb; i++)
 {
 FileList[i].FileOffset=FileList[i-1].FileSize+FileList[i-1].FileOffset;
 }
 return 0;
}

void WriteHeader(void)
{
 int D=FileNumb;
 int *K=&D;

 _dos_write(OutHandle, HeaderName, 13, &count);
 if (count<13) {printf("Unable to write to outputfile ...\n"); exit(1);}
 _dos_write(OutHandle, K, sizeof(FileNumb), &count);
 _dos_write(OutHandle, FileList, sizeof(FileList[0])*(FileNumb), &count);
}

void AddFiles(void)
{
 BYTE New;
 long Total;
 BYTE Tmp[26];
 for (i=0; i<=FileNumb-1; i++)
 {
  if ((_dos_open(FileList[i].FileName, O_RDONLY, &DatHandle))!=NULL)
   {printf("Unable to open datafile %s...\n",FileList[i].FileName); exit(1);}

  strcpy(Tmp, "Adding ");
  strcat(Tmp, SelectList[i].FileName);
  strcat(Tmp, "...");

  MessageToWindow(4, Tmp);

  Total=0;
  New=1;
  while (!eof(DatHandle))
  {
   _dos_read (DatHandle, LBuf, sizeof(LBuf), &count);

   Total+=count;

    CompletionWindow(SelectList[i].FileName, (int)
		    (((float) Total/ (float) FileList[i].FileSize)
		     *(float)100), New);
    New=0;
   _dos_write(OutHandle, LBuf, count, &count);
  }
   _dos_close(DatHandle);
 }
}

int DelFiles(int SelCnt)
{
   BYTE Mess[90];
   BYTE *Temp=NULL;
   BYTE Prompt=1;
   Mess[0]=27;
   Mess[1]=0;
   strcat(Mess, "Really delete the ");
   itoa(SelCnt, Temp, 10);
   strcat(Mess, Temp);
   strcat(Mess, " files?");
   Temp = (BYTE *) SystemRequest(Mess, 3, 0);
   if (!Temp[0]) Prompt=0;

   if (Prompt)
   {
//    PlaceWindow(5);
    Prompt=0;
    textbackground(0);

    for (i=0; i<=SelCnt-1; i++)
    {

     strcpy(Mess, "Deleting: ");
     strcat(Mess, SelectList[i].FileName);
     strcat(Mess, "...");

     MessageToWindow(4, Mess);

     if (unlink(FileList[i].FileName)==-1) Prompt=2;
   }

//    RemoveWindow(5);
  }
 return Prompt;
}

void ExtraFiles(BYTE *ExtractDir, BYTE *DATFile)
{
 FILE *F;
 FILE *Fe;
 BYTE TPath[84];
 BYTE New;
 int maxp, tt;
 long Total, exbytes, extra;
 BYTE Tmp[26];
  if ((F = fopen(DATFile, "rb"))==NULL)
   {printf("Unable to open datafile %s...\n",DATFile); exit(1);}

  for (i=0; i<=FileNumb-1; i++)
 {

  strcpy(Tmp, "Extracting ");
  strcat(Tmp, SelectList[i].FileName);
  strcat(Tmp, "...");

  MessageToWindow(4, Tmp);

  Total=0;
  New=1; extra=0; Fe=NULL;
  exbytes=32768;
  maxp=FileList[i].FileSize/32768;
  if (!maxp) { exbytes=FileList[i].FileSize; }
  else { extra=(long) (FileList[i].FileSize-(32768*(long) maxp)); maxp--; }

  fseek(F, FileList[i].FileOffset, SEEK_SET);
  if (Fe)  {printf("Error!!!!!!!"); exit(1);}
  strcpy(TPath, ExtractDir);
  strcat(TPath, SelectList[i].FileName);
  if ((Fe = fopen(TPath, "wb"))==NULL)
//  if ((Fe = fopen(SelectList[i].FileName, "wb"))==NULL)
   {clrscr();
   _setcursortype(_NORMALCURSOR);
 //   printf("Unable to create file %s...\n",TPath);
    perror("Well?");}

  tt=0;
  while (tt<=maxp)
  {
    fread(LBuf, exbytes, 1, F);

   Total+=exbytes;

    CompletionWindow(SelectList[i].FileName, (int)
		    (((float) Total/ (float) FileList[i].FileSize)
		     *(float)100), New);
    New=0;
    fwrite(&LBuf, exbytes, 1, Fe);
   tt++;
  }
   if (extra)
   {
    exbytes=extra;
   fread(LBuf, exbytes, 1, F);

   Total+=exbytes;

    CompletionWindow(SelectList[i].FileName, (int)
		    (((float) Total/ (float) FileList[i].FileSize)
		     *(float)100), New);
    New=0;
    fwrite(&LBuf, exbytes, 1, Fe);
  }
  fclose(Fe);
 }
 fclose(F);
}

void Help(void)
{
 printf("\nSyntax:\n\nmakedat [LISTFILE] [OUTPUTFILE]\n\n");
 printf("[LISTFILE]  =  TEXTfile in which you specify the names of the files\n");
 printf("               you wish to add, separated by CARRIAGE-RETURNS.\n");
 printf("[OUTPUTFILE]=  NAME of the data file you wish to create.\n");
}

int StartCreatingDATFile(BYTE *DATFile, int Number)
{

 FileNumb=Number;

 HeaderSize = GetHeaderSize();

 GetFileSizes();

 GetOffsets();

if ((_dos_creat(DATFile, _A_NORMAL, &OutHandle))!=NULL) return 1;

 WriteHeader();

 PlaceWindow(5);

 textbackground(0);

 AddFiles();

 RemoveWindow(5);

 _dos_close(OutHandle);

 return 0;
}
int StartExtractingDATFile(BYTE *ExtractDir, BYTE *DATFile, int Number)
{

 FileNumb=Number;

 PlaceWindow(5);

 textbackground(0);

 ExtraFiles(ExtractDir, DATFile);

 RemoveWindow(5);


 return 0;
}

/*int main(int argn, BYTE *arg[])
{

 if (arg[1]==NULL) {printf("No ListFile specified...\n"); Help(); exit(1);}
 if (arg[2]==NULL) {printf("No OutPutFile specified...\n"); Help(); exit(1);}


if (GetFileNames(arg[1])==NULL) {printf("Can't open ListFile...\n"); exit(1);}

 HeaderSize = GetHeaderSize();

 GetFileSizes();

 GetOffsets();
 printf("=-----------------------=\n");
 printf("MakeDat v0.01 SadCom Ltd.\n");
 printf("=-----------------------=\n");

if ((_dos_creat(arg[2], _A_NORMAL, &OutHandle))!=NULL)
{printf("Unable to open outputfile %s...\n", arg[2]); exit(1);}

 printf("Outputfile %s created...\n", arg[2]);
 printf("-----------------------\n");
 printf("Writing Header...\n");
 printf("-----------------------\n");

 WriteHeader();

 printf("Adding requested files:\n");
 printf("-----------------------\n");

 AddFiles();

 _dos_close(OutHandle);

 printf("-----------------------\n");
 printf("DAT File %s created...\n", arg[2]);

return 0;
} */