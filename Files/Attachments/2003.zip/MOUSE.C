#include "mouse.h"
#include "system.h"
#include "error.h"

extern BYTE *LastFunction;


int  	    OldX, OldY;
BYTE        MouseImageI[MOUSE_SIZE_X*MOUSE_SIZE_Y];  //IdleMouse
BYTE        MouseImageL[MOUSE_SIZE_X*MOUSE_SIZE_Y];  //LeftPressed
BYTE        MouseImageR[MOUSE_SIZE_X*MOUSE_SIZE_Y];  //RightPressed
BYTE	    MouseImageB[MOUSE_SIZE_X*MOUSE_SIZE_Y];  //BackgroundSave
struct      {
	    int far *MouseLeft;
	    void far *MouseRight;
	    void far *MouseBoth;
	    } MouseFunctions;


void far       *Image;

int	    YPosArray[SCREEN_Y];
BYTE 	    ImagesLoaded=0;
BYTE	    GraphShow;

int CheckMouse(void)
{
#ifdef debug
LastFunction="CheckMouse";
#endif
 asm {
      mov ah, 0x35
      mov al, 0x33
      int 0x21

      or  ax, bx
      jz  cm1
      cmp byte ptr es:[bx], 0x0cf
      jne Done
     }
cm1:
return 0; //Abort(21);
Done:
return 1;
}

void Set_YArray_Sizes(void)
{
 int i;
 YPosArray[0]=0;
 for (i=1; i<=SCREEN_Y-1; i++)
 {
  YPosArray[i]=YPosArray[i-1]+SCREEN_X;
 }
}


void InitTxtMouse(void)
{
 asm {
      mov ax, 0
      int 0x33
      cmp ax, 0
      jne Done
     }
//Abort(21);
Done:
}

void InitGraphMouse(void)
{
 asm {
      mov ax, 0
      int 0x33
      cmp ax, 0
      jne Done
     }
//Abort(21);
Done:
  asm {
      mov ax, 0x04
      mov cx, 150
      mov dx, 100
      int 0x33
     }

if (ImagesLoaded<3) {printf("Not enough mouse images loaded\n");
		     exit(1);}

SetMouseArea(0, 0, SCREEN_X-MOUSE_SIZE_X, SCREEN_Y-MOUSE_SIZE_Y);

Set_YArray_Sizes();

GetBackImage(150, 100);

OldX=150; OldY=100;

GraphShow=0;
//PutImage(MOUSE_IDLE, OldX, OldY, TRUE);
}

void ResetMouse(void)
{
 asm {
      mov ax, 0
      int 0x33
     }
}

void ShowGraphMouse(void)
{
 if (!GraphShow)
 {
 GetBackImage(OldX, OldY);
 PutImage(MOUSE_IDLE, OldX, OldY, TRUE);
 GraphShow=1;
 }
}

void HideGraphMouse(void)
{
 if (GraphShow)
 {
 PutImage(MOUSE_BACK, OldX, OldY, FALSE);
 GraphShow=0;
 }
}

void ShowMouse(void)
{
 asm {
      mov ax, 1
      int 0x33
     }
}

void HideMouse(void)
{
 asm {
      mov ax, 2
      int 0x33
     }
}

void LoadMouseImage(BYTE What, BYTE *File)
{
 FILE *Str;
 BYTE *Image;
#ifdef debug
LastFunction="LoadMouseImage";
#endif

 if (What>3) {printf ("Mouse Image Not Available\n"); exit(1); }
 if (What==MOUSE_IDLE)  {Image = MouseImageI;}
 if (What==MOUSE_LEFT)  {Image = MouseImageL;}
 if (What==MOUSE_RIGHT) {Image = MouseImageR;}

 if ((Str = fopen(File, "rb"))==NULL) {printf("No Mouse Images found/n");
					exit(1); }

 if ((fread(Image, (MOUSE_SIZE_X*MOUSE_SIZE_Y), 1, Str))!=1)
	{printf("Not able to read mouse image..."); exit(1); }

 fclose(Str);
 ImagesLoaded++;
}

void SetMouseInterruptSubRoutine(int Mask, void far *Handler)
{
 asm {
      cli
      mov ax, 0x14
      mov cx, word ptr Mask
      les di, Handler
      mov dx, di
      int 0x33
      sti
     }
}


void GetBackImage(int x, int y)
{
 int Pos;
 Pos=YPosArray[y]+x;
 Image = MouseImageB;
 asm {
    push ds
    les di, Image
    mov bx, 0xa000
    mov ds, bx
    mov cx, MOUSE_SIZE_Y
    mov bx, Pos
    mov si, bx
    }
Loop:
 asm {
    dec cx
    push cx
    mov cx, MOUSE_SIZE_Y
    shr cx, 1
 rep movsw
    mov cx, SCREEN_X
    sub cx, MOUSE_SIZE_X
    add si, cx
    pop cx
    cmp cx, 0
    jne Loop
    pop ds
 }
}


void PutImage(int what, int x, int y, BYTE Trans)
{
 int Pos;
 Pos=YPosArray[y]+x;
 if (what==MOUSE_IDLE) Image = MouseImageI;
 if (what==MOUSE_LEFT) Image = MouseImageL;
 if (what==MOUSE_RIGHT)Image = MouseImageR;
 if (what==MOUSE_BACK) Image = MouseImageB;

if (Trans)
{
asm {
     push ds
     lds  si,Image
     mov  bx, 0xa000
     mov  es, bx
     mov  bx, Pos
     mov  di, bx
     mov  cx, MOUSE_SIZE_Y
     }
Loop:
asm {
     dec  cx
     mov  dx, MOUSE_SIZE_X
//     push cx
    }
Loopx:
asm {
     dec  dx
     cmp  byte ptr ds:[si], 0
     je   GoOn
     movsb
     jmp On
    }
GoOn:
asm {
     inc  si
     inc  di
    }
On:
asm {
     cmp  dx, 0
     jne  Loopx
     cmp  cx, 0
     je   Done
     mov  dx, SCREEN_X
     sub  dx, MOUSE_SIZE_X
     add  di, dx
     jmp  Loop
    }
Done:
asm {
     pop  ds
    }
 }
if (!Trans)
 {
 asm {
    push ds
    lds si, Image
    mov bx, 0xa000
    mov es, bx
    mov cx, MOUSE_SIZE_Y
    mov bx, Pos
    mov di, bx
    }
Loop3:
 asm {
    dec cx
    push cx
    mov cx, MOUSE_SIZE_Y
    shr cx, 1
 rep movsw
    mov cx, SCREEN_X
    sub cx, MOUSE_SIZE_X
    add di, cx
    pop cx
    cmp cx, 0
    jne Loop3
    pop ds
 }
}


}

#pragma inline
#undef outp
BYTE MouseAction;
BYTE LastMouseAction;

void TrackGraphMouse(void)
{

 int   CurX;
 int   CurY;
 void far *Function=NULL;

 asm {
  mov  ax, 0x03
  int  0x33
  mov  CurX, cx
  mov  CurY, dx
  cmp  bl, 00000011B
  je   Both
  test bl, 00000001B
  jnz  Left
  test bl, 00000010B
  jnz  Right
  mov  MouseAction, MOUSE_IDLE
  jmp  Done
  }

Both:

  if (MouseFunctions.MouseBoth!=NULL)
   { Function=MouseFunctions.MouseBoth; }

  asm { jmp Done;
      }
Left:

  if (MouseFunctions.MouseLeft!=NULL)
   { Function=MouseFunctions.MouseLeft; }
  asm {
  mov  MouseAction, MOUSE_LEFT
  jmp  Done
      }

Right:

  if (MouseFunctions.MouseRight!=NULL)
   { Function=MouseFunctions.MouseRight; }
  asm {
  mov  MouseAction, MOUSE_RIGHT
      }

Done:

  if (GraphShow)
  {
  if ((OldX!=CurX) || (OldY!=CurY))
  {
   PutImage(MOUSE_BACK, OldX, OldY, FALSE);
   GetBackImage(CurX, CurY);
   PutImage(MouseAction, CurX, CurY, TRUE);
  }

  if (LastMouseAction!=MouseAction)
  {
   PutImage(MouseAction, CurX, CurY, TRUE);
   OldX=CurX; OldY=CurY;
  }
  }

  OldX=CurX;
  OldY=CurY;
  LastMouseAction=MouseAction;

  if (Function!=NULL)
  asm {
       call Function
      }

}

TObj TrackTXTMouse(void)
{
 TObj TextStat;
 int   CurX;
 int   CurY;
 void far *Function=NULL;

 TextStat.ButtonL=0;
 TextStat.ButtonR=0;
 TextStat.Both=0;



 asm {
  mov  ax, 0x03
  int  0x33
  mov  CurX, cx
  mov  CurY, dx
  cmp  bl, 00000011B
  je   Both
  test bl, 00000001B
  jnz  Left
  test bl, 00000010B
  jnz  Right
  mov  MouseAction, MOUSE_IDLE
  jmp  Done
  }

Both:
  TextStat.Both=1;
  if (MouseFunctions.MouseBoth!=NULL)
   { Function=MouseFunctions.MouseBoth; }

  asm { jmp Done;
      }
Left:
  TextStat.ButtonL=1;
  if (MouseFunctions.MouseLeft!=NULL)
   { Function=MouseFunctions.MouseLeft; }
  asm {
  mov  MouseAction, MOUSE_LEFT
  jmp  Done
      }

Right:
  TextStat.ButtonR=1;
  if (MouseFunctions.MouseRight!=NULL)
   { Function=MouseFunctions.MouseRight; }
  asm {
  mov  MouseAction, MOUSE_RIGHT
      }

Done:

  OldX=CurX;
  OldY=CurY;
  LastMouseAction=MouseAction;
  TextStat.CurX=CurX;
  TextStat.CurY=CurY;
  TextStat.LastAction=MouseAction;
  if (Function!=NULL)
  asm {
       call Function
      }

 return TextStat;
}

void SetCursorPos(int x, int y)
{
 asm {
     mov ax, 0x04
     mov cx, x
     mov dx, y
     int 0x33
     }
}

void SetMouseArea(int x, int y, int x2, int y2)
{

 asm {
     mov ax, 0x07
     mov cx, x
     mov dx, x2
     int 0x33
     mov ax, 0x08
     mov cx, y
     mov dx, y2
     int 0x33
     }
}

void AsnFnctToMseAct(void far *Function, int what)
{
 if (what==MOUSE_LEFT ) MouseFunctions.MouseLeft = Function;
 if (what==MOUSE_RIGHT) MouseFunctions.MouseRight= Function;
 if (what==MOUSE_BOTH ) MouseFunctions.MouseBoth = Function;
}

void SetMouseSensitivity(int HSens, int VSens, int DSThres)
{
 asm {
 mov ax, 0x1a
 mov bx, HSens
 mov cx, VSens
 mov dx, DSThres
 int 0x33
 }
}

SObj GetMouseSensitivity(void)
{
 SObj Sens;
 asm {
 mov ax, 0x1b
 int 0x33
 mov Sens.HSens, bx
 mov Sens.VSens, cx
 mov Sens.DSThres, dx
 }
 return Sens;
}

void ResetBackImage(void)
{
 int CurY;
 int CurX;

 asm {
  mov  ax, 0x03
  int  0x33
  mov  CurX, cx
  mov  CurY, dx
     }
 OldX=CurX;
 OldY=CurY;
 GetBackImage(CurX, CurY);
 PutImage(MOUSE_IDLE, CurX, CurY, TRUE);
}

BYTE CheckGraphMouseArea(int x, int y, int x2, int y2)
{
 if ((OldX>=x) && (OldX<=x2) && (OldY>=y) && (OldY<=y2)) return TRUE;
 return FALSE;
}
BYTE CheckTXTMouseArea(int x, int y, int x2, int y2)
{
 if (((OldX>>3) >=x-1) && ((OldX>>3)<=x2-1) &&
     ((OldY>>3) >=y-1) && ((OldY>>3)<=y2-1)) return TRUE;
 return FALSE;
}