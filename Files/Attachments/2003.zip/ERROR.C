//error.c for errorhandling

#include "error.h"
#include "system.h"

unsigned char	  *Errors[100];
unsigned char     *LastFunction;
char       	  CEH=0;



void TextMode(void)
{
 asm {
 xor ax, ax
 mov al, 3
 int 0x10
 }
}


void InitCEH(void)
{
 CEH=1;
 printf("Error Handler Init\n");
//--------------EMS Handler Errors------------
 Errors[1] ="No Expanded Memory Manager present.";
 Errors[2] ="Unable to Allocate EMS memory.";
 Errors[3] ="Unable to Map EMS memory.";
 Errors[4] ="Unable to Create More UserBufs";
 Errors[5] ="Unable to Load File";
 Errors[6] ="Unable to Map EMS Pages";
 Errors[7] ="Unable to determine Page Frame";
 Errors[8] ="Unable to allocate memory";
 Errors[9] ="Byte requested from Buffer is outside Buffer Size";
 Errors[10]="Access to Buffer requested that not has been initialized...yet";
 Errors[11]="Release of Buffer requested that not has been initialized...yet";
 Errors[12]="Unable to set EMS handle Name";
 Errors[13]="Unable to release memory";
 Errors[14]="Unable to Move Memory Block";
//--------------DAT File Errors---------------
 Errors[15]="Unable to open .DAT File";
 Errors[16]="Unable to read from .DAT File";
 Errors[17]="Different .DAT file format";
 Errors[18]="Empty .DAT File";
 Errors[19]="Unable to retrieve item from DAT-file";
 Errors[20]="Requested item does not exist in DAT-file";
//--------------MOUSE Errors------------------
 Errors[21]="No Mouse Driver Installed";
 Errors[22]="Incorrect MOUSE IMAGE specified";
 Errors[23]="MOUSE IMAGE file does not exist";
 Errors[24]="Unable to read from the mouse image file";
 Errors[25]="InitGraphMouse: Not enough images loaded";
//--------------Mem Errors---------------------
 Errors[26]="Unable to allocate mem";


}

void Abort(int Error)
{
 if (!CEH) InitCEH();
 TextMode();
 printf("Error %d : %s\n", Error, Errors[Error]);
#ifdef debug
 printf("Function Previously Used: %s\n", LastFunction);
#endif
 exit(1);
}
