using System;
using System.IO;
using System.Collections;
using Microsoft.DirectX.Direct3D;

namespace DOA3Viewer
{
	public class DOA3Reader : System.IO.BinaryReader
	{
		public DOA3Reader(System.IO.Stream fs): base(fs)
		{
		}
		public DOA3Object ReadDOA3Obj()
		{
			DOA3Object obj=new DOA3Object();
			obj.Magic=ReadChars(4);
			obj.VertexType=ReadUInt32();
			obj.Num0=ReadUInt32();
			obj.NumFaces=ReadUInt32();
			DOA3VertexInfo []vInfo=new DOA3VertexInfo[2];
			vInfo[0]=ReadDOA3VInfo();
			vInfo[1]=ReadDOA3VInfo();
			obj.VertexInfo=vInfo;
			float []fvals=Read4Singles();

			while(ReadUInt32()==0x80000000)
			{
				obj.AddMaterial(ReadDOA3Material());
			}

			DOA3Reader dr=this;
			dr.BaseStream.Seek(DOA3Object.dataoffset,System.IO.SeekOrigin.Begin);
			dr.BaseStream.Seek(obj.VertexInfo[0].VertexOffset,System.IO.SeekOrigin.Begin);
			obj.Vertices=dr.ReadVertices((int)obj.VertexInfo[0].NumVerts);
			//dr.BaseStream.Seek(DOA3Object.dataoffset,System.IO.SeekOrigin.Begin);
			//dr.BaseStream.Seek(obj.VertexInfo[0].IndexOffset,System.IO.SeekOrigin.Current);
			//obj.IndexBytes=dr.ReadBytes((int)obj.VertexInfo[0].NumFaces*2);
			return obj;
		}
		public DOA3VertexInfo ReadDOA3VInfo()
		{
			DOA3VertexInfo vInfo=new DOA3VertexInfo();
			vInfo.NumVerts=ReadUInt32();
			vInfo.VertexOffset=ReadUInt32();
			vInfo.NumFaces=ReadUInt32();
			vInfo.IndexOffset=ReadUInt32();
			vInfo.Num0=ReadUInt32();
			vInfo.Num1=ReadUInt32();
			vInfo.Num2=ReadUInt32();
			vInfo.Num3=ReadUInt32();
			return vInfo;
		}
		public DOA3Material ReadDOA3Material()
		{
			DOA3Material mat=new DOA3Material();
			mat.Size=ReadUInt32();
			mat.Pad02=ReadUInt32();
			mat.Number=ReadUInt32();
			mat.MatColor0=Read4Singles();
			mat.MatColor1=Read4Singles();
			mat.MatColor2=Read4Singles();
			mat.MatColor3=Read4Singles();
			mat.MatColor4=Read4Singles();
			mat.Power=ReadSingle();
			mat.Pad25=ReadSingle();
			mat.Pad26=ReadUInt32();
			mat.TextureIndex=ReadUInt32();
			mat.Pad28=ReadUInt32();
			mat.Pad29=ReadUInt32();
			mat.Pad30=ReadUInt32();
			mat.Pad31=ReadUInt32();
			mat.Pad32=ReadUInt32();
			uint [,] quads=new uint[mat.Pad31,4];
			for(int i=0;i<mat.Pad31;i++)
			{
				quads[i,0]=ReadUInt32();
				quads[i,1]=ReadUInt32();
				quads[i,2]=ReadUInt32();
				quads[i,3]=ReadUInt32();
			}
			mat.Quads=quads;
			return mat;
		}
		public float[] Read4Singles()
		{
			float [] farray=new float[4];
			for(int i=0;i<4;i++)
			{
				farray[i]=ReadSingle();
			}
			return farray;
		}
		public CustomVertex.PositionNormalTextured [] ReadVertices(int numVerts)
		{
			CustomVertex.PositionNormalTextured [] verts=new CustomVertex.PositionNormalTextured[numVerts];
			for(int i=0;i<numVerts;i++)
			{
				verts[i].X=ReadSingle();
				verts[i].Y=ReadSingle();
				verts[i].Z=ReadSingle();
				verts[i].Nx=ReadSingle();
				verts[i].Ny=ReadSingle();
				verts[i].Nz=ReadSingle();
				verts[i].Tu=ReadSingle();
				verts[i].Tv=ReadSingle();
			}
			return verts;
		}
	}

	/// <summary>
	/// Summary description for DOA3Model.
	/// </summary>
	public class DOA3Model
	{
		public DOA3Model()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public void Load(string filename)
		{
			FileStream fs=new FileStream(filename,FileMode.Open);
			DOA3Reader dr=new DOA3Reader(fs);
			uint headermagic=dr.ReadUInt32();
			uint filesize=dr.ReadUInt32();
			uint headersize=dr.ReadUInt32();
			DOA3Object.dataoffset=headersize;
			uint modelheader=dr.ReadUInt32();
			size=dr.ReadUInt32();
			magic=dr.ReadChars(4);
			numobjs=dr.ReadUInt32();
			numtxt=dr.ReadUInt32();
			num0=dr.ReadUInt32();
			num1=dr.ReadUInt32();
			uint [] offsets=new uint[numobjs];
			doa3Objs=new DOA3Object[numobjs];
			for(int i=0;i<numobjs;i++)
			{
				offsets[i]=dr.ReadUInt32();
			}
			for(int i=0;i<numobjs;i++)
			{
				dr.BaseStream.Seek(offsets[i],System.IO.SeekOrigin.Begin);
				doa3Objs[i]=dr.ReadDOA3Obj();
			}
			fs.Close();
		}
		private uint size;
		private char[] magic;
		private uint numobjs;
		private uint numtxt;
		private uint num0;
		private uint num1;
		public DOA3Object [] doa3Objs;
	}

	public class DOA3Object
	{
		public DOA3Object()
		{
			materials=new ArrayList();
		}
		public void Load(ref BinaryReader br)
		{
			uint i=br.ReadUInt32();
		}
		private char[] magic;
		private uint vertex_type;
		private uint num0;
		private uint numfaces;
		private DOA3VertexInfo[] v_info;
		private float [] floatvalues;
		private CustomVertex.PositionNormalTextured [] vertices;
		private byte[] indexbytes;
		static public uint dataoffset=0;
		ArrayList materials;

		public void AddMaterial(DOA3Material mat)
		{
			materials.Add(mat);
		}
		public char[] Magic
		{
			get
			{
				return magic;
			}
			set
			{
				magic=value;
			}
		}
		public uint VertexType
		{
			get
			{
				return vertex_type;
			}
			set
			{
				vertex_type=value;
			}
		}
		public uint Num0
		{
			get
			{
				return num0;
			}
			set
			{
				num0=value;
			}
		}

		public uint NumFaces
		{
			get
			{
				return numfaces;
			}
			set
			{
				numfaces=value;
			}
		}
		public DOA3VertexInfo[] VertexInfo
		{
			get
			{
				return v_info;
			}
			set
			{
				v_info=value;
			}
		}
		public float [] FloatValues
		{
			get
			{
				return floatvalues;
			}
			set
			{
				floatvalues=value;
			}
		}
		public CustomVertex.PositionNormalTextured [] Vertices
		{
			get
			{
				return vertices;
			}
			set
			{
				vertices=value;
			}
		}
		public byte [] IndexBytes
		{
			get
			{
				return indexbytes;
			}
			set
			{
				indexbytes=value;
			}
		}
	}
	public class DOA3VertexInfo
	{
		public DOA3VertexInfo()
		{
		}

		private uint numverts;
		private uint vertex_offset;
		private uint numfaces;
		private uint index_offset;
		private uint num0;
		private uint num1;
		private uint num2;
		private uint num3;

		public uint NumVerts
		{
			get
			{
				return numverts;
			}
			set
			{
				numverts=value;
			}
		}
		public uint VertexOffset
		{
			get
			{
				return vertex_offset;
			}
			set
			{
				vertex_offset=value;
			}
		}
		public uint NumFaces
		{
			get
			{
				return numfaces;
			}
			set
			{
				numfaces=value;
			}
		}
		public uint IndexOffset
		{
			get
			{
				return index_offset;
			}
			set
			{
				index_offset=value;
			}
		}
		public uint Num0
		{
			get
			{
				return num0;
			}
			set
			{
				num0=value;
			}
		}
		public uint Num1
		{
			get
			{
				return num1;
			}
			set
			{
				num1=value;
			}
		}		
		public uint Num2
		{
			get
			{
				return num2;
			}
			set
			{
				num2=value;
			}
		}		
		public uint Num3
		{
			get
			{
				return num3;
			}
			set
			{
				num3=value;
			}
		}	
	}

	public class DOA3Material
	{
		public DOA3Material()
		{
		}
		private uint size;
		private uint pad02;
		private uint number;
		private float []mat_color0;
		private float []mat_color1;
		private float []mat_color2;
		private float []mat_color3;
		private float []mat_color4;
		private float power;
		private float pad25;
		private uint pad26;
		private uint tex_no;
		private uint pad28;
		private uint pad29;
		private uint pad30;
		private uint pad31;
		private uint pad32;
		private uint [,] quads;
		public uint Size
		{
			get{return size;}
			set{size=value;}
		}
		public uint Pad02
		{
			get{return pad02;}
			set{pad02=value;}
		}
		public uint Number
		{
			get{return number;}
			set{number=value;}
		}
		public float[] MatColor0
		{
			get{return mat_color0;}
			set{mat_color0=value;}
		}
		public float[] MatColor1
		{
			get{return mat_color1;}
			set{mat_color1=value;}
		}
		public float[] MatColor2
		{
			get{return mat_color2;}
			set{mat_color2=value;}
		}
		public float[] MatColor3
		{
			get{return mat_color3;}
			set{mat_color3=value;}
		}
		public float[] MatColor4
		{
			get{return mat_color4;}
			set{mat_color4=value;}
		}
		public float Power
		{
			get{return power;}
			set{power=value;}
		}
		public float Pad25
		{
			get{return pad25;}
			set{pad25=value;}
		}
		public uint Pad26
		{
			get{return pad26;}
			set{pad26=value;}
		}
		public uint TextureIndex
		{
			get{return tex_no;}
			set{tex_no=value;}
		}
		public uint Pad28
		{
			get{return pad28;}
			set{pad28=value;}
		}		
		public uint Pad29
		{
			get{return pad29;}
			set{pad29=value;}
		}
		public uint Pad30
		{
			get{return pad30;}
			set{pad30=value;}
		}
		public uint Pad31
		{
			get{return pad31;}
			set{pad31=value;}
		}
		public uint Pad32
		{
			get{return pad32;}
			set{pad32=value;}
		}
		public uint [,] Quads
		{
			get{return quads;}
			set{quads=value;}
		}
	}
}
