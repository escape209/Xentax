using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Direct3D=Microsoft.DirectX.Direct3D;

namespace DOA3Viewer
{
	public class DOA3View : Form
	{
		// Our global variables for this project
		Device device = null; // Our rendering device
		VertexBuffer vertexBuffer = null;
		PresentParameters presentParams = new PresentParameters();
		DOA3Model dmdl=new DOA3Model();

		float XRot=0.0f;
		float YRot=0.1f;
		float ZEye=0.6f;
		float YLookAt=0.2f;
		
		bool pause = false;

		public DOA3View()
		{
			// Set the initial size of our form
			this.ClientSize = new System.Drawing.Size(400,300);
			// And it's caption
			this.Text = "DOA3 Viewer";

			dmdl.Load(@"D:\Projects\xpr\lei06.xpr");
			// Load our icon from the resources of the .exe
			//this.Icon = new Icon(this.GetType(), "directx.ico");
		}

		public bool InitializeGraphics()
		{
			try
			{
				// Now let's setup our D3D stuff
				presentParams.Windowed=true;
				presentParams.SwapEffect = SwapEffect.Discard;
				presentParams.EnableAutoDepthStencil=true;
				presentParams.AutoDepthStencilFormat=DepthFormat.D16;
				device = new Device(0, DeviceType.Hardware, this, CreateFlags.SoftwareVertexProcessing, presentParams);
				device.DeviceCreated += new System.EventHandler(this.OnCreateDevice);
				device.DeviceReset += new System.EventHandler(this.OnResetDevice);
				this.OnCreateDevice(device, null);
				this.OnResetDevice(device, null);
				pause = false;
				device.RenderState.ZBufferEnable=true;
				device.RenderState.AlphaBlendEnable=true;
				return true;
			}
			catch (DirectXException)
			{ 
				return false; 
			}
		}
		public void OnCreateDevice(object sender, EventArgs e)
		{
			Device dev = (Device)sender;
			// Now Create the VB
			vertexBuffer = new VertexBuffer(typeof(CustomVertex.PositionNormalTextured),(int)dmdl.doa3Objs[0].VertexInfo[0].NumVerts, dev, 0, CustomVertex.PositionNormalTextured.Format, Pool.Default);
			vertexBuffer.Created += new System.EventHandler(this.OnCreateVertexBuffer);
			this.OnCreateVertexBuffer(vertexBuffer, null);
		}
		public void OnResetDevice(object sender, EventArgs e)
		{
			Device dev = (Device)sender;
			// Turn off culling, so we see the front and back of the triangle
			dev.RenderState.CullMode = Cull.None;
			// Turn off D3D lighting, since we are providing our own vertex colors
			dev.RenderState.Lighting = false;
		}
		public void OnCreateVertexBuffer(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionNormalTextured [] verts = (CustomVertex.PositionNormalTextured[])vb.Lock(0,LockFlags.Discard);
			CustomVertex.PositionNormalTextured [] verts2=dmdl.doa3Objs[0].Vertices;
			// do NOT just assign the array.  this will reallocate the 
			// locked buffer and will cause the vertex buffer to remain
			// unchanged
			for(int i=0;i<dmdl.doa3Objs[0].VertexInfo[0].NumVerts;i++)
			{
				verts[i]=verts2[i];
			}
			vb.Unlock();
		}

		private void Render()
		{
			if (device == null) 
				return;

			if (pause)
				return;

			CustomVertex.PositionNormalTextured [] verts = (CustomVertex.PositionNormalTextured[])vertexBuffer.Lock(0,LockFlags.ReadOnly);
			vertexBuffer.Unlock();
			//Clear the backbuffer to a green color 
			device.Clear(ClearFlags.Target|ClearFlags.ZBuffer, System.Drawing.Color.Green, 1.0f, 0);
			//Begin the scene
			device.BeginScene();
			// Setup the world, view, and projection matrices
			SetupMatrices();
	
			device.SetStreamSource(0, vertexBuffer, 0);
			device.VertexFormat = CustomVertex.PositionNormalTextured.Format;
			device.DrawPrimitives(PrimitiveType.PointList, 0, (int)dmdl.doa3Objs[0].VertexInfo[0].NumVerts);
			//End the scene
			device.EndScene();
			device.Present();
		}

		private void SetupMatrices()
		{

			device.Transform.World = Matrix.RotationYawPitchRoll(YRot,XRot,0.0f);

			// Set up our view matrix. A view matrix can be defined given an eye point,
			// a point to lookat, and a direction for which way is up. 
			device.Transform.View = Matrix.LookAtLH( new Vector3( 0.0f, 0.2f,ZEye ), new Vector3( 0.0f, YLookAt, 0.0f ), new Vector3( 0.0f, 1.0f, 0.0f ) );

			// For the projection matrix, we set up a perspective transform (which
			// transforms geometry from 3D view space to 2D viewport space, with
			// a perspective divide making objects smaller in the distance). To build
			// a perpsective transform, we need the field of view (1/4 pi is common),
			// the aspect ratio, and the near and far clipping planes (which define at
			// what distances geometry should be no longer be rendered).
			device.Transform.Projection = Matrix.PerspectiveFovLH( (float)Math.PI / 4, 1.0f, 0.1f, 100.0f );
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			this.Render(); // Render on painting
		}

		protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e)
		{
			switch(e.KeyCode)
			{
				case Keys.Escape:
					this.Close();
					break;
				case Keys.Up:
					XRot+=0.1f;
					break;
				case Keys.Down:
					XRot-=0.1f;
					break;
				case Keys.Left:
					YRot+=0.1f;
					break;
				case Keys.Right:
					YRot-=0.1f;
					break;
				case Keys.Add:
					ZEye-=0.1f;
					break;
				case Keys.Subtract:
					ZEye+=0.1f;
					break;
				case Keys.Prior:
					YLookAt+=0.1f;
					break;
				case Keys.Next:
					YLookAt-=0.1f;
					break;

			}
		
		}
		protected override void OnKeyPress(System.Windows.Forms.KeyPressEventArgs e)
		{
			if ((int)(byte)e.KeyChar == (int)System.Windows.Forms.Keys.Escape)
				this.Close(); // Esc was pressed

		}
		protected override void OnResize(System.EventArgs e)
		{
			pause = ((this.WindowState == FormWindowState.Minimized) || !this.Visible);
		}

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main() 
		{
			using (DOA3View frm = new DOA3View())
			{
				if (!frm.InitializeGraphics()) // Initialize Direct3D
				{
					MessageBox.Show("Could not initialize Direct3D.");
					return;
				}
				frm.Show();

				// While the form is still valid, render and process messages
				while(frm.Created)
				{
					frm.Render();
					Application.DoEvents();
				}
			}
		}
	}
}
