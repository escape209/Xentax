struct vmp_header {
	unsigned long filetype;
	unsigned char unk001;
	unsigned char unk002;
	unsigned char unk003;
	unsigned char unk004;
	unsigned short table1_count;
	unsigned short bone_count;
	unsigned long unk005; // total number of vertices
	unsigned long unk006; // padding?
	unsigned long unk007; // padding?
	unsigned long unk008; // padding?
	unsigned long unk009; // padding?
	// addresses
	unsigned long bone_addr;
	unsigned long tex_file_addr;
	unsigned long table1a_addr;
	unsigned long table5_addr;
	unsigned long table4_addr;
	unsigned long table7_addr; // jumps to a few ints and a string, then follows the string table {minus 64 from each byte in string table}
	unsigned long unk016; // always 0?
	unsigned long table1_addr;
	unsigned long table2_addr;
	unsigned long table3_addr;
	unsigned long table6_addr;
	};
struct vmp_table1a_type_1 {
	unsigned char* indices;
	};
struct vmp_table1a_type_2 {
	unsigned long unk1;
	float unk2;
	float unk3;
	};
struct vmp_table1a_type_3 {
	float unk1;
	unsigned long unk2;
	unsigned long unk3;
	unsigned long unk4;
	};
struct vmp_table1a_type_4 {
	unsigned char unk[156];
	};
struct vmp_table1a { // mesh bone palette
	unsigned char type;	// 0 = Static Mesh | 1 = Skinned Mesh
	unsigned char count;
	unsigned char unk023;
	unsigned char unk024;
	vmp_table1a_type_1 type1_data;
	vmp_table1a_type_2 type2_data;
	vmp_table1a_type_3 type3_data;
	vmp_table1a_type_4 type4_data;
	unsigned long unk025;
	unsigned char* addrs;
	};
struct vmp_table1b {
	unsigned char unk025;
	unsigned char unk026;
	unsigned char unk027;
	unsigned char unk028;
	unsigned long addr;
	};
struct vmp_table1c_chunk {
	unsigned char index;
	unsigned char type;
	unsigned char size;
	unsigned char unk072;
	unsigned char unk073;
	};
struct vmp_table1c_cmd01 {
	vmp_table1c_chunk header;
	};
struct vmp_table1c_cmd02 {
	vmp_table1c_chunk header;
	unsigned long unk083;
	unsigned long unk084;
	unsigned long unk085;
	unsigned long unk086;
	unsigned long unk087;
	};
struct vmp_table1c_cmd03 {
	vmp_table1c_chunk header;
	unsigned long unk088; // texture addrress
	unsigned long unk089; // texture addrress
	float unk090;
	float unk091;
	};
struct vmp_table1c_cmd05 {
	vmp_table1c_chunk header;
	unsigned long table1d_addr; // address to mesh table
	};
struct vmp_table1c_cmd10 {
	vmp_table1c_chunk header;
	unsigned long mat_addr; // address to floats, seems like diffuse colours etc
	};
struct vmp_table1c_cmd11 {
	vmp_table1c_chunk header;
	unsigned char unk079;
	unsigned char unk080;
	unsigned char unk081;
	unsigned char unk082;
	};
struct vmp_table1c {
	vmp_table1c_chunk header;
	vmp_table1c_cmd01* cmd01_info;
	vmp_table1c_cmd02* cmd02_info;
	vmp_table1c_cmd03* cmd03_info;
	vmp_table1c_cmd05* cmd05_info;
	vmp_table1c_cmd10* cmd10_info;
	vmp_table1c_cmd11* cmd11_info;
	};
struct vmp_table1d_chunk {
	unsigned char unk094;
	unsigned char unk095;
	unsigned char unk096;
	unsigned char unk097; // type?
	};
struct vmp_table1d_type16 {
	vmp_table1d_chunk header;
	};
struct vmp_table1d_type48 {
	vmp_table1d_chunk header;
	unsigned long addr;
	};
struct vmp_table1d_type96 {
	vmp_table1d_chunk header;
	};
struct vmp_table1d {
	vmp_table1d_chunk header;
	vmp_table1d_type16* table1d_type16;
	vmp_table1d_type48* table1d_type48;
	vmp_table1d_type96* table1d_type96;
	};
struct vmp_table2 {
	unsigned long unk061; // always 1?
	unsigned long unk062; // count ?
	unsigned long unk063; // count ?
	};
struct vmp_table3 {
	unsigned long unk064; // always 1?
	};
struct vif_header {
	unsigned char unk100;	// 1
	unsigned char unk101;	// 1
	unsigned char unk102;	// 0
	unsigned char unk103;	// 1
	unsigned char unk104;
	unsigned char unk105;
	unsigned char unk106;
	unsigned char unk107;
	unsigned long unk108;
	unsigned char unk109;
	unsigned char unk110;
	unsigned char unk111;
	unsigned char unk112;
	unsigned long unk113;
	unsigned long unk114;
	};
struct vmp_table4_header {
	unsigned char type;
	unsigned char count;
	unsigned char unk055;
	unsigned char unk056;
	};
struct vmp_table4_info01 {
	vmp_table4_header header;
	};
struct vmp_table4_info02 {
	vmp_table4_header header;
	unsigned long addr1;
	unsigned long addr2;
	};
struct vmp_table4_info03 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info04 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info05 {
	vmp_table4_header header;
	bool state;
	};
struct vmp_table4_info06 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info07 {
	vmp_table4_header header;
	unsigned char* indices;
	}
struct vmp_table4_info08 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info09 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info10 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info11 {
	vmp_table4_header header;
	unsigned long addr;
	};
struct vmp_table4_info12 {
	vmp_table4_header header;
	bool state;
	}
struct vmp_table4_info13 {
	vmp_table4_header header;
	bool state;
	};
struct vmp_table4_info14 {
	vmp_table4_header header;
	bool state;
	};
struct vmp_table4_info16 {
	vmp_table4_header header;
	unsigned char* indices;
	unsigned long addr = 0
	};
struct vmp_table4_info19 {
	vmp_table4_header header;
	bool state;
	};
struct vmp_table4 {
	vmp_table4_header header;
	vmp_table4_info01 info01;		// end address of chunks
	vmp_table4_info02 info02;		// address inside tex file pointing to texture address
	vmp_table4_info03 info03;		// not documented
	vmp_table4_info04 info04;		// addr?
	vmp_table4_info05 info05;		// count?
	vmp_table4_info06 info06;		// addr?
	vmp_table4_info07 info07;		// bone palette?
	vmp_table4_info08 info08;		// addr?
	vmp_table4_info09 info09;		// addr?
	vmp_table4_info10 info10;		// not documented
	vmp_table4_info11 info11;		// addr?
	vmp_table4_info12 info12;		// flag?
	vmp_table4_info13 info13;		// flag?
	vmp_table4_info14 info14;		// flag?
	vmp_table4_info16 info16;		// bone palette?
	vmp_table4_info13 info19;		// flag?
	};
struct vmp_vec4 {
	float x;
	float y;
	float z;
	float w;
	};
struct vmp_table6 {
	unsigned short count6a;
	unsigned short count6b;
	unsigned short count6c;
	unsigned short unk058;
	unsigned long unk059;
	unsigned long unk060;
	unsigned long table6a_addr;
	unsigned long table6b_addr;
	unsigned long table6c_addr;
	unsigned long unk064;
	unsigned long unk065;
	unsigned long unk066;
	vmp_vec4* table6a;
	vmp_vec4* table6b;
	vmp_vec4* table6c;
	};
struct bone_table1 {	// 64bytes
	vmp_vec4 unk034; // rotation?
	vmp_vec4 unk035; // position?
	float unk036;
	float unk037;
	float unk038;
	unsigned long name_addr;
	char* name;
	float unk043;
	float unk044;
	unsigned char unk045;
	unsigned char unk046;
	unsigned char unk047;
	unsigned char unk048;
	unsigned char unk049; // Child
	unsigned char unk050; // Parent
	unsigned char unk051; // Index {this is a unique id, ids need to be matched when reading the bone palette}
	unsigned char unk052; // Type / Group
	};
struct vmp_file {
	vmp_header header;
	unsigned long* table1;
	vmp_table1a* table1a;
	vmp_table1b* table1b;
	vmp_table1c* table1c;
	vmp_table1d* table1d;
	vmp_table2 table2;
	vmp_table3 table3;
	bone_table1* bone_info;
	vpt_file texture;
	unsigned long* table4;
	// 	I Skipped table5, too frustrating..
	vmp_table6 table6;
	};