I organized this to use to demo the mesh file format used in soul calibur 3

I reversed the format myself and wrote a tool in maxscript

Included are the following;
block_diagram.png		Shows how to get to a relating block
vmp_imp__by_mariokart64n.ms	The original maxscript that I wrote
vmp_format.h			the maxscript structures transcoded into c style structs
vmp_sample.vmp			A soul calibur 3 model to examine


My original release thread can be found here
https://forum.xentax.com/viewtopic.php?p=162231#p162231

you may contact me via email but its likely you'll go to my spam folder
mario_kart64n@yahoo.com

So if you really need to contact me, currently doing so through discord is most effective
mariokart64n#9964

This information was organized for TopazTK, which I will be doing a short
walk through in his thread called the "SC3 MEGA THREAD!!" here
https://forum.xentax.com/posting.php?mode=reply&f=29&t=22497#pr165597



Aug 5 2020
-mariokart64n