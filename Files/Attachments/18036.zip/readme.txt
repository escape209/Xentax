How to use:

1.Import the Skeleton from the havok File (\Alan Wake\data\ep999-000\skeletons\) into 3dsmax first with:
    https://lukascone.wordpress.com/2019/03/21/havok-3ds-max-plugin/
    import settings:
        scale = 97
        Coord. setup - tick Invert Top
        Coord. setup - Back - choose Top from dropdown
        Coord. setup - tick Right
        Coord. setup - Right - choose Right from dropdown
2. then run script, flip the toggles around with settings:
    Clear scene: OFF
    Enable Skin: ON
    Flip X Axis of Mesh: ON
    
Note: it's important that you use the correct skeleton, and thats about it.
also seems all bones called "ragdoll*" can be removed