PTExplorer v0.1.4
-===============-
Game: Smackdown vs Raw 2010 (XBOX360)
-===============-
By XeNTaX Game Research
http://www.xentax.com
Forum: http://forum.xentax.com
Code by Mr.Mouse
December 2009

-=Instructions=- 

1. Transfer your .PT (Paint Tool) file to PC and extract images using PTExplorer as (*.bmp)
2. Open the bmps in PSP or Photoshop and edit them
Remember that since black is the transparent color in the in-game pallette you need to change the black slightly in PS so it doesnt appear as a transparent in game.
3. Save the bmps of the same size & color depth.
4. Reimport the bmps into the .pt file to slots of your choice with PTExplorer, but don't use slot 0.
5. Save the *.PT file from PTExplorer
6. Use modio to rehash and resign the .pt file
7. Transfer it to the XBox, overwriting the old Paint Tool .pt file
8. Go to the Paint Tool in-game: the game will detect a corrupted file and when asked to overwrite the file, do it! The game will correct the file, make slot 0 the default logo, but keep the other logo's intact. 

-=PTExplorer use=-

Straightforward, open a .pt file and export any image you like to edit. Export as BMP. Then edit in a good graphics package. Save as 256 colour paletted file while retaining alpha. Remember that colour 0x0F (15 decimal) is black and has transparency 0. It is used as the background colour. 
When done editing, import back into desired slot. At the moment, slot 0 is off limits, as the work-around for checksums will overwrite slot 0 in game. 

Alpha: to get a preview of the intensity of each colour, click "View alpha". Black is background (intensity 0) and white is max intensity (transparency 0).  
