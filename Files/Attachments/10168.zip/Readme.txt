BikMod 
v0.3e (Beta)
------------------------------------------

Installation:
-Open game installation folder.
-Rename file binkw32.dll to libbinkw32.dll.
-Extract BikMod installation archive to game folder.
-Thats it, run game.


Uninstallation:
-Delete file binkw32.dll.
-Rename file libbinkw32.dll to binkw32.dll
-Done.


Configuration:
-Open file binkw32.cfg in text editor, modify and save.


Using subtitles:
-Rename subtitle file to name of .bik file, and append underscore, language code and track index, e.g. SierraLogo.bik -> SierraLogo_en0.srt.
-Copy subtitle file to folder "subtitle" or to folder where .bik file is located.


Known bugs:
-Doesn't work properly with DirectDraw games when running fullscreen. Will be fixed one day (?).


Tested games:
-Arcanum - Steamworks and Magick Obscura
-Fallout: New Vegas
-Hitman - Blood Money
-Urban Chaos
-Diablo 2
-C&C: Red Alert 2


Changelog:

Version 0.3e
2011/04/21

-Added support for .bik files that are opened from archive or memory. Filenames are now automatically generated from .bik's file header, and it's possible to load and display subtitles for them.
-Added version checking. It will also inform you when new version of BikMod library is available to download.
-Fixed bug that in some cases caused host application crash when copying frame data back to buffer.
-Fixed some minor bugs.

Version 0.3c
2011/04/17

-BikMod released for public beta testing.

------------------------------------------
GaMod Community
http://tools.game-alive.com/