// myview, viewer used by Multiex Commander for textfiles
// Special Ability: uses command line given start and end offsets in any file
// and shows that particular piece.

#include <dos.h>
#include <conio.h>
#include <stdio.h>
#include  <stdlib.h>
#include <string.h>
#include "myview.h"
#include <fcntl.h>

FileInfo	MainFile;
FileInfo	PackedFile;
int 		Pages;
int		CP;
BYTE 		Wrap=0;
BYTE		Buffer[21*80];
FILE 		*File;
BYTE 		ClearBuf[4096];
typedef struct { BYTE Text[100];} _StringType;
typedef struct { long Offset;} _PageOffSetType;
_StringType Line[22];
_PageOffSetType Page[10000];

#pragma inline

int ExitProgram(BYTE *Mess)
{
  clrscr();
 _setcursortype(_NORMALCURSOR);
 printf(Mess);
 exit(0);
 return 0;
}

int CheckMainFile(BYTE *MFile)
{
 FILE *M ;
 BYTE Error;
 M = fopen(MFile, "rt");
 if (!M) return 1;
 strcpy(MainFile.Filename, MFile);
 MainFile.StartOff=0l;
 fseek(M, 0l, SEEK_END);
 MainFile.EndOff=ftell(M);
 fclose(M);
 return 0;
}


int CheckPages(void)
{

 long total=0;
 BYTE Temp[80];
 int  P=0;
 int P2=0;
 File = fopen (MainFile.Filename, "rt");
/* while ((fread(Temp, 78, 1, File)))
 {
  P++;
  if (P==22) {P=0; P2++; Page[P2].Offset=ftell(File); }
   total++;
 }*/

 while ((fgets(Temp, 78, File)))
 {
  P++;
  if (P==21) {P=0; P2++; Page[P2].Offset=ftell(File); }
   total++;
 }
 fclose (File);
// P = (int) total/21;
// if ((long)P*21<total) P++;
 return P2;
}

int LoadBuffer(long FilePos)
{
 int Lines=0;
 BYTE *Error;
 BYTE Line1[100];
 fseek(File, FilePos, SEEK_SET);
 while ((Lines<21) && ((fgets(&Line1[0], 78, File))))
 {
   setmem((void *) &Line[Lines].Text[0], 78l, 0);
   strcpy(&Line[Lines].Text[0], Line1);
   setmem((void *) &Line1[0], 88l, 0);
   Lines++;
 }
 MainFile.StartOff=ftell(File);
 return Lines;
}

int ShowPage(int Lines)
{
 float Per;
 int L=0;
 int y=3;
 textbackground(0);
 textcolor(14);
 puttext(2, 3, 80, 23, ClearBuf);
 while (L<Lines)
 {
  gotoxy(2, y);
  printf(Line[L].Text);
  y++; L++;
 }
 Per=100;
 if (Pages>0) Per=((float) (CP)/ (float) (Pages))*100;
 gotoxy(75, 25); cprintf("    ", (int) Per);
 gotoxy(75, 25); cprintf("%d%", (int) Per);

 return 0;
}

int ViewFile(void)
{
 BYTE Line[90];
 BYTE Lines=0;
 BYTE Xit=0, Xit2=0;
 BYTE ch;
 BYTE *Error;
 int check;
 CP=0;
 File=fopen(MainFile.Filename, "rt");
 MainFile.StartOff=0;
 Lines=LoadBuffer(Page[CP].Offset);
 ShowPage(Lines);

 while (!Xit)
 {
 ch=getch();
 switch (ch) {
 case 27 : Xit=1; Xit2=1; break;
 case 81 : if (CP<=Pages-1)
	   {CP++;
	   Lines=LoadBuffer(Page[CP].Offset);
	   ShowPage(Lines); }
	   break;
 case 73 : if (CP>0)
	    { CP--;
	    Lines=LoadBuffer(Page[CP].Offset);
	    ShowPage(Lines); }
	    break;

 }
}

fclose(File);
return 0;
}


int SetUpScreen(void)
{
 int t;
 textbackground(0);
 textcolor(15);
 clrscr();
 _setcursortype(_NOCURSOR);
 textbackground(1);
 gotoxy(1,1); cprintf("������������������");
 gotoxy(63,1);cprintf("����������������ͻ");
 gotoxy(1,2);
 cprintf("������������������������������������������������������������������������������Ķ");
 for (t=3; t<=23; t++) {
 gotoxy(1, t); cprintf("�");
 gotoxy(80, t); cprintf("�");
 }
 gotoxy(1,24);
 cprintf("�");
 gotoxy(80,24);
 cprintf("�");
 for (t=2; t<=79; t++)
 {
  gotoxy(t, 24); cprintf("�");
 }
 textcolor(15);
 textbackground(0);
 gotoxy(17, 1); cprintf("Multiex Commander TREAD v1.0, 2000, SadCom Ltd.");
 textcolor(15);
 textbackground(7);
 gotoxy(1, 25); cprintf(MainFile.Filename);
// gotoxy(28, 2); cprintf(PackedFile.Filename);
 textbackground(15);
 textcolor(1);
 gettext(2, 3, 80, 23,ClearBuf);
return 0;
}


int main(int argc, BYTE *argv[])
{

// if (argc<=3) ExitProgram("Not enough arguments to do anything!\n");
 if (CheckMainFile(argv[1])) ExitProgram("File given that does not exist!\n");
 if (strcmp(argv[4], "-wrap")==0) Wrap=1;
// strcpy(PackedFile.Filename, "No Name Given By MC");
 if (argc>=5) strcpy(PackedFile.Filename, argv[4]);
 Pages=CheckPages();
 SetUpScreen();
 ViewFile();
 ExitProgram("ended.\n");
 return 0;
}