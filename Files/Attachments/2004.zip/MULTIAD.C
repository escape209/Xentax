// Add on for MC
// This should handle the different files with overlapping extensions

#include "system.h"
#include <conio.h>
#include <process.h>
#include "defs.h"
#include <dos.h>
#include <float.h>
#include <string.h>
BYTE OldBuf[4096];
BYTE MexDir[256];
BYTE ConfigDir[256];
BYTE ConfigDirPlus[256];
BYTE MexPath[256];
BYTE TextFilePath[256];
BYTE ConfigDirPlus2[256];
BYTE FileNameIn[256];
BYTE EXT[5];
int B;
typedef struct {BYTE Name[256]; BYTE FileName[256];} _FormatName;

_FormatName Formats[20];

int CURSORY=0;
int MAXCURSORY;
int CURRENTFORMAT;
int NUMBEROFFORMATS;
FILE *F1, *F2;

int InitParam(void)
{
struct ffblk files;
char P3[512];
char P2[256];
char *P;
char *T="MC\\;";
BYTE TextFile[18];
int i, j, k;
BYTE Done;
P = getenv("PATH");
//strcpy(P, "c:\\deos\\;c:\\temp\\mc\\;");

strcpy(&P3[0], P);
i=0; P2[0]=0; j=strlen(P3);
while ((strncmpi(&P2[0], T,4)))
{
 i++;
 strncpy(&P2[0], &P3[i],4);
 P2[4]=0;
// printf("%s\n", &P2[0]);
// printf("%s\n", T);
 if (i>=j) strcpy(&P2[0], "MC\\;");
}
if (i>=j) {printf("Kutzooi\n"); exit(0);}
P3[i+3]=0;
//clrscr();
//printf("P# = %s\n, i=%d\n", P3, i); getch();

while (P3[i]!=':')
{
 i--;
}
i--;

strcpy(&MexDir[0], &P3[i]);
printf("MEXDIR = %s\n", MexDir);
strcpy(&ConfigDir[0], MexDir);
i = strlen(ConfigDir);
strcpy(&ConfigDir[i-1], "\\config");
i = strlen(FileNameIn);
strcpy(MexPath, MexDir);
MexPath[strlen(MexPath)-1]=0;
strcat(MexPath, "\\");
strcat(MexPath, "multiex.exe");
//printf("Mpath# = %s\n", MexPath); getch();

//getting the right extension

j=0;
while ((i>0) && (FileNameIn[i]!='.')) {i--; j++;}
strncpy(&EXT[0], &FileNameIn[i+1], j);
strcpy (&ConfigDirPlus[0], ConfigDir);
strcat (ConfigDirPlus, "\\");
strcat (ConfigDirPlus, EXT);
//printf("ConfigDirplus = %s\n", ConfigDirPlus); getch();

// checking if format uberhaupt exists
//strcpy(ConfigDirPlus, "D:\\TEMP\\FAD");

Done = findfirst(ConfigDirPlus, &files, FA_DIREC);

//if !Done the dir is there

if (Done) { return 1;}

strcpy (ConfigDirPlus2, ConfigDirPlus);
strcat (ConfigDirPlus, "\\*.ini");
//printf("ConfigDirplus = %s\n", ConfigDirPlus); getch();

j=0;
Done = findfirst(ConfigDirPlus, &files, FA_ARCH);
while (!Done)
 { j++;
   strcpy(&TextFile[0], files.ff_name);
   strcpy(Formats[j-1].FileName, ConfigDirPlus2);
   strcat(Formats[j-1].FileName, "\\");
   strcat(Formats[j-1].FileName, files.ff_name);

   TextFile[strlen(TextFile)+1]=0;
   k=0; i=strlen(files.ff_name);
   while ((i>0) && (files.ff_name[i]!='.')) {i--; k++;}
   strcpy(&TextFile[i], ".txt");
   strcpy(TextFilePath, ConfigDirPlus2);
   strcat(TextFilePath, "\\");
   strcat(TextFilePath, TextFile);
//printf("textFilePath = %s\n", TextFilePath); getch();
   F1=fopen(TextFilePath, "rt");
   if (F1)
   {
    fgets(Formats[j-1].Name, 18, F1);
    fclose(F1);
    Done=findnext(&files);
   }
   else
   {
   Done=1; fclose(F1);
   }
  }
   NUMBEROFFORMATS=j;
   CURRENTFORMAT=0;
return 0;

}

int CopyCurrentFormat(void)
{
 BYTE TEMP[512];
 BYTE LINE[90];
 F1=fopen(Formats[CURRENTFORMAT].FileName, "rt");
 strcpy(TEMP, ConfigDir);
 strcat(TEMP, "\\");
 strcat(TEMP, EXT);
 strcat(TEMP, ".INI");
//printf("Temp# = %s\n", TEMP); getch();
  F2=fopen(TEMP, "w+t");
  while (fgets(LINE, 80, F1)) fputs(LINE, F2);
  fclose(F2);fclose(F1);
 return 0;
}

int SelectionWindow(void)
{
 int x, y;
 int t;
 int x1=22;
 int x2=58;
 int y1=8;
 int y2=12;
 BYTE ch;
 BYTE Xit=0;
 gettext(x1,y1, x2, y2, OldBuf);

 textcolor(15);
 textbackground(11);

 for (x=x1; x<=x2; x++)
 {gotoxy(x, y1); cprintf("�");
  gotoxy(x, y2); cprintf("�");}

 for (y=y1; y<=y2; y++)
 {gotoxy(x1, y); cprintf("�");
  gotoxy(x2, y); cprintf("�");}

 gotoxy(x1, y1); cprintf("�");
 gotoxy(x2, y1); cprintf("�");
 gotoxy(x1, y2); cprintf("�");
 gotoxy(x2, y2); cprintf("�");

 gotoxy(x1+1,y1);
 cprintf("Cycle through %s formats:", EXT);

 textbackground(0);

 for (x=x1+1; x<=x2+1; x++)
 {gotoxy(x, y2+1); cprintf(" ");}

 for (y=y1+1; y<=y2; y++)
 {gotoxy(x2+1, y); cprintf(" ");}

 textcolor(15); textbackground(4);

 for (y=y1+1; y<=y2-1; y++)
 {
  for (x=x1+1; x<=x2-1; x++)
  {
   gotoxy(x,y); cprintf(" ");
  }
 }
 t=(x2-2)-(x1+2);
 for (x=x1+2; x<=x2-2; x++)
 {gotoxy(x, y1+2);
textbackground(4); cprintf(" ");}
 gotoxy(x1+2+((t-strlen(Formats[CURRENTFORMAT].Name))/2), y1+2);
 textbackground(11); cprintf("%s", Formats[CURRENTFORMAT].Name);

 while (!Xit)
 {
 if (kbhit())
 {
  ch=getch();
  switch (ch) {
  case 13 : Xit=1; break;
  case 75 : { if (CURRENTFORMAT>0)
		 { CURRENTFORMAT--;
		   textbackground(4);
		   for (x=x1+2; x<=x2-2; x++)
		   {gotoxy(x, y1+2);
		   cprintf(" ");}
		   gotoxy(x1+2+((t-strlen(Formats[CURRENTFORMAT].Name))/2), y1+2);
		   textbackground(11);cprintf("%s", Formats[CURRENTFORMAT].Name);
		 }
		 break;
	     }
  case 77 : { if (CURRENTFORMAT<NUMBEROFFORMATS-1)
		 { CURRENTFORMAT++; textbackground(4);
		   for (x=x1+2; x<=x2-2; x++)
		   {gotoxy(x, y1+2);
		   cprintf(" ");}
		   gotoxy(x1+2+((t-strlen(Formats[CURRENTFORMAT].Name))/2), y1+2);
		   textbackground(11);cprintf("%s", Formats[CURRENTFORMAT].Name);
		 }
		 break;
	     }
   } //switch

 } //kbhit

}//Xit
 puttext(22,8, 58, 14, OldBuf);

return 0;

}




int main(int argc, BYTE *argv[])
{
strcpy(&FileNameIn[0], argv[1]);
if (InitParam()) exit(6);
B=0;
if (NUMBEROFFORMATS>1) SelectionWindow();

CopyCurrentFormat();
textbackground(0);
clrscr();
B=spawnl(P_WAIT, MexPath, (void *) MexDir, (void *) argv[1], "-l", NULL);
textbackground(0);
if (B) {clrscr(); perror("Unable to spawn MultiEx from MultiAd!");}
clrscr();
return 0;
}
