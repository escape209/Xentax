#define BYTE unsigned char

typedef 	struct {
		BYTE Filename[81];
		long StartOff;
		long EndOff;
		} FileInfo;

