/*
--------------------------------------------------------------------------

			      M U L T I E X

				V 1 . 7 0

				   B Y

			       S A D C O M

				  L T D

		    Copyright 1998 Mr.Mouse/SadCom Ltd.

--------------------------------------------------------------------------
*/

#include "system.h"
#include "defs.h"
#include <float.h>


//BYTE FBuf[50001];
//BYTE *FBuffer;
BYTE *FBuf;
//BYTE FBuf = &FBuffer;

//typedefs

typedef struct {
		BYTE NAME[57];
		long Offset;
		long Size;
	       } _FileType;

typedef struct {
		BYTE NAME[13];
		BYTE ID[80];
		BYTE CheckID;
		BYTE EVENTCNT;
		BYTE EVENTS[80];
	       } _FormatType;

typedef struct {
		BYTE EXT[4];
		BYTE Format;
	       } _ExtType;

typedef struct {
		BYTE Specifier1[20];
		BYTE Specifier2[20];
		BYTE Specifier3[20];
		BYTE Pos;
		BYTE Code;
	       } _SpecType;

typedef struct {BYTE Specifiers[10][30];} _SpecType2;

typedef struct {BYTE S[80];} String80;


//global structs

struct {
	BYTE S[80];
       } STR[10];


_FormatType INIFormats[100];
_ExtType    ExtAss[100];
_FileType   FilesList[2];
BYTE 	    LoopList[10][20];




//errorcodes returned

#define ErrorInMainINI 1
#define ErrorInExINI   2
#define OpenMainINI    3
#define OpenExINI      4
#define OpenDatFile    5
#define IllegalFormat  6
#define NoDATFile      7
#define UnableListFile 8
#define UnableCreateEx 9
#define IllegalSwitch  10
#define ErrorInWriting 11
#define ImpFileNotExis 12
#define FIleNotFound   13
#define NotEnoughFree  14
#define NormalExit     99

//format specifiers

#define _SIZEL    1
#define _SIZEI    2
#define _OFFSETL  3
#define _OFFSETI  4


//event specifiers

#define _GoToStart    1
#define _GoToEnd      2
#define _GoTo         3
#define _GetLong      4
#define _GetInt       5
#define _SavePos      6
#define _GetString    7
#define _StrBResizeC  8
#define _StrEResizeC  9
#define _StrBResize   10
#define _StrEResize   11
#define _ExtractFILE  12
#define _Events	      13
#define _ID           14
#define _LOOP         15
#define _ENDLOOP      166
#define _PROMPTUSER   17
#define _SETBYTESREAD 18
#define _SETFILECNT   19

//variable specifiers

#define _TAILOFF   20
#define _TAILSIZEB 21
#define _TAILSIZEU 22
#define _FILESTART 23
#define _SAVESIZE  24
#define _BYTESREAD 25
#define _DUMMYL    26
#define _DUMMYI    27
#define _FILECNTL  28
#define _FILECNT   29
#define _STRRESIZE 30
#define _FILEOFF   31
#define _FILESIZE  32
#define _ONE       33
#define _ALL       34
#define _EXTRCNT   35
#define _NOFILENAMES 36
#define _FILEJMP   37

#define _FILENAME  40

//additional events

#define _UP	   50
#define _DOWN	   51
#define _MULTIPLY  52
#define _DIVIDE	   53
#define _NUMBER    54
#define _VAR       55
#define _SET       56
#define _ADD       57
#define _SUBST     58


//all variables

long 		TAILOFF;
long 		TAILSIZEB;
long 		TAILSIZEU;
long 		FILESTART;
long 		SAVESIZE ;
long 		BYTESREAD;

BYTE 		EXTRACTDIR[80];
BYTE		MULTIEXDIR[80];

long 		VAR[21];
long 	        SIZEL;
long 		EXTRCNT=0;
int  		SIZEI;
long 		OFFSETL;
int  		OFFSETI;
long 		FILECNTL;
int  		FILECNTI;
long 		DUMMYL;
int  		DUMMYI;
long 		TailOff;
long 		OffPos;
long 		JmpPos;
long 		SizePos;
long 		ImFileSize;
long 		OrImFileSize;
long 		OrImFileOff;
long 		DifOrIm;

BYTE 		IMPDONE=0;
BYTE 		IMPORT=0;
BYTE 		PROMPT=0;
BYTE 		PROMPTOVER=0;
BYTE 		EXTRACTD=1;
BYTE 		SAVETEMP=0;


BYTE 		CheckExt=0;
BYTE 		CheckFirst=0;
BYTE 		CheckFull=0;
BYTE		CheckName=0;
BYTE 		dbg=0;
BYTE 		All=0;
BYTE	        cont=0;
BYTE		Yes=0;
BYTE 		ListFile=0;
BYTE 		Check1=0;
BYTE 		CheckID=1;
BYTE 		ErrorCode=0;
BYTE 		FILENAMES=1;
BYTE		LoopCnt=0;
BYTE 		LOOP=0;


long 		current, total;
FILE 		*F;

long 		FILECNTL;
BYTE 		FileNameIn[80];
BYTE		ImportFile[79];
BYTE 	       *FileNameOut;
BYTE	        FPart[79];
BYTE 		ExtPart[13];
BYTE		FullName[80];
FILE 	       *Out;
FILE 	       *In;
FILE 	       *TEMPIMP;
int 		t, L;

int 		FormatNum;
int 		ExINICnt, ExtenCnt;
int 		EventCnt;


//making some functs accessible

long GetFreeSpace(void);
BYTE ProcessLoop(BYTE LoopC, BYTE VAR1, BYTE VAR2);
BYTE Switch(BYTE *Table, BYTE L);
long WriteLong(long TEMP);


//All Functions

//---------------------------------------------------------------

int CheckDebugKey(void)
{
 BYTE c;
 c = getch();
 switch (c)
 {
 case 27 : printf("Debugging aborted.\n"); exit(1); break;
 }
 return 0;
}


//---------------------------------------------------------------

BYTE PROMPTUSER(BYTE *FName, long Size)
{
 BYTE 			ch;
  Yes=0;
  if (All) printf("Extracting : %lu %s Size %lu\n", EXTRCNT,  FName, Size);
  if (!All)
  {
   printf("Extract: %lu %s Size %lu (y/n/a/q)?", EXTRCNT, FName, Size);

   while ((!cont) && (!All))
   {
   ch = getch();
   switch (ch) {
     case 121:  Yes=1; printf(" Yes\n"); cont=1; break;
     case 110:  Yes=0; printf(" No\n");  cont=1; break;
     case 113:  Yes=0; printf(" Quit\n");  cont=1; exit(0); break;
     case 97 :  All=1; printf(" All\n "); cont=1; break;
    }
   }
  }
 cont=0;
 return 0;
}

//---------------------------------------------------------------

BYTE StrBResizeC(BYTE *STR1, BYTE CH)
{
 BYTE L;
 BYTE *TEMP;
 BYTE C=0;

 L = strlen(STR1);
 while ((STR1[C]!=CH) && (C!=L)) C++;
 if (C!=L)
 {
 strcpy(TEMP, STR1[C+1]);
 strcpy(STR1, TEMP);
 }
 return 0;
}

//---------------------------------------------------------------

BYTE StrEResizeC(BYTE *STR1, BYTE CH)
{
 BYTE TEMP[80];
 BYTE C=0;
// CH='/';
 C = strlen(STR1);

if (dbg)
 printf("Trying to resize %s till character %d\n", STR1, CH);
 while ((STR1[C]!=CH) && (C!=0)) C--;

 if (C!=0)
 {
 strncpy(TEMP, &STR1[C+1], strlen(STR1)-C);
 strcpy(STR1, TEMP);
if (dbg)
 printf("new str1: %s\n", STR1);
 }
 return 0;
}

//---------------------------------------------------------------

BYTE StrBResize(BYTE *STR1, BYTE CNT)
{
 BYTE *TEMP;
 strcpy(TEMP, STR1[CNT]);
 strcpy(STR1, TEMP);
 return 0;
}

//---------------------------------------------------------------

BYTE StrEResize(BYTE *STR1, BYTE CNT)
{
 BYTE *TEMP;
 strncpy(TEMP, CNT);
 strcpy(STR1, TEMP);
 return 0;
}

//---------------------------------------------------------------

BYTE CheckString(BYTE *String)
{
 int d;
 int t=0;
 BYTE cnt=0;
 d=strlen(String);
 do
 {
  if    (((String[t]>63) && (String[t]<91)) ||
	((String[t]>47) && (String[t]<58)) ||
	((String[t]>96) && (String[t]<123)))
	{}
  else {
  String[t]=36; cnt++;}

 t++;
 } while (t<=d-1);
 return cnt;
}

//---------------------------------------------------------------

int ExtractFile(long what)
{
 long 			d, tt;
 unsigned 		c;
 int			dec, sign;
 int 			c1, c2;
 BYTE 			ch;
 BYTE 			TName[18];
 BYTE 			FName[81], *Temp;
 BYTE a[80];
 BYTE b[13];
 BYTE e;


 if (what==_ONE) tt=0;
 if (what==_ALL) {printf("ExtractFILE ALL not implemented...Use ONE.\n");
		  exit(1);
		  }


 for (t=0; t<=tt; t++)
 {
  if (FilesList[t].Offset>0)
   {
    fseek(In, FilesList[t].Offset, SEEK_SET);
   }
   else
   {
    FilesList[t].Offset=ftell(In);
   }

  if (EXTRACTD)
  {
   strcpy(FName, EXTRACTDIR);
   if (FILENAMES)
    {
     strcat(FName, FilesList[t].NAME);
    }
  else
   {
    Temp = fcvt(EXTRCNT,  8, &dec, &sign);
    Temp[dec]=0;
    strcat(Temp, ".MEX");
    strcat(FName, Temp);
   }
 }
 else
  {
   if (FILENAMES)
    {
     strcpy(FName, FilesList[t].NAME);
    }
   else
    {
     Temp = fcvt(EXTRCNT,  8, &dec, &sign);
     Temp[dec]=0;
     strcat(Temp, ".MEX");
     strcat(FName, Temp);
    }
  }
 ch=1;

 if ((IMPORT) && (!IMPDONE))
 {
  ch=0;
  if (strcmp(ImportFile, &FName[strlen(EXTRACTDIR)])==0)
  {
   OrImFileOff=FilesList[t].Offset;
   OrImFileSize=FilesList[t].Size;
   d=ftell(In);
   if (!LISTIMP)
   {
   printf(" File to import found:\n");
   printf(" Name	 : %s\n", FName);
   printf(" OffPos  : %lu\n", OffPos);
   printf(" SizPos  : %lu\n", SizePos);
   printf(" OrOff   : %lu\n", OrImFileOff);
   printf(" OrSize  : %lu\n", OrImFileSize);
   }
   DifOrIm=ImFileSize-OrImFileSize;
   if (
   printf(" DifOrIm : %ld \n", DifOrIm);
  if (VAR[0]>0)
   {
    fseek(In, TailOff, SEEK_SET);
    WriteLong(VAR[0]+DifOrIm);
    if (dbg)
    {
     printf("TailOff Written: %lu at %lu\n",
      VAR[_TAILOFF-20]+DifOrIm, TailOff);
     CheckDebugKey();
    }
   }
  fseek(In, SizePos, SEEK_SET);
  WriteLong(ImFileSize);
  fseek(In, d, SEEK_SET);
  IMPDONE=1;
  if (dbg) CheckDebugKey();
  }
 }

 if (IMPDONE) ch=0;

 if (CheckName)
  {
   e=0; ch=0;
   while ((e!=strlen(FilesList[t].NAME)) && (FilesList[t].NAME[e]!='.')) e++;
   if (e==strlen(FilesList[t].NAME))
   {
    if (CheckFull) {
    if (strcmp(FullName,FilesList[t].NAME)==0) ch=1;}
   }
   else
   {
    strncpy(a, FilesList[t].NAME, e); a[e]=0;
    strcpy(b, FilesList[t].NAME+e+1);

    if (CheckFull)
    {
     if (strcmp(FullName,FilesList[t].NAME)==0) ch=1;
    }
    else
    {
     if ((CheckExt) && (strcmp(b, ExtPart)==0)) ch=1;
     if ((CheckFirst) && (strcmp(a, FPart)==0)) ch=1;
    }
   }
  }

  if ((PROMPT) && (!ListFile) && (ch)) PROMPTUSER(FName, FilesList[t].Size);


  if (!(All) ^ (Yes))
   {
    if (ListFile)
    {
     d=0;
     while (d<=18) {TName[d]=0; d++;};
     if (FILENAMES)
     {
      strcpy(TName, FilesList[t].NAME);
     }
     else
     {
      strcpy(TName, Temp);
     }
     if (dbg) printf("Writing ''%s'' in MULTIEX.LST...\n", TName);
     if (CheckName)
     {
      if (ch) fwrite(&TName, 18, 1, Out);
     }
     else
     {
      fwrite(&TName, 18, 1, Out);
     }
    }
    d= ftell(In);
    if (ListFile)
     {
      if (CheckName)
      {
       if (ch) fwrite(&d, 4, 1, Out);
      }
      else
      {
       fwrite(&d, 4, 1, Out);
      }
     }
    d+=FilesList[t].Size;
    if (ListFile)
     {
      if (CheckName)
      {
       if (ch) fwrite(&d, 4, 1, Out);
      }
      else
      {
       fwrite(&d, 4, 1, Out);
      }
     }
    fseek(In, d, SEEK_SET);
    EXTRCNT++;
   }

  if ((All) || (Yes))
  {
   if (ch)
   {
    Out = fopen(FName, "wb");
    if (Out==NULL)
    {
     if (CheckString(FilesList[t].NAME))
     {
      strcpy(FName, EXTRACTDIR);
      strcat(FName, FilesList[t].NAME);
     }
     Out = fopen(FName, "wb");
     if (Out==NULL)
     {
      ErrorCode=UnableCreateEx; return 0;
     }
    }
    d = FilesList[t].Size;

    do
    {
     d -= 50000;
     c=50000;
     if (d<0) {c=d+50000;}


     fread(FBuf, c, 1, In);
//     if (fwrite(&FBuf, c, 1, Out)==0)
     if (fwrite(FBuf, c, 1, Out)==0)
      {
       ErrorCode=11;
       return 0;}
    } while (c==50000);

    EXTRCNT++;

    fclose(Out);
   }
   else EXTRCNT++;
  }
 }
 FilesList[0].Offset=0;// <<<<-------------------!!!!!!!!!!!!!!!!!!

 return 1;
}

//---------------------------------------------------------------

long GetLong(void)
{
 long TEMP=0;
 long  bah;
 if (!fread(&TEMP, 4, 1, In))
  {
   perror("Terminated!!\n");
   exit(1);
  }
 BYTESREAD+=4;
 if (dbg)
  {
   printf("Long gotten: %lu\n", TEMP);
   CheckDebugKey();
  }
 return TEMP;
}

//---------------------------------------------------------------

long WriteLong(long TEMP)
{
 long  bah;
 bah=ftell(In);
 fwrite(&TEMP, 4, 1, In);
 fclose(In);
 In = fopen(FileNameIn, "r+b");
 fseek(In, bah+4, SEEK_SET);

 if (dbg)
  {
   printf("Long written: %lu\n", TEMP);
   CheckDebugKey();
  }
 return TEMP;
}

//---------------------------------------------------------------

long GetInt(void)
{
 int TEMP;
 fread(&TEMP, 2, 1, In);
 BYTESREAD+=2;
 return TEMP;
}

//---------------------------------------------------------------

BYTE ProcessLoop(BYTE LoopC, BYTE VAR1, BYTE VAR2)
{
 BYTE T;
 BYTE K;
 long *v1;
 long *v2;

 T=LoopList[LoopC][0];
 if (VAR1==_BYTESREAD) v1=&BYTESREAD;
 if (VAR1==_TAILSIZEB) v1=&VAR[_TAILSIZEB-20];
 if (VAR1==_TAILSIZEU) v1=&VAR[_TAILSIZEU-20];
 if (VAR1==_FILECNTL)  v1=&VAR[_FILECNTL-20];
 if (VAR1==_FILECNT)   v1=&VAR[_FILECNT-20];
 if (VAR1==_EXTRCNT)   v1=&EXTRCNT;
 if (VAR1==_DUMMYL)    v1=&VAR[_DUMMYL-20];
 if (VAR1==_FILEJMP)   v1=&VAR[_FILEJMP-20];
 if (VAR2==_BYTESREAD) v2=&BYTESREAD;
 if (VAR2==_TAILSIZEB) v2=&VAR[_TAILSIZEB-20];
 if (VAR2==_TAILSIZEU) v2=&VAR[_TAILSIZEU-20];
 if (VAR2==_FILECNTL)  v2=&VAR[_FILECNTL-20];
 if (VAR2==_FILECNT)   v2=&VAR[_FILECNT-20];
 if (VAR2==_EXTRCNT)   v2=&EXTRCNT;
 if (VAR2==_DUMMYL)    v2=&VAR[_DUMMYL-20];
 if (VAR2==_FILEJMP)   v2=&VAR[_FILEJMP-20];
 while (* (long *) v1!= * (long *) v2)
 {
  K=0;
  do
  {
   K=Switch(&LoopList[LoopCnt][1], K);
   if (K==0) return 0;
   K++;
  } while (K<T-1);
 }
 return 1;
}

//---------------------------------------------------------------

BYTE Switch(BYTE *Table, BYTE L)
{
 long  bah;
 long aa, bb;
  int K;

  if (dbg)
  {printf("Now trying to process: %d\n", Table[L]);
   printf("------(next in line: %d, %d, %d)\n", Table[L+1], Table[L+2], Table[L+3]);
   printf("BYTESREAD: %lu, EXTRCNT: %lu\n", BYTESREAD, EXTRCNT);
   CheckDebugKey();
  }
  switch (Table[L])
  {
   case _GoToStart	: fseek(In, 0l, SEEK_SET); break;
   case _GoToEnd        : fseek(In, 0l, SEEK_END); break;
   case _GoTo           :{L++;

			  if (dbg)
			  {
			   printf("Going to FilePosition: %lu\n",
			   VAR[Table[L]-20]);
			   CheckDebugKey();
			  }

			  fseek(In, VAR[Table[L]-20],
				SEEK_SET);
			 break;
			 }
   case _GetLong        :{L++;
			  if (Table[L]==_FILEOFF)
			  {
			  if (dbg)
			  {
			   printf("Getting FileOffset. \n");
			  }
			   if (IMPORT) OffPos=ftell(In);
			   FilesList[VAR[_FILECNT-20]].Offset=
			   GetLong();
			   VAR[_FILEOFF-20] = FilesList[VAR[_FILECNT-20]].Size;

			   if (IMPDONE)
			   {
			    fseek(In, OffPos,SEEK_SET);
			    FilesList[VAR[_FILECNT-20]].Offset+=DifOrIm;
			    WriteLong(FilesList[VAR[_FILECNT-20]].Offset);
			   }
			  }

			  if (Table[L]==_FILESIZE)
			  {
			  if (dbg)
			  {
			   printf("Getting FileSize.\n");
			  }
			   if (IMPORT) SizePos=ftell(In);
			   FilesList[VAR[_FILECNT-20]].Size=
			   GetLong();
			   VAR[_FILESIZE-20] = FilesList[VAR[_FILECNT-20]].Size;
			  }

			  if ((Table[L]!=_FILESIZE) &&
			  (Table[L]!=_FILEOFF))
			  {
			   if (Table[L]==_FILEJMP)
			   {
			    if (dbg)
			    {
			     printf("Getting FileJmp.\n");
			    }
			    if (IMPORT) JmpPos=ftell(In);
			    VAR[Table[L]-20]= GetLong();

			    if (IMPDONE)
			    {
			     fseek(In, JmpPos,SEEK_SET);
			     WriteLong(VAR[Table[L]-20]+DifOrIm);
			    }
			   }
			   else
			   {
			    if (Table[L]==_TAILOFF) TailOff=ftell(In);
			    VAR[Table[L]-20] = GetLong();
			   }
			  }
			  break;
			 }
   case _GetInt         :{L++;
			  VAR[Table[L]-20] = (int)
			  GetInt(); break;
			 }
   case _SavePos        :{L++;
			  VAR[Table[L]-20] =
			  ftell(In);
			  if (dbg)
			   printf("Pos saved: %lu\n", VAR[Table[L]-20]);
			  break;
			 }

   case _GetString      :{L++;

			  if (dbg)
			  {
			   printf("Getting string of %d bytes.\n", Table[L]);
			   if (Table[L]==0) {printf("Attempt to get string of 0 bytes\n"); return 0;}
			   CheckDebugKey();
			  }
			  if (Table[L+1]==_FILENAME)
			  {
			   fread(FilesList[VAR[_FILECNT-20]].NAME,
			   Table[L], 1, In); BYTESREAD+=Table[L];
			   L++;
			  }
			  if (dbg)
			   printf("String : %s, now going to do: %d\n",
			    FilesList[VAR[_FILECNT-20]].NAME, Table[L]);
			  break;
			 }
   case _SET		:{L++;
			  if (Table[L+1]==_VAR)
			  {
			   VAR[Table[L]-20]=VAR[Table[L+2]-20];
			  }
			  if (Table[L+1]==_NUMBER)
			  {
			   VAR[Table[L]-20]=Table[L+2];
			  }
			  L+=2;
			  break;
			 }
   case _ADD		:{L++;
			  if (Table[L+1]==_VAR)
			  {
			   VAR[Table[L]-20]+=VAR[Table[L+2]-20];
			  }
			  if (Table[L+1]==_NUMBER)
			  {
			   VAR[Table[L]-20]+=Table[L+2];
			  }
			  L+=2;
			  break;
			 }
   case _SUBST		:{L++;
			  if (Table[L+1]==_VAR)
			  {
			   VAR[Table[L]-20]-=VAR[Table[L+2]-20];
			  }
			  if (Table[L+1]==_NUMBER)
			  {
			   VAR[Table[L]-20]-=Table[L+2];
			  }
			  L+=2;
			  break;
			 }

   case _MULTIPLY       :{L++;
			  if (Table[L+1]==_VAR)
			  {
			   aa=VAR[Table[L+2]-20];
			  }
			  if (Table[L+3]==_VAR)
			  {
			   bb=VAR[Table[L+4]-20];
			  }
			  if (Table[L+1]==_NUMBER)
			  {
			   aa=Table[L+2];
			  }
			  if (Table[L+3]==_NUMBER)
			  {
			   bb=Table[L+4];
			  }
			  VAR[Table[L]-20]=aa*bb;
			  L+=4;
			  break;
			 }

   case _UP		:{L++;
			  VAR[Table[L]-20]++;
			  break;
			 }
   case _DOWN		:{L++;
			  VAR[Table[L]-20]--;
			  break;
			 }


   case _SETBYTESREAD   :{L++;
			  if (Table[L]==0)
			  {
			  BYTESREAD=0;
			  }
			  else
			  {
			   BYTESREAD=VAR[Table[L]-20];
			  }
			  break;
			 }
   case _SETFILECNT   :{L++;
			  if (Table[L]==0)
			  {
			  VAR[_FILECNT-20]=0;
			  }
			  else
			  {
			   BYTESREAD=VAR[Table[L]-20];
			  }
			  break;
			 }

   case _StrBResizeC    :{L++;
			  if (Table[L+1]==_FILENAME)
			  {
			  StrBResizeC(FilesList[FILECNTL-1].NAME,
			  Table[L]);
			  }
			  else
			  {
			  StrBResizeC(STR[Table[L]-40].S,
			  Table[L+1]);
			  }
			  L++; break;
			 }


   case _StrEResizeC    :{L++;
			  if (Table[L+1]==_FILENAME)
			  {
			  StrEResizeC(FilesList[FILECNTL].NAME,
			  Table[L]);
			  }
			  else {
			  StrEResizeC(STR[Table[L]-40].S,
			  Table[L+1]);
			  }
			  L++; break;
			 }

   case _StrBResize     :{L++;
			  if (Table[L+1]==_FILENAME)
			  {
			  StrBResize(FilesList[FILECNTL-1].NAME,
			  Table[L]);
			  }
			  else {
			  StrBResize(STR[Table[L]-40].S,
			  Table[L+1]);
			  }
			  L++; break;
			 }

   case _StrEResize     :{L++;
			  if (Table[L+1]==_FILENAME)
			  {
			  StrEResize(FilesList[FILECNTL-1].NAME,
			  Table[L]);
			  }
			  else {
			  StrEResize(STR[Table[L]-40].S,
			  Table[L+1]);
			  }
			  L++; break;
			 }

   case _ExtractFILE    :{L++;
			  if (Table[L]==_ONE)
			  {
			  if (ExtractFile(_ONE)==0) {return 0;}
			  break;
			  }
			  if (Table[L]==_ALL)
			  {
			  if (!ExtractFile(_ALL)==0) {return 0;}
			  break;
			   }
			  }

   case _LOOP           : L++;
			  K=1;
			  while (Table[L]!=_ENDLOOP)
			  {
			  LoopList[LoopCnt][K]=Table[L];
			  K++; L++;
			  }
			  L++; LoopList[LoopCnt][0]=K;
			  if (dbg) {
				    printf("Processing loop:\n");
				    CheckDebugKey();
				   }

			  if (ProcessLoop(LoopCnt,Table[L],
				      Table[L+1])==0) {return 0;}
			  L++; LoopCnt++;
			  break;

   case _ENDLOOP        : LOOP=0; break;
   case _PROMPTUSER     : if (!PROMPTOVER) PROMPT=1; break;
   case _NOFILENAMES    : L++; FILENAMES=0; break;
  }
  if (ErrorCode) return 0;

  return L;
}

//---------------------------------------------------------------

BYTE PROCESS(BYTE FORMAT)
{
 BYTE IDT[80];

 L=0;

 if (ListFile) printf(" Generating ListFile MULTIEX.LST.\n");
 if (PROMPTOVER) printf(" No messages...\n");



 if ((In=fopen(FileNameIn, "r+b"))==NULL) {ErrorCode=5; return 0;}

   //CheckID Or Not
   //---------------------------------------------------

 if (INIFormats[FORMAT].CheckID)
 {
 fgets(IDT, strlen(INIFormats[FORMAT].ID)+1, In);
 if ((strcmp(INIFormats[FORMAT].ID, IDT))!=0) {ErrorCode=6; return 0;}
 }

   //Process Format Specifiers
   //---------------------------------------------------

 do
 {
  L=Switch(&INIFormats[FORMAT].EVENTS[0], L);
  if (L==0) return 0;
  L++;
 }
 while (L!=INIFormats[FORMAT].EVENTCNT);
 fclose(In);
 return 1;
}

//---------------------------------------------------------------

_SpecType2 GetSpecifiers(BYTE Buffer[80])
{
 BYTE t=0;
 BYTE s=0;
 BYTE k=0;
 _SpecType2 Spef;
 Spef.Specifiers[0][0]=0;
 Spef.Specifiers[1][0]=0;
 Spef.Specifiers[2][0]=0;
 Spef.Specifiers[3][0]=0;
 Spef.Specifiers[4][0]=0;
 Spef.Specifiers[5][0]=0;
 do
 {
  while (((Buffer[t]>63) && (Buffer[t]<123)) ||
	((Buffer[t]>47) && (Buffer[t]<58)))
	{Spef.Specifiers[s][k]=Buffer[t]; t++; k++;}
  if    (((Buffer[t-1]>63) && (Buffer[t-1]<123)) ||
	((Buffer[t-1]>47) && (Buffer[t-1]<58)))
	{Spef.Specifiers[s][k]=0; s++; }
  t++; k=0;
 }
 while (t<=strlen(Buffer));

 return Spef;
}

//---------------------------------------------------------------

BYTE CheckSpecifier(BYTE *Buffer)
{
 _SpecType Duh;
 BYTE T;
 if (dbg) printf("Checking specifiers in EXT-INI file...\n");

 if (strcmp(Buffer, "ID")==0)
   {
    return _ID;
   }

 if ((Buffer[0]>47) && (Buffer[0]<58))
   {
    INIFormats[ExINICnt].EVENTS[EventCnt]=(BYTE) atoi(Buffer);
    EventCnt++;
   }

 if (strcmp(Buffer, "EVENTS")==0)
   { return _Events; }

 if (strcmp(Buffer, "GetLong")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_GetLong;
    EventCnt++;
   }

 if (strcmp(Buffer, "GetString")==0)
   {
   INIFormats[ExINICnt].EVENTS[EventCnt]=_GetString;
    EventCnt++;
   }

 if (strcmp(Buffer, "GoToStart")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_GoToStart;
    EventCnt++;
   }

 if (strcmp(Buffer, "GoToEnd")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_GoToEnd;
    EventCnt++;
   }

 if (strcmp(Buffer, "GoTo")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_GoTo;
    EventCnt++;
   }

 if (strcmp(Buffer, "PROMPTUSER")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_PROMPTUSER;
    EventCnt++;
   }

 if (strcmp(Buffer, "SavePos")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_SavePos;
    EventCnt++;
   }

 if (strcmp(Buffer, "GetInt")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_GetInt;
    EventCnt++;
   }

 if (strcmp(Buffer, "StrBResizeC")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_StrBResizeC;
    EventCnt++;
   }

 if (strcmp(Buffer, "StrEResizeC")==0)
   {
    INIFormats[ExINICnt].EVENTS[EventCnt]=_StrEResizeC;
    EventCnt++;
   }

 if (strcmp(Buffer, "StrBResize")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_StrBResize;
    EventCnt++;
   }

 if (strcmp(Buffer, "StrEResize")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_StrEResize;
    EventCnt++;
   }

 if (strcmp(Buffer, "ExtractFILE")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_ExtractFILE;
    EventCnt++;
   }

 if (strcmp(Buffer, "LOOP")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_LOOP;
    EventCnt++;
   }
 if (strcmp(Buffer, "ENDLOOP")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_ENDLOOP;
    EventCnt++;
   }

 if (strcmp(Buffer, "TAILSIZEB")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_TAILSIZEB;
    EventCnt++;
   }


 if (strcmp(Buffer, "TAILSIZEU")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_TAILSIZEU;
    EventCnt++;
   }

 if (strcmp(Buffer, "TAILOFF")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_TAILOFF;
    EventCnt++;
   }

 if (strcmp(Buffer, "FILESTART")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILESTART;
    EventCnt++;
   }

 if (strcmp(Buffer, "FILESIZE")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILESIZE;
    EventCnt++;
   }

 if (strcmp(Buffer, "FILENAME")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILENAME;
    EventCnt++;
   }
 if (strcmp(Buffer, "NOFILENAMES")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_NOFILENAMES;
    EventCnt++;
   }

 if (strcmp(Buffer, "FILECNT")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILECNT;
    EventCnt++;
   }
 if (strcmp(Buffer, "FILEJMP")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILEJMP;
    EventCnt++;
   }
 if (strcmp(Buffer, "EXTRCNT")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_EXTRCNT;
    EventCnt++;
   }
 if (strcmp(Buffer, "ONE")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_ONE;
    EventCnt++;
   }
 if (strcmp(Buffer, "ALL")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_ALL;
    EventCnt++;
   }
 if (strcmp(Buffer, "FILECNTL")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILECNTL;
    EventCnt++;
   }
 if (strcmp(Buffer, "DUMMYL")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_DUMMYL;
    EventCnt++;
   }
 if (strcmp(Buffer, "DUMMYI")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_DUMMYI;
    EventCnt++;
   }

 if (strcmp(Buffer, "FILEOFF")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_FILEOFF;
    EventCnt++;
   }

 if (strcmp(Buffer, "SETBYTESREAD")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_SETBYTESREAD;
    EventCnt++;
   }

 if (strcmp(Buffer, "SETFILECNT")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_SETFILECNT;
    EventCnt++;
   }

 if (strcmp(Buffer, "BYTESREAD")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_BYTESREAD;
    EventCnt++;
   }
 if (strcmp(Buffer, "UP")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_UP;
    EventCnt++;
   }
 if (strcmp(Buffer, "DOWN")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_DOWN;
    EventCnt++;
   }
 if (strcmp(Buffer, "MULTIPLY")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_MULTIPLY;
    EventCnt++;
   }
 if (strcmp(Buffer, "DIVIDE")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_DIVIDE;
    EventCnt++;
   }
 if (strcmp(Buffer, "ADD")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_ADD;
    EventCnt++;
   }
 if (strcmp(Buffer, "SUBST")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_SUBST;
    EventCnt++;
   }
 if (strcmp(Buffer, "SET")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_SET;
    EventCnt++;
   }
 if (strcmp(Buffer, "NUMBER")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_NUMBER;
    EventCnt++;
   }
 if (strcmp(Buffer, "VAR")==0)
   {INIFormats[ExINICnt].EVENTS[EventCnt]=_VAR;
    EventCnt++;
   }

 return 0;
}

//---------------------------------------------------------------

BYTE *GetString(BYTE BUFFER[80], BYTE Start, BYTE *Buf)
{
 BYTE t, k;
 BYTE Temp[80];
 t=Start; k=0;
 printf("Getting string: \b");
 while ((t<=80) && ((BUFFER[t]<64) && (BUFFER[t]>122))) t++;
 while ((t<=80) && ((BUFFER[t]>63) && (BUFFER[t]<122)))
 {Temp[k]=BUFFER[t]; t++; k++;}
 Temp[k]=0;
 Buf=&Temp[0];
 printf("string gotten: %s\n", Temp);
 return Buf;
}

//---------------------------------------------------------------

BYTE ReadExINI(BYTE *FileName)
{
 _SpecType2 Spec;
 FILE *INI;
 BYTE Buffer[80];
 BYTE CC=0;
 BYTE SPECODE;

 ErrorCode=0; EventCnt=0;

 if ((INI = fopen(FileName, "rt"))==NULL)
  {ErrorCode=OpenExINI; return 0; }

 while ((fgets(Buffer, 80, INI))!=NULL)
 {
  if ((Buffer[0]!=';') && (Buffer[0]!=10))
  {
   Spec = GetSpecifiers(Buffer);
   SPECODE = CheckSpecifier(Spec.Specifiers[0]);

   //---------------------------------------------------

   if (SPECODE==_ID)
   {
    INIFormats[ExINICnt].CheckID=1;
    if ((strcmp(Spec.Specifiers[1], "NONE")!=0) &&
	(strcmp(Spec.Specifiers[1], "NONE")!=0))
    {
    strcpy(INIFormats[ExINICnt].ID, Spec.Specifiers[1]);
    }
    else {INIFormats[ExINICnt].CheckID=0;}
   }

   //---------------------------------------------------

   if (SPECODE==_Events)
   {
    while ((fgets(Buffer, 80, INI))!=NULL)
    {
     if ((Buffer[0]!=';') && (Buffer[0]!=10))
     {
      Spec.Specifiers[0][0]=0;
      Spec.Specifiers[1][0]=0;
      Spec.Specifiers[2][0]=0;
      Spec.Specifiers[3][0]=0;
      Spec.Specifiers[4][0]=0;
      Spec.Specifiers[5][0]=0;
      Spec = GetSpecifiers(Buffer);
      SPECODE = CheckSpecifier(Spec.Specifiers[0]);
      SPECODE = CheckSpecifier(Spec.Specifiers[1]);
      SPECODE = CheckSpecifier(Spec.Specifiers[2]);
      SPECODE = CheckSpecifier(Spec.Specifiers[3]);
      SPECODE = CheckSpecifier(Spec.Specifiers[4]);
      SPECODE = CheckSpecifier(Spec.Specifiers[5]);
      for (CC=0; CC<=80; CC++) Buffer[CC]=0;
     }
    }
   }
  }
 INIFormats[ExINICnt].EVENTCNT=EventCnt;
}
fclose(INI);

return 0;
}

//---------------------------------------------------------------

BYTE ReadINI(BYTE *FileName)
{
 FILE *INI;
 BYTE Buffer[80];
 BYTE NUMBuf[3];
 BYTE *Buf;
 int EqPos;

 ErrorCode=0;


 if ((INI = fopen(FileName, "rt"))==NULL)
  {ErrorCode=OpenMainINI; return 0; }

 ExINICnt=0; ExtenCnt=0;

 while ((fgets(Buffer, 80, INI))!=NULL)
 {
  if ((Buffer[0]!=';') && (Buffer[0]!=10))
  {
   if ((EqPos = strncmp(Buffer, "MULTIEXDIR=", 11))==0)
   {
    Buf=&Buffer[11];
    strcpy(MULTIEXDIR, Buf);
    MULTIEXDIR[strlen(MULTIEXDIR)-1]=0;
   }


   if ((EqPos = strncmp(Buffer, "ExINI", 5))==0)
   {
    EqPos=0;
    while ((Buffer[5+EqPos]!='>') && (EqPos<=80))
    {
     EqPos++;
    }
    if (EqPos>80) {ErrorCode=ErrorInMainINI; return 0;}
    Buf = &Buffer[EqPos+5+2];
    strcpy(INIFormats[ExINICnt].NAME, MULTIEXDIR);
    strcat(INIFormats[ExINICnt].NAME, "CONFIG\\");
    strcat(INIFormats[ExINICnt].NAME, Buf);
    EqPos=strlen(INIFormats[ExINICnt].NAME);
    INIFormats[ExINICnt].NAME[EqPos-1]=0;
    ReadExINI(INIFormats[ExINICnt].NAME);
    ExINICnt++;
   }
   if ((strncmp(Buffer, "EXT=", 4))==0)
   {
    Buf = &Buffer[4];
    strcpy(ExtAss[ExtenCnt].EXT, Buf);
    ExtAss[ExtenCnt].EXT[3]=0;
    EqPos=7;
    while ((Buffer[EqPos]!='>') && (EqPos<=80))
    {
     EqPos++;
    }
    if (EqPos>80) {ErrorCode=ErrorInMainINI; return 0;}
    Buf = &Buffer[EqPos+2];
    strcpy(NUMBuf, Buf);
    ExtAss[ExtenCnt].Format = (BYTE) atoi(Buf);
    if (ExtAss[ExtenCnt].Format==0) {ErrorCode=ErrorInMainINI; return 0;}
    ExtenCnt++;
   }
  }
 }
 fclose(INI);
 return 0;
}

//---------------------------------------------------------------
int ComLineHelp(void)
{
 printf("\nSyntax : multiex [datfile] [extractdir] [switches]\n");
 printf("\nSwitches : \n -l       : generate listfile MULTIEX.LST\n");
 printf(" -debug   : switches debugmode on\n -all     : extracts all (no prompt)");
 printf("\n -f[file] : extract specific file (*.wav, sound.*, sound.wav)");
 printf("\n -i[file] : import specific file (same name as in datfile!)");
 printf("\n -savetemp: saves TEMP.MEX created when importing\n");
 printf("\n -h       : this help text\n");
 return 0;
}

//---------------------------------------------------------------

int GetImFileInfo(void)
{
 FILE *I;

 if ((I=fopen(ImportFile, "rb"))==NULL) {ErrorCode=12; return ErrorCode;}
 fseek(I, 0 , SEEK_END);

 ImFileSize=ftell(I);
 printf(" FileSize:  %lu\n",ImFileSize);
 fclose(I);
 return ErrorCode;
}

//---------------------------------------------------------------

int CheckSwitch(BYTE *Sw)
{
 BYTE Check=0;
 BYTE a[80];
 BYTE b[3];
 BYTE c;
 printf(" Switch  : %s\n", Sw);

 if (strcmp(Sw, "-l")==0)
  {
  ListFile=1;
  Check=1;
  Out = fopen("multiex.lst", "w+b");
 }

 if (strcmp(Sw, "-debug")==0) {Check=1; dbg=1;}

 if (strcmp(Sw, "-savetemp")==0) {Check=1; SAVETEMP=1;}

 if (strcmp(Sw, "-h")==0) {Check=1; ErrorCode=99; ComLineHelp(); return ErrorCode;}

 if (Sw[1]=='f')
 {
  c=0;
  while ((c!=strlen(Sw)) && (Sw[c]!='.')) c++;
  strcpy(FullName, Sw+2);
  if (c==strlen(Sw))
  {
   CheckFull=1; CheckName=1; Check=1;
  }
  else
  {
  strncpy(FPart, Sw+2, c-2); FPart[c-2]=0;
  strcpy(&ExtPart, Sw+c+1);
  c='*';
  if (FPart[0]==c) {CheckExt=1;}
  if (ExtPart[0]==c) {CheckFirst=1;}
  if (CheckExt+CheckFirst==0) {CheckFull=1;}
  if (CheckExt+CheckFirst==2) return 10;
  CheckName=1; Check=1;
  }
 }

 if (Sw[1]=='i')
 {
  strcpy(&ImportFile, &Sw[2]);
  if (GetImFileInfo()) return ErrorCode;
  SizePos=0; OffPos=0; IMPORT=1;
  Check=1;
 }

 if (strcmp(Sw, "-all")==0) {PROMPTOVER=1; All=1; Check=1;}

 if (Check) {return 0;}
 else return 10;
}

//---------------------------------------------------------------

int CreateNewFile(void)
{
 BYTE x, y, ch;
 long d, c, t, a;
 float total, current;
 int c1, c2;

 c2=0;
 In = fopen(FileNameIn, "r+b");
 Out= fopen("temp.mex", "w+b");

 // Get Amount of Free Space on the disk

   a = GetFreeSpace();

 //writing last part of new file as temp.mex

   fseek(In, 0, SEEK_END);
   d=ftell(In)-(OrImFileOff+OrImFileSize);

   if ((d*2)+ImFileSize>a) {ErrorCode=14; return ErrorCode;}
 printf(" Amount of free space for import sufficient.\n");

 printf("\n WARNING! File will be imported! Absolutely sure? (y/n)\n");
 ch = getch();
  switch (ch)
  {
   case 121 : ch=1; break;
   case 110 : ch=0; break;
  }
  if (!ch) {ErrorCode=99; return ErrorCode;}
   printf(" Completed: ");

   fseek(In, OrImFileOff+OrImFileSize, SEEK_SET);
   t=d;

   current=0;
   total= (float) ((d*2)+ImFileSize);

   x=wherex();
   y=wherey();

   do {
    d -= 50000;
    c=50000;
    if (d<0) {c=d+50000;}


   fread(FBuf, c, 1, In);
   if (fwrite(FBuf, c, 1, Out)==0) {ErrorCode=11; return 0;}
   gotoxy(x,y);
   current+=c;
   c1=(int) ((current/total)*100);
   if (c2!=c1) {
   printf("%d %", c1); c2=c1;}
   } while (c==50000);

  fclose(Out);

//  exit(1);



 // importing new file


 fseek(In, OrImFileOff, SEEK_SET);
 TEMPIMP = fopen(ImportFile, "r+b");

   d = ImFileSize;
   do {
    d -= 50000;
    c=50000;
    if (d<0) {c=d+50000;}


   fread(FBuf, c, 1, TEMPIMP);
   if (fwrite(FBuf, c, 1, In)==0) {ErrorCode=11; return 0;}
   gotoxy(x,y);
   current+=c;
   c1=(int) ((current/total)*100);
   if (c2!=c1) {
   printf("%d %", c1); c2=c1;}
   } while (c==50000);

   fclose(TEMPIMP);

//appending part just saved

  Out= fopen("temp.mex", "r+b");
  fseek(Out, 0, SEEK_SET);

   d = t;

   do {
    d -= 50000;
    c=50000;
    if (d<0) {c=d+50000;}


   fread(FBuf, c, 1, Out);
   if (fwrite(FBuf, c, 1, In)==0) {ErrorCode=11; return 0;}
   gotoxy(x,y);
   current+=c;
   c1=(int) ((current/total)*100);
   if (c2!=c1) {
   printf("%d %", c1); c2=c1;}
   } while (c==50000);

   fclose(Out);
   if (!SAVETEMP) unlink("temp.mex");
   fclose(In);
   printf("\n");
   return 0;
}

//---------------------------------------------------------------

long GetFreeSpace(void)
{
struct dfree free;
long avail;
int drive;

drive = getdisk();
getdfree(drive+1, &free);
if (free.df_sclus == 0xFFFF)
{
   printf(" Couldn't check free space\n");
   return 0;
}

avail =  (long) free.df_avail
	 * (long) free.df_bsec
	 * (long) free.df_sclus;

//printf(" Drive %c: has %ld bytes available\n", 'A' + drive, avail);

return avail;
}


int main(int argc, BYTE *argv[])
{
 BYTE EXT[4];
 BYTE NoEx=0;
 BYTE t=0;
 long b;


 strcpy(FileNameIn,argv[1]);

 printf("\nMULTIEX v1.7 SadCom Ltd. Mr.Mouse\n");
 printf("=================================\n");

 if (argc==1) {ComLineHelp(); ErrorCode=5;}

 if (argv[1][0]=='-') ErrorCode = CheckSwitch(argv[1]);

 if ((argv[2][0]=='-') || (argv[2]==NULL)) NoEx=1;

 if (argc>2)
 {
  printf("-Processing Switches :\n");

  if (argv[2][0]=='-') ErrorCode = CheckSwitch(argv[2]);
  t=3;
  while ((t<=argc-1) &&
	 ((ErrorCode = CheckSwitch(argv[t]))==0))
	  t++;
 }

 t=0;

 if (!ErrorCode)
 {
  if (NoEx)
  {
   printf("\n No extraction dir given...assuming rout.\n");
   strcpy(EXTRACTDIR, ".\\");
  }
  else
  {
   strcpy(EXTRACTDIR, argv[2]);
  }

 strupr((BYTE *) FileNameIn);

 EXT[0]=FileNameIn[strlen(FileNameIn)-3];
 EXT[1]=FileNameIn[strlen(FileNameIn)-2];
 EXT[2]=FileNameIn[strlen(FileNameIn)-1];
 EXT[3]=0;

 ReadINI("MULTIEX.INI");

 while ((strcmp(EXT, ExtAss[t].EXT)!=0) && (t!=ExtenCnt+1))
 {t++;}

 if (t>ExtenCnt) {
 printf("Error: %d\n", NoDATFile);
 return NoDATFile;}

 FBuf = malloc(50001);

 FILECNTL=0;
 printf("-Processing Format : \n");

 PROCESS(ExtAss[t].Format-1);

 fclose(In);

 if ((IMPORT) && (IMPDONE)) CreateNewFile();
 if ((IMPORT) && (!IMPDONE)) ErrorCode=13;

 if (Out!=NULL) fclose(Out);
 }
 printf(" Done.\n");
 printf("-Error: %d\n", ErrorCode);

 free(FBuf);
 return ErrorCode;
}

//---------------------------------------------------------------