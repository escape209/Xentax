//Make Dat File...
// SC Ltd.
// 1997

#include "setup.h"
#include "defs.h"
#include "maked1.h"

 BYTE  LBuf[32768];
 void *LoadBuf;
 int   FileNumb=0;
 int   i, OutHandle, DatHandle;
 long  HeaderSize=0;
 BYTE  HeaderName[13]="SadComLtdat";
 BYTE  SetUpText[30]="SystemRequest";
 BYTE OldBuf[4096];
 BYTE Tmp[256];
 FileObj     FileList[100];
 SelectType  SelectList[100];
 unsigned count;
 FILE *MCFile;


int CompletionWindow(BYTE *ExtraMess, int Percent, BYTE New)
{
 int x, y;
 int Nu;
 textbackground(12);
 textcolor(15);
 y=10;
 x=25;
 if (New) {gotoxy(x+4, y+2); cprintf("                      ");}
 textbackground(11);
 gotoxy(x+15, y); cprintf("             ");
 gotoxy(x+15, y); cprintf("%s", ExtraMess);
 Nu=0;
 textcolor(15);
 while (Nu<=Percent/10)
 {
  gotoxy(x+4+(Nu*2), y+2); cprintf("��");
  Nu++;
 }
 textbackground(0);
 return 0;
}
void RemoveWindow(int x1, int y1, int x2, int y2)
{
 puttext(x1, y1, x2+1, y2+1, OldBuf);
}

int PlaceWindow(int x1, int y1, int x2, int y2, BYTE *Title)
{
 int x, y;
 int t;
/* int x1=22;
 int x2=58;
 int y1=8;
 int y2=12;*/
 BYTE ch;
 BYTE Xit=0;
 gettext(x1,y1, x2+1, y2+1, OldBuf);

 textcolor(15);
 textbackground(11);

if (Title[0]=='0') {textbackground(2);}


 for (x=x1; x<=x2; x++)
 {gotoxy(x, y1); cprintf("�");
  gotoxy(x, y2); cprintf("�");}

 for (y=y1; y<=y2; y++)
 {gotoxy(x1, y); cprintf("�");
  gotoxy(x2, y); cprintf("�");}

 gotoxy(x1, y1); cprintf("�");
 gotoxy(x2, y1); cprintf("�");
 gotoxy(x1, y2); cprintf("�");
 gotoxy(x2, y2); cprintf("�");

 textbackground(0);

 for (x=x1+1; x<=x2+1; x++)
 {gotoxy(x, y2+1); cprintf(" ");}

 for (y=y1+1; y<=y2; y++)
 {gotoxy(x2+1, y); cprintf(" ");}

 textcolor(15); textbackground(7);

 for (y=y1+1; y<=y2-1; y++)
 {
  for (x=x1+1; x<=x2-1; x++)
  {
   gotoxy(x,y); cprintf(" ");
  }
 }
 t=(x2-2)-(x1+2);
 for (x=x1+2; x<=x2-2; x++)
 {gotoxy(x, y1+2);
textbackground(7); cprintf(" ");}
if (Title[0]=='0')
{
  x1=(80-strlen(Title)-1+4)/2;
//  x2=x1+strlen(Title)-1+4;
  gotoxy(x1, y1+2);
  textbackground(11);
 cprintf("%s", &Title[1]);
}
else {
 textcolor(15);
 textbackground(11);
 gotoxy(x1+1,y1);
 cprintf("%s", Title);}

 textcolor(15); textbackground(4);

return 0;
}

BYTE* SystemRequest(BYTE *Request, int L)
{
 int Y, i;
 int x;
 char *p;
 char k=0;
 int x1, y1, x2, y2;
 x1=(80-(L+4))/2;
 x2=x1+L+4;
 y1=10; y2=14;

 PlaceWindow(x1, y1, x2, y2, SetUpText);
 textbackground(11);
 textcolor(15);
 Y=y1+(y2-y1)/2-1;
 gotoxy(x1+
	((x2-x1)-strlen(Request))/2, Y);

 if (Request[0]==27) { k=1; cprintf("%s", &Request[1]); }
 else {cprintf("%s", Request); }


 textbackground(0); textcolor(14);
 if (L)
 {
 for (i=x1+2; i<=x1+2+L; i++)
 {gotoxy(i, Y+2); cprintf(" "); }
 }
 else  { textbackground(11);
	 gotoxy(x1+2, Y+2);
	 cprintf("[Y]es / [N]o"); }

 gotoxy(x1+2, Y+2);
 Tmp[0]=L;

 //if k then request is for yes and no
 x=0;
 if (!k)
 {
  while ((x>=0) && (x<=L))
  {
   if (kbhit())
   {
    k = getch();
    switch (k) {
    case 27 : L=0; x=-1; p=NULL; break;
    case 13 : L=x; x=-1; break;
    case 8 : if (x>0) { gotoxy(x1+1+x, y1+3);putch(32);x--;} break;
    }
    if ((k>=33) && (k<=126))
    {
      if (x<L)
      {
      x++;
      gotoxy(x1+1+x, y1+3);
      putch(k);}
    }
   }
//  p = cgets(Tmp);}
  }
  if (L)
  {
    gettext(x1+2, y1+3, x1+L+1, y1+3, Tmp); i=0;
    for (k=0; k<=L; k++)
    {
     p[k]=Tmp[i];
     i+=2;
     }
   p[k-1]=0;
   }
  }
  else { k=getch();
	 p[0]=0;
	 if (k=='y') p[0]=1;
       }
 RemoveWindow(x1, y1, x2, y2);
 return p;

}


void SystemMessage(int x1, int y1, int x2, int y2, BYTE *Message)
{
 PlaceWindow(x1, y1, x2, y2, "System Message:");
 textbackground(8);
 gotoxy(x1+
	((x2-x1)-strlen(Message))/2,
	 y1+(y2-y1)/2);
 cprintf("%s", Message);
 getch();
 textbackground(1); textcolor(1);
 RemoveWindow(x1, y1, x2, y2);
}


int ErrorMessage(BYTE *Mess)
{
    SystemMessage(24, 10, 54, 14, Mess);
    textbackground(1);
    clrscr();
return 0;
}
long GetLong(void)
{
 long TEMP=0;
 long  bah;
 if (!fread(&TEMP, 4, 1, MCFile))
  {
   ErrorMessage("Can't Read MCDATAFile!");
   Abort();
  }
 return TEMP;
}


int GetOnWithIt(BYTE *InstallPath, BYTE *MCDATA)
{
 long fpos;
 FILE *F;
 FILE *Fe;
 BYTE TPath[256];
 BYTE New;
 BYTE noDir;
 int maxp, tt, D;
 long cf=0;
 long FileOff, FileSize;
 long cpos, npos;
 long Total, exbytes, extra;
 int IL;
 BYTE *ExtrName;
 BYTE Check=0;
 BYTE FileName[256];
 BYTE Tmp[12];
  Tmp[11]=0;
  if ((MCFile = fopen(MCDATA, "rb"))==NULL)
   {
    ErrorMessage("Can't Open MCDataFile!"); Abort();
   }
 fread(&Tmp[0], 11, 1, MCFile);
 if ((strcmp(Tmp, HeaderName)))
   { ErrorMessage("Wrong MCDATAFile!"); Abort();}
 fpos = ftell(MCFile) +2;
 fseek(MCFile, fpos, SEEK_SET);
 FileNumb =GetLong();
 cpos = ftell(MCFile);
 strcpy(&TPath[0], &InstallPath[0]);
 IL=strlen(InstallPath);
 while (cf<FileNumb)
 {
//  cpos+=2;
  fseek(MCFile, cpos, SEEK_SET);
  memset(&FileName[0],256,0);
  Check=1;
  Check=fread(&FileName[0], 256, 1, MCFile);
  Check=fread(&FileSize, 4, 1, MCFile);
  Check=fread(&FileOff,4,1,MCFile);
  cpos=ftell(MCFile);
  if (!Check)
   {ErrorMessage("Unable to Get FileInfo!"); Abort();}
  FileName[0]=InstallPath[0];
  ExtrName = SplitPath(FileName);
  noDir=SplitDirs(1);
  if (noDir==255)
   {ErrorMessage("File to Extract Illegal!"); Abort();}
    D = getdisk();
 if (D!=InstallPath[0]-97) setdisk(InstallPath[0]-97);
  chdir(&InstallPath[2]);
  if (cf<FileNumb-1) setdisk(D);
  if (CreateDirs(noDir))
   {ErrorMessage("Can't Create Directory!"); Abort();}

  Total=0;
  New=1; extra=0; Fe=NULL;
  exbytes=32768;
  maxp=FileSize/32768;
  if (!maxp) { exbytes=FileSize; }
  else { extra=(long) (FileSize-(32768*(long) maxp)); maxp--; }
  memset(&TPath[IL],0,256-IL);
  strcat(&TPath[0], &FileName[3]);
  if ((Fe = fopen(TPath, "wb"))==NULL)
   {ErrorMessage("Can't Create File!"); Abort();}
 fseek(MCFile, FileOff, SEEK_SET);

  tt=0;
  while (tt<=maxp)
  {
    fread(LBuf, exbytes, 1, MCFile);

   Total+=exbytes;

    CompletionWindow(ExtrName, (int)
		    (((float) Total/ (float) FileSize)
		     *(float)100), New);
    New=0;
    fwrite(&LBuf, exbytes, 1, Fe);
   tt++;
  }
   if (extra)
   {
    exbytes=extra;
   fread(LBuf, exbytes, 1, MCFile);

   Total+=exbytes;

    CompletionWindow(ExtrName, (int)
		    (((float) Total/ (float) FileSize)
		     *(float)100), New);
    New=0;
    fwrite(&LBuf, exbytes, 1, Fe);
  }
  fclose(Fe);
 cf++;
 }
 fclose(MCFile);

     return 0;
}


int StartExtractingDATFile(BYTE *ExtractDir, BYTE *DATFile)
{


 PlaceWindow(25, 10, 55, 14, "Installing of");

 textbackground(0);

 GetOnWithIt(ExtractDir, DATFile);
// ExtraFiles(ExtractDir, DATFile);

 RemoveWindow(25,10,55,14);


 return 0;
}

