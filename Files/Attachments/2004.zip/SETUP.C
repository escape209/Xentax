#include "setup.h"
#include <PROCESS.H>
#include "maked1.h"
#include "defs.h"
#include <DIR.H>

//typedef struct { BYTE dir[80];} _dirtype;

_dirtype DList[100];
BYTE InstallPath[80];
    BYTE Temp[90];
    char drive[MAXDRIVE];
    char dir[MAXDIR];
    char file[MAXFILE];
    char ext[MAXEXT];
    int flags;
    int Xit=0;
BYTE noDir;
    int Error;
    int CurDr;
    BYTE CurDir[256];
    BYTE *MCCommands[] = { ";MC.INI was was created by MultiEx Commander SETUP v2.0\n",
    "ROOT=" ,"MAINVIEWER=", "FILEFILE=", "EXT=TXT -> ",
		       "EXT=INI -> ", "EXT=DOC -> "};
    BYTE *MEXCommands[] = {";MULTIEX.INI was created by MultiEx Commander SETUP v2.0\n","MULTIEXDIR="};
    BYTE *MCBATCommands[] = {"REM MC.BAT was created by MultiEx Commander SETUP v2.0\nREM XeNTaX 2000\n",
    "SET PATH=", "mcmain.exe\n"};

int SetUpIniFiles(void)
{
 BYTE Check=0;
 FILE *F;
 BYTE *P;
 BYTE Temp[512];
 BYTE MCINI[256];
 BYTE MEXINI[256];
 BYTE MCBAT[256];
 strcat(InstallPath, "mc\\");
 strcpy(MCINI, InstallPath);
 strcpy(MCBAT, InstallPath);
 strcpy(MEXINI, InstallPath);
 strcat(MCINI, "MC.INI");
 strcat(MCBAT, "MC.BAT");
 strcat(MEXINI, "MULTIEX.INI");

 F = fopen(MCINI, "wt");
 if (!F)
  {ErrorMessage("Unable to create INI File!"); Abort();}
 fputs(MCCommands[0], F);
 strcpy(Temp, MCCommands[1]);
 strcat(Temp, InstallPath);
 strcat(Temp, "\n");
 fputs(Temp, F);
 strcpy(Temp, MCCommands[2]);
 strcat(Temp, InstallPath);
 strcat(Temp, "BREAD.EXE\n");
 fputs(Temp, F);
 strcpy(Temp, MCCommands[3]);
 strcat(Temp, InstallPath);
 strcat(Temp, "FILE.MKD\n");
 fputs(Temp, F);
 for (Check=4; Check<=6; Check++)
 {
 strcpy(Temp, MCCommands[Check]);
 strcat(Temp, InstallPath);
 strcat(Temp, "TREAD.EXE\n");
 fputs(Temp, F);
 }
fclose(F);
 F = fopen(MEXINI, "wt");
 fputs(MEXCommands[0], F);
 strcpy(Temp, MEXCommands[1]);
 strcat(Temp, InstallPath);
 strcat(Temp, "\n");
 fputs(Temp, F);
 fclose(F);
 P = getenv("PATH");
 F = fopen(MCBAT, "wt");
 fputs(MCBATCommands[0], F);
 strcpy(Temp, MCBATCommands[1]);
 strcat(Temp, P);
 strcat(Temp, ";");
 strcat(Temp, InstallPath);
 strcat(Temp, ";\n");
 fputs(Temp, F);
 fputs(MCBATCommands[2],F);
 fclose(F);



 return 0;
}

int NormalExit(void)
{
 textbackground(0);
 textcolor(7);
 clrscr();
 printf("Installation Completed. Type MC.BAT to Start!\n");
 _setcursortype(_NORMALCURSOR);
 exit(1);
 return 0;
}
int Abort(BYTE *Mess)
{
 textbackground(0);
 textcolor(7);
  clrscr();
 _setcursortype(_NORMALCURSOR);
 printf("MCSetup did not complete! %s\n", Mess);
 exit(0);
 return 0;
}

int CreateDirs(int noDir)
{
 int x;
 int DriveNumber;
 DriveNumber = getdisk();
 if (DriveNumber!=drive[0]-97) setdisk(drive[0]-97);
 for (x=0; x<=noDir-1; x++)
 {
  mkdir(DList[x].dir);
  chdir(DList[x].dir);
  }
 setdisk(DriveNumber);
return 0;
}
int GetInstallPath(void)
{
 BYTE *P;
 setmem(&InstallPath[0], 80, 0);
 P= SystemRequest("Specify Install Path",54);
 if (P) {
 strcpy(&InstallPath[0], P);}
 else {
  Abort("MCSetup: User aborted setup.");}
return 1;
}



BYTE SplitDirs(BYTE J)
{
 int L;
 int a=0;
 int pos,x, no=0;
 L = strlen(dir);
 pos=0; x=0;
 if (J) a=1;
 while (x<L-1)
 { x++;
  if (dir[x]=='\\')
  {
   memset(&DList[no].dir[0], 0,80);
   strncpy(&DList[no].dir[0], &dir[pos+a], x-pos-a);
   DList[no].dir[x-pos]=0; a=1;
   if (strlen(DList[no].dir)>9) return 255;
   no++; pos=x;
  }
 }
 return no;
}

BYTE* SplitPath(BYTE *TPath)
{
  BYTE File[128];
  flags=fnsplit(TPath,drive,dir,file,ext);
  strcpy(File, file);
  strcat(File, ext);
 return &File[0];
}



int main(void)
{
// BYTE *path;
//  chdir("\\");
  _setcursortype(0);
 strcpy(&CurDir[0], "X:\\");      /* fill string with form of response: X:\ */
 CurDir[0] = 'A' + getdisk();    /* replace X with current drive letter */
 getcurdir(0, &CurDir[3]);  /* fill rest of string with current directory */
 textbackground(1);
 clrscr();
 PlaceWindow(5,3, 75,7, "0MultiEx Commander Version 2.01 SetUp Version 2.0 XeNTaX 2000");
 while (!Xit)
 {
  Xit = GetInstallPath();
  if (InstallPath[strlen(InstallPath)-1]!='\\') InstallPath[strlen(InstallPath)-1]='\\';
  SplitPath(InstallPath);
  noDir = SplitDirs(0);
  if (noDir==255)
   { Xit=0; ErrorMessage("Fault in Path!");
   }
 if (Xit) {
  if(CreateDirs(noDir))
   { Xit=0; ErrorMessage("Can't create Path!");
   }
  }
 }
 if (CurDir[strlen(CurDir)-1]=='\\') { strcat(CurDir, "setup.sad");}
 else { strcat(CurDir, "\\setup.sad");}
 StartExtractingDATFile(InstallPath, CurDir);
 SetUpIniFiles();
 strcpy(Temp, InstallPath);
 strcat(Temp, "TREAD.EXE");
 strcpy(CurDir, InstallPath);
 strcat(CurDir, "README.1ST");
 if ((spawnl(P_WAIT, Temp, (void *) InstallPath, (void *) CurDir, NULL))!=0)
 { ErrorMessage("Could Not Show README!");
 }

 NormalExit();
 return 0;
}