#ifndef QSSHADER_QSMaterialDetailCompose_H
#define QSSHADER_QSMaterialDetailCompose_H

#include "PostFxColor.h"
#include "ColorShifting.h"
#include "CommonNormalFunc.h"
// detail:
// * masked colorize, enabled when mask texture is available
// * masked detailed with texture(diffuse/normal/gloss/specular color), enabled when at least one channel's d/n/g/s/uv is available
//  definition macro
//  DETAIL_MASK_TEXTURE
//  DETAIL_MASK_TEXTURE_R
//  DETAIL_MASK_SPECULAR_R
//  DETAIL_MASK_TEXTURE_G
//  DETAIL_MASK_SPECULAR_G

//  algorithm comments :   replaceMode	//decide if the blending mode is multiply or replace

// texture&constants
sampler2D DetailMaskMap;

sampler2D DetailDiffuseMapR;       
sampler2D DetailMetallicMapR;       
sampler2D DetailNormalMapR;          //xy for normal, z for gloss

sampler2D DetailDiffuseMapG;       
sampler2D DetailMetallicMapG;       
sampler2D DetailNormalMapG;          //xy for normal, z for gloss

float4 DetailUvScaleBiasR;          //xy for bais, zw for scale
float4 DetailUvScaleBiasG;          //xy for bais, zw for scale

float4 DetailDiffuseColorR;			//xyz for diffuse color, w for roughness g
float4 DetailDiffuseColorG;			//xyz for diffuse color, w for roughness g

float4 DetailInfo;//x metallic r, y replacemode r, z metallic g, w replacemode g

#define DetailMetallicR DetailInfo.x
#define DetailReplaceModeR DetailInfo.y
#define DetailMetallicG DetailInfo.z
#define DetailReplaceModeG DetailInfo.w

void ComposeColor(inout float3 srcColor, float3 composeColor, float mask, float replaceMode)
{
	float3 factor = replaceMode!=0.0f ? 1.0f : srcColor;
	srcColor = lerp(srcColor, composeColor*factor, mask);	
}

void ComposeColor(inout float srcColor, float composeColor, float mask, float replaceMode)
{
	float factor = replaceMode!=0.0f ? 1.0f : srcColor;
	srcColor = lerp(srcColor, composeColor*factor, mask);	
}

float3 DetailOverlay(float3 baseColor, float3 detailColor)
{
	const float3 lumCoeff = float3(0.2125 , 0.7154 , 0.0721);
	const float luminance = dot(baseColor.rgb , lumCoeff.rgb);
	const float indexVal = 2.0;
	return (luminance < 0.5) ? (indexVal * detailColor * baseColor) : (1.0 - indexVal*((1.0 - detailColor)*(1.0 - baseColor)));
}

float3 DetailOverlay(float baseColor, float detailColor)
{
    const float indexVal = 2.0;
    return (baseColor < 0.5) ? (indexVal * detailColor * baseColor) : (1.0 - indexVal * ((1.0 - detailColor)*(1.0 - baseColor)));
}

void ComposeNormal(inout float3 normal, float2 detailNormal, float mask, float replaceMode)
{
    //replace on lerp
    if(replaceMode!=1.0f)
    {
        normal.xy = lerp(normal.xy, detailNormal, mask);
        normal.z = sqrt(max(1.0f-dot(normal.xy,normal.xy), 0.0f));
    }
    //compose on base matrix
    else
    {
        float3 detailNormal3 = DecodeNormal(detailNormal.xy);
        detailNormal3 = lerp(float3(0,0,1.0f), detailNormal3, mask);
        detailNormal3 = normalize(detailNormal3);
        normal = ReorientNormal(normal, detailNormal3);       
    }

    normal = normalize(normal);
}

struct MaterialPropertyGGX
{
    float3 Albedo;
    float3 Normal;
    float  Roughness;
    float  Metallic;
};

void ColorizeDetailMapDNGS(
    float2 uv, float mask,
    sampler2D difMap, sampler2D normMap, sampler2D metallicMap, int channelFlag,
    float4 detailUvScaleBias, float3 DetailDiffuseColor, float detailRoughness, float DetailMetallic, float replaceMode,
    inout MaterialPropertyGGX matProp)
{
    float2 detailUv = uv * detailUvScaleBias.zw + detailUvScaleBias.xy;

    //diffuse
#if COLOR_SHIFTING
	ShiftColor(matProp.Albedo, channelFlag, mask);
#else
	float3 dif = tex2D(difMap, detailUv).xyz*DetailDiffuseColor;
	float3 difOverlay = DetailOverlay(matProp.Albedo, dif);
	ComposeColor(matProp.Albedo, difOverlay, mask, replaceMode);
#endif

    //metallic
    float detailMetallic = tex2D(metallicMap, detailUv).x*DetailMetallic;
    ComposeColor(matProp.Metallic, detailMetallic, mask, replaceMode);

    //normal/roughness
    float3 detailNormRoughness = tex2D(normMap, detailUv);

    //normal    
    float2 detailNormXy = detailNormRoughness.xy*2.0f - 1.0f;
#if COLOR_SHIFTING
	
#else
    ComposeNormal(matProp.Normal, detailNormXy, mask, replaceMode);
#endif

    //roughness
    //float detailRoughnessOverlay = DetailOverlay(matProp.Roughness, detailNormRoughness.z);
	float detailRoughnessOverlay = detailNormRoughness.z;
#if COLOR_SHIFTING
	detailRoughnessOverlay = lerp(detailRoughnessOverlay , detailRoughnessOverlay * detailRoughness , mask);
#else
	detailRoughnessOverlay *= detailRoughness;
#endif
    ComposeColor(matProp.Roughness, detailRoughnessOverlay, mask, replaceMode);
}

void ComposeDetail(inout MaterialPropertyGGX matProp, inout float3 spec, float4 uv0)
{
    float3 mask = float3(1.0f, 1.0f, 1.0f);
	float2 uv = float2(1.0f , 1.0f);
	float3 DetailDiffuseSamplerColorR = float3(1.0f, 1.0f, 1.0f);
	float3 DetailDiffuseSamplerColorG = float3(1.0f, 1.0f, 1.0f);
	
#if COLOR_SHIFTING
	uv = uv0.xy;
#else
	uv = uv0.zw;
#endif


#if DETAIL_MASK_TEXTURE
    mask = tex2D(DetailMaskMap, uv).xyz;
#endif

#if DETAIL_MASK_TEXTURE_R
    ColorizeDetailMapDNGS(uv, mask.r,
        DetailDiffuseMapR, DetailNormalMapR, DetailMetallicMapR, 0,
        DetailUvScaleBiasR, DetailDiffuseColorR.xyz, DetailDiffuseColorR.w, DetailMetallicR, DetailReplaceModeR,
        matProp);

#if COLOR_SHIFTING
	DetailDiffuseSamplerColorR = tex2D(DetailDiffuseMapR, uv).xyz;
	ShiftSpec(spec, DetailDiffuseColorR.rgb, mask.r);
	spec = lerp(spec , spec * DetailDiffuseSamplerColorR , mask.r);
#endif

#endif//DETAIL_MASK_TEXTURE_R

#if DETAIL_MASK_TEXTURE_G
    ColorizeDetailMapDNGS(uv, mask.g,
        DetailDiffuseMapG, DetailNormalMapG, DetailMetallicMapG, 1,
        DetailUvScaleBiasG, DetailDiffuseColorG.xyz, DetailDiffuseColorG.w, DetailMetallicG, DetailReplaceModeG,
		matProp);
#if COLOR_SHIFTING
	DetailDiffuseSamplerColorG = tex2D(DetailDiffuseMapG, uv).xyz;
	ShiftSpec(spec, DetailDiffuseColorG.rgb, mask.g);
	spec = lerp(spec , spec * DetailDiffuseSamplerColorG , mask.g);
#endif
#endif//DETAIL_MASK_TEXTURE_G   
}

#endif//QSSHADER_QSMaterialDetailCompose_H