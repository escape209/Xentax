#ifndef QSUTILS_H
#define QSUTILS_H

#ifndef VIEW_PROJ
#define VIEW_PROJ
float4x4 view;
#endif
#include "QSUtils.fxh"

float3 GetCamDir()
{
	return view._m01_m11_m21;
}
float3 GetCamRight()
{
	return view._m00_m10_m20;
}
float3 GetCamUp()
{
    return view._m02_m12_m22;
}

#endif

