#ifndef QSMATERIAL_HAIR_H
#define QSMATERIAL_HAIR_H

#define AlphaTestFactor 1.5f
#define InvAlphaTestFactor (1.0f/1.5f)

//postprocess alpha in lighting, so that the alpha value's smooth, otherwise, there will be a gap which cause bad quality
float AdjustALphaForAlphaTest(float alpha)
{
    return alpha * AlphaTestFactor;
}

void HairAlphaTest(float alpha)
{
    clip(alpha - InvAlphaTestFactor);
}

#endif // QSMATERIAL_HAIR_H
