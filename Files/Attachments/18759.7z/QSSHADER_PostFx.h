#ifndef QSSHADER_PostFx_H
#define QSSHADER_PostFx_H

/**
*   DataStructure definition
*/
#define MAX_SCENE_COLOR 4.0f
struct PosTex
{
    float4 pos:POSITION;
    float2 tex:TEXCOORD0;
};

struct TrackTex
{
	float4 pos : POSITION;
	float3 tex : TEXCOORD0;
};

PosTex PosTexVS(PosTex param)
{
    PosTex result;
    result.pos = float4(param.pos.xyz,1);
    result.tex = param.tex;
    return result;
}

float CalcLuminance(float3 color)
{
    const float3 lumWeight = float3(0.299f,0.587f,0.114f);
    return dot(color, lumWeight);
}



//postfx basic parameter
sampler2D SrcSampler;
sampler2D SrcSamplerLinear;
sampler2D SrcSamplerMask;
float4 BufferResolution;   //xy--resolution, zw---inv resolution
float2 SharpenIntensity;

#if USE_GRAIN_JITTER || USE_GRAIN_INTENSITY || USE_GRAIN_QUANTIZATION
float2 GrainRandomFull;
float3 GrainScaleBiasJitter;
#endif

#if USE_COLOR_FRINGE
float3 ChromaticAberrationParams;
#endif

#if USE_VIGNETTE
float VignetteIntensity;
#endif

//some util funcs
float2 GetScreenUv(float2 vpos)
{
    return (vpos+0.5f)*BufferResolution.zw;
}

#endif //QSSHADER_PostFx_H