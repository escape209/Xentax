#ifndef QSSHADER_QSLighting_H
#define QSSHADER_QSLighting_H
#include "FunctionLib.fxh"
//------------------------------------------------------------------
//--handle lighting
//------------------------------------------------------------------

float CalcFresnel(float3 viewDir, float3 normal, float fresnelFactor, float r0)
{
	//fresnel factor    
	float NDotView = abs(dot(normal,viewDir));
	float fresnelValue = r0 + (1.0f - r0) * pow(max(1.0f - NDotView, 1e-5), fresnelFactor);	
	return fresnelValue;
}

#if FORWARD_LIGHTING || DIR_LIGHT || DISTORTION_MASK
float4 SunLightDir;
float4 SunColor;		//xyz is sun color, w is dir light fresnel
float4 SkyLightColor;		//xyz color, w-specular lighting scaler
float4 GroundLightColor;
//x: SkySpecLightingContrast, y: ambientLighting contrast zw: skin specular lighting factor(gloss and lighting result)
float4 SpecularIndirectLightingEnhance;
float4 SecondDirLightDir;
float4 SecondDirLightColor;


float EnvStrength;
#if ENV_CAPTURE_OUTDOOR || ENV_CAPTURE_INDOOR
float4 EnvIndoorTint;
#define EnvCaptureIndoorAddLight EnvIndoorTint.xyz
#define EnvCaptureIndoorSunLightAdjust EnvIndoorTint.w
float	EnvCaptureSpecAdjust;
#endif

//vegetation light
float4 VegetationLightFactor; //x-direct lighting factor, y-indirect lighting factor

void QSAmbientLighting(
    //output
    out float3 difLighting,
    //in:light property
    float3 skyLightColor, float3 groundLightColor,
    //in:geometry info
    float3 normal, float3 diffuse, float4 indirectSpecEnhance)
{
#if ENHANCE_INDIRECT_LIGHTING	
	float indirectEnhanceConstrast = indirectSpecEnhance.y;	
	float lerpFactor = 0.5f+indirectEnhanceConstrast*0.5f;

	//sky hemisphere light lighting
	float skyLight = max(lerp(1.0f, normal.z, lerpFactor), 0.0f);    
	difLighting = skyLight*skyLightColor;

	//ground light, enhanced ground light color    
	float groundLight = max(lerp(0.75f, -normal.z, lerpFactor), 0.0f);
	difLighting += groundLightColor*groundLight;    	
#else
	//sky hemisphere light lighting
	float skyLight = max(normal.z*0.5f+0.5f, 0.0f);    
	difLighting = skyLight*skyLightColor;

	//ground light, enhanced ground light color    
	float groundLight = max(-normal.z*0.75f+0.25f, 0.0f);
	difLighting += groundLightColor*groundLight;    
#endif

    difLighting *= diffuse;
}

bool IsVegetation(float specAlpha)
{
	// alpha 8bit --xx----
	// xx is vegetation bits
    return specAlpha > 15.5f / 255.f;
}

bool IsVegetationBillBoard(float specAlpha)
{
	// alpha 8bit --x-----
	// x is vegetation billboard bit
    return specAlpha > 47.5f / 255.f;
}


void ScaleVegetationDirectLighting(inout float3 v)
{
    v *= VegetationLightFactor.x;
}

void ScaleVegetationIndirectLighting(inout float3 v)
{
    v *= VegetationLightFactor.y;
}
#endif
#endif //QSSHADER_QSLighting_H