#ifndef QSSHADER_FXPARTICLE_H
#define QSSHADER_FXPARTICLE_H

#include "hash.h"

sampler2D ParticleTex0;
sampler2D ParticleTex1;
float4 ParticleTexRes;
float4 FlipBookInfo;
float4 FlipBookInfo1; // mUseRandomStartFrame
float2 Random;
float4 ParticleTimer;   // mAccumTime, mDeltaTime, lastDeltaTime, mDeltaTime / lastDeltaTime
float4 ParticleIndex;	// beginIndex, newlyIndex, maxCount, 1/(activeCount - 1)

#define ParticleSystemBeginIndex ParticleIndex.x
#define ParticleSystemNewlyIndex ParticleIndex.y
#define ParticleSystemMaxCount ParticleIndex.z
#define ParticleSystemActiveCountCountInv ParticleIndex.w

#define ParticleSystemAccumTime ParticleTimer.x
#define ParticleSystemDeltaTime ParticleTimer.y
#define ParticleSystemLastDeltaTime ParticleTimer.z
#define ParticleSystemDeltaTimeRatio ParticleTimer.w

#define RANDOM_1 (vPos + Random)
#define RANDOM_2 (vPos*2 + Random)
#define RANDOM_3 (vPos*3 + Random)
#define RANDOM_4 (vPos*4 + Random)
#define RANDOM_5 (vPos*5 + Random)
#define RANDOM_6 (vPos*6 + Random)
#define RANDOM_7 (vPos*7 + Random)
#define RANDOM_8 (vPos*8 + Random)
#define RANDOM_9 (vPos*9 + Random)
#define PSEUDO_RANDOM_1 (vPos)
#define PSEUDO_RANDOM_2 (vPos*2)
#define PSEUDO_RANDOM_3 (vPos*3)
#define PSEUDO_RANDOM_4 (vPos*4)
#define PSEUDO_RANDOM_5 (vPos*5)
#define PSEUDO_RANDOM_6 (vPos*6)
#define PSEUDO_RANDOM_7 (vPos*7)
#define PSEUDO_RANDOM_8 (vPos*8)
#define PSEUDO_RANDOM_9 (vPos*9)

#define PARTICLE_STEP 16
#define PresumeFrameRate 40
#define InvPresumeFrameRate 0.025f



//////////////////////////////////////////////////////////////
// xy should be a integer position (e.g. pixel position on the screen)
// similar to a texture lookup but is only ALU

float GetRandom12(float2 xy)
{	
    return hash12(xy);
}

float GetRandom12(float fMin, float fMax, float2 xy)
{	
    return hash12(xy) * (fMax - fMin) + fMin;
}

float2 GetRandom22(float2 xy)
{	
    return hash22(xy);
}

float2 GetRandom22(float fMin, float fMax, float2 xy)
{	
    return hash22(xy) * (fMax - fMin) + fMin;
}

float3 GetRandom32(float2 xy)
{	
    return hash32(xy);
}

float3 GetRandom32(float fMin, float fMax, float2 xy)
{	
    return hash32(xy) * (fMax - fMin) + fMin;
}

//////////////////////////////////////////////////////////////
void CalcAxis1(float3 vDir, out float3 vRight, float3 vTestUp)
{
    float fCheck = dot(vDir, vTestUp);

    if ((-0.99f < fCheck) && (fCheck < 0.99f))
    {
        vRight = cross(vDir, vTestUp);
        vRight = normalize(vRight);
    }
    else        
    {       
        vRight = float3(vDir.y, vDir.z, vDir.x);
    }
}

//////////////////////////////////////////////////////////////
void CalcAxis2(float3 vDir, out float3 vUp, out float3 vRight, float3 vTestUp)
{
    float fCheck = dot(vDir, vTestUp);

    if ((-0.99f < fCheck) && (fCheck < 0.99f))
    {
        vRight = cross(vDir, vTestUp);
        vRight = normalize(vRight);
        vUp = cross(vRight, vDir);
        vUp = normalize(vUp);
    }
    else        
    {       
        vRight = float3(vDir.y, vDir.z, vDir.x);
        vUp = cross(vRight, vDir);
    }
}

////////////////////////////////////////////////////////////////

void SetRotateZ(out float3x3 m, float theta)
{
    float c = cos(theta);
    float s = sin(theta);

    m._m00 = c;
    m._m01 = -s;            
    m._m02 = 0;                

    m._m10 = s;
    m._m11 = c;
    m._m12 = 0;

    m._m20 = 0;
    m._m21 = 0;
    m._m22 = 1;
}

void SetRotateY(out float3x3 m, float theta)
{
    float c = cos(theta);
    float s = sin(theta);

    m._m00 = c;
    m._m01 = 0;            
    m._m02 = s;                

    m._m10 = 0;
    m._m11 = 1;
    m._m12 = 0;

    m._m20 = -s;
    m._m21 = 0;
    m._m22 = c;
}

////////////////////////////////////////////////////////////////

void SetRotate(out float3x3 m, float3 operand, float theta)
{
    float c = cos(theta);
    float s = sin(theta);
    float xx = operand.x * operand.x;
    float yy = operand.y * operand.y;
    float zz = operand.z * operand.z;
    float xy = operand.x * operand.y;
    float yz = operand.y * operand.z;
    float xz = operand.x * operand.z;
    float xs = operand.x * s;
    float ys = operand.y * s;
    float zs = operand.z * s;
    float _c = 1 - c;

    m._m00 = xx * _c + c;
    m._m01 = xy * _c + zs;            
    m._m02 = xz * _c - ys;                

    m._m10 = xy * _c - zs;
    m._m11 = yy * _c + c;
    m._m12 = yz * _c + xs;

    m._m20 = xz * _c + ys;
    m._m21 = yz * _c - xs;
    m._m22 = zz * _c + c;
}

////////////////////////////////////////////////////////////////////////////////////////////

float2 GetParticleTexUV(float2 vPos)
{
    return (vPos + 0.5f) * ParticleTexRes.zw;
}

void GetDataFromParticleTex(float4 uv, out float3 pos, out float3 velocity, out float starTime, out float life)
{
    float4 tex0 = tex2Dlod(ParticleTex0, uv);
    float4 tex1 = tex2Dlod(ParticleTex1, uv);
    pos = tex0.xyz;
    starTime = tex0.w;
#if STATE_INDEPENDENT
    velocity = (pos - tex1.xyz) * PresumeFrameRate;
#else
    velocity = (pos - tex1.xyz) / ParticleSystemDeltaTime;
#endif
    life = tex1.w;
}

float3 GetPosFromParticleTex(float4 uv)
{
    return tex2Dlod(ParticleTex0, uv).xyz;
}
/////////////////////////////////////////////

float3 GetPosFromParticleTex(float2 uv)
{
    return tex2D(ParticleTex0, uv).xyz;
}
float3 GetVelocityFromParticleTex(float2 uv)
{
    float4 tex0 = tex2D(ParticleTex0, uv);
    float4 tex1 = tex2D(ParticleTex1, uv);
    return (tex0.xyz - tex1.xyz) / ParticleSystemDeltaTime;
}
void GetPosVelocityFromParticleTex(float2 uv, out float3 pos, out float3 velocity)
{
    float4 tex0 = tex2D(ParticleTex0, uv);
    float4 tex1 = tex2D(ParticleTex1, uv);
    pos = tex0.xyz;
    velocity = (pos - tex1.xyz) / ParticleSystemDeltaTime;
}

///////////////////////////////////////////////////////////////////////

float4 CalcTexTransform(int flipBookFrame)
{
#if FLIPBOOK
    float4 texTransform;			
    texTransform.x = 1.0f / FlipBookInfo.y;
    texTransform.y = 1.0f / FlipBookInfo.z;
    texTransform.z = texTransform.x * (flipBookFrame % int(FlipBookInfo.y));
    texTransform.w = texTransform.y * (flipBookFrame / int(FlipBookInfo.y));

    texTransform.z += texTransform.x * 0.5f;
    texTransform.w += texTransform.y * 0.5f;
    texTransform.y = - texTransform.y;
    return texTransform;
#else
    return float4(1, -1, 0.5f, 0.5f);
#endif
}

///////////////////////////////////////////////////////////////////////

float CalcAgeLerp(float age, out int a, out int b)
{
    float s = age * (PARTICLE_STEP - 1);
    a = int(floor(s));
    b = int(ceil(s));
    s -= a; 
    return s;
};

///////////////////////////////////////////////////////////////////////

//距离最后生成的粒子的id偏移
int GetOffsetFormNewly(float2 vPos)
{
   return ParticleSystemNewlyIndex - (vPos.y * ParticleTexRes.x + vPos.x);
};

int GetOffsetFormBegin(float2 vPos)
{
    return (vPos.y * ParticleTexRes.x + vPos.x) - ParticleSystemBeginIndex;
};

//index: 距离粒子的begin偏移: return xy: uv, zw: vPos
float4 GetParticleTexUVFromBeginOffset(float4 particleIndex, int index)
{
	index += particleIndex.x;
    float4 result;
    int width = ParticleTexRes.x;
    result.z = index % width;
    result.w = index / width;
    result.xy = GetParticleTexUV(result.zw);
    return result;
}

float4 GetParticleTexUVFromNewlyOffset(float4 particleIndex, int index)
{
    index = particleIndex.y - index;
    if (index < particleIndex.x)
    {
        index += particleIndex.z;
    }

    float4 result;
    int width = ParticleTexRes.x;
    result.z = index % width;
    result.w = index / width;
    result.xy = GetParticleTexUV(result.zw);
    return result;
}

///////////////////////////////////////////////////////////////////////

float3 SafeNormalize(float3 v)
{
    float distance = length(v) + (1e-7);
    return v * (1 / distance);
}

///////////////////////////////////////////////////////////////////////

bool UseRandomStartFrame()
{
    return FlipBookInfo1.x > 0.5;
}

#endif//QSSHADER_FXPARTICLE_H