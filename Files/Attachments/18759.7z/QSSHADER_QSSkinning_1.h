#ifndef QSSHADER_QSSkinning_H
#define QSSHADER_QSSkinning_H

//We will use texture bone now. so, just use SkinBone as PreSkinBone.
//It will cause to much constant buffer.
//float4x3 PreSkinBone[MAX_BONES];

sampler2D	BoneTex;
sampler2D	PreBoneTex;
float4		BoneTexUv; //xy: current frame boneUV, zw: previous frame boneUV

#define BONE_NUM_WIDTH 128.0f
#define BONE_WIDTH (BONE_NUM_WIDTH*3)
float4x3 ReadBoneData(int i)
{
	float4 uv = float4(BoneTexUv.xy, 0, 0);
	uv.x += i/BONE_NUM_WIDTH;
	
	float4x3 result;
	float4 v0 = tex2Dlod(BoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v1 = tex2Dlod(BoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v2 = tex2Dlod(BoneTex, uv).rgba;
	
	result._m00_m10_m20_m30 = v0;	
	result._m01_m11_m21_m31 = v1;
	result._m02_m12_m22_m32 = v2;
	return result;
}

float4x3 ReadBoneData(int i, float2 boneUv)
{
	float4 uv = float4(boneUv,0.0f,0.0f);
	uv.x += i/BONE_NUM_WIDTH;

	float4x3 result;
	float4 v0 = tex2Dlod(BoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v1 = tex2Dlod(BoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v2 = tex2Dlod(BoneTex, uv).rgba;

	result._m00_m10_m20_m30 = v0;	
	result._m01_m11_m21_m31 = v1;
	result._m02_m12_m22_m32 = v2;
	return result;
}

float4x3 DecompressSkinBoneMat( float4x3 vectors )
{
	return vectors;
}

float4 DecompressBlendWeights( int4 val )
{
	float4 weights;
	weights.xyzw = val.xyzw * 0.003921569f;
	//weights.w = min(0.0f, abs(1.0f - weights[0] - weights[1] - weights[2]) );

	return weights;
}

float4x3 SkinMatrixCalc(float3 blendWeight,int4 blendIndices)
{
	float4x3 SkinBoneTransform;

	float weight4 = 1.0f - blendWeight[0] - blendWeight[1] - blendWeight[2];

	SkinBoneTransform = blendWeight[0] * ReadBoneData(blendIndices[0]);
	SkinBoneTransform += blendWeight[1] * ReadBoneData(blendIndices[1]);
	SkinBoneTransform += blendWeight[2] * ReadBoneData(blendIndices[2]);
	SkinBoneTransform += weight4 * ReadBoneData(blendIndices[3]);
	return SkinBoneTransform;
}

float4x3 SkinMatrixCalc(float3 blendWeight,int4 blendIndices, float2 boneUv)
{
	float4x3 SkinBoneTransform;

	float weight4 = 1.0f - blendWeight[0] - blendWeight[1] - blendWeight[2];

	SkinBoneTransform  = blendWeight[0] * ReadBoneData(blendIndices[0], boneUv);
	SkinBoneTransform += blendWeight[1] * ReadBoneData(blendIndices[1], boneUv);
	SkinBoneTransform += blendWeight[2] * ReadBoneData(blendIndices[2], boneUv);
	SkinBoneTransform += weight4 * ReadBoneData(blendIndices[3], boneUv);
	return SkinBoneTransform;
}

float4x3 SkinMatrixCalcCompressed(int4 blendWeight,int4 blendIndices)
{
	float4x3 SkinBoneTransform;

	float4 weight = DecompressBlendWeights( blendWeight );
	SkinBoneTransform = weight[0] * ReadBoneData(blendIndices[0]);
	SkinBoneTransform += weight[1] * ReadBoneData(blendIndices[1]);
	SkinBoneTransform += weight[2] * ReadBoneData(blendIndices[2]);
	SkinBoneTransform += weight[3] * ReadBoneData(blendIndices[3]);
	return SkinBoneTransform;
}

float4x3 SkinMatrixCalcCompressed(int4 blendWeight,int4 blendIndices,float2 boneUv)
{
	float4x3 SkinBoneTransform;

	float4 weight = DecompressBlendWeights( blendWeight );
	SkinBoneTransform  = weight[0] * ReadBoneData(blendIndices[0], boneUv);
	SkinBoneTransform += weight[1] * ReadBoneData(blendIndices[1], boneUv);
	SkinBoneTransform += weight[2] * ReadBoneData(blendIndices[2], boneUv);
	SkinBoneTransform += weight[3] * ReadBoneData(blendIndices[3], boneUv);
	return SkinBoneTransform;
}


float4x3 ReadPreBoneData(int i)
{
	float4 uv = float4(BoneTexUv.zw, 0, 0);
	uv.x += i/BONE_NUM_WIDTH;
	
	float4x3 result;
	float4 v0 = tex2Dlod(PreBoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v1 = tex2Dlod(PreBoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v2 = tex2Dlod(PreBoneTex, uv).rgba;
	
	result._m00_m10_m20_m30 = v0;	
	result._m01_m11_m21_m31 = v1;
	result._m02_m12_m22_m32 = v2;
	return result;
}

float4x3 ReadPreBoneData(int i, float2 boneUv)
{
	float4 uv = float4(boneUv,0.0f,0.0f);
	uv.x += i/BONE_NUM_WIDTH;

	float4x3 result;
	float4 v0 = tex2Dlod(PreBoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v1 = tex2Dlod(PreBoneTex, uv).rgba;	
	uv.x +=1.0f/BONE_WIDTH;
	float4 v2 = tex2Dlod(PreBoneTex, uv).rgba;

	result._m00_m10_m20_m30 = v0;	
	result._m01_m11_m21_m31 = v1;
	result._m02_m12_m22_m32 = v2;
	return result;
}

float4x3 PreSkinMatrixCalc(float3 blendWeight,int4 blendIndices)
{
	float4x3 SkinBoneTransform;

	float weight4 = 1.0f - blendWeight[0] - blendWeight[1] - blendWeight[2];

	SkinBoneTransform = blendWeight[0] * ReadPreBoneData(blendIndices[0]);
	SkinBoneTransform += blendWeight[1] * ReadPreBoneData(blendIndices[1]);
	SkinBoneTransform += blendWeight[2] * ReadPreBoneData(blendIndices[2]);
	SkinBoneTransform += weight4 * ReadPreBoneData(blendIndices[3]);
	return SkinBoneTransform;
}

float4x3 PreSkinMatrixCalc(float3 blendWeight,int4 blendIndices, float2 boneUv)
{
	float4x3 SkinBoneTransform;

	float weight4 = 1.0f - blendWeight[0] - blendWeight[1] - blendWeight[2];

	SkinBoneTransform  = blendWeight[0] * ReadPreBoneData(blendIndices[0], boneUv);
	SkinBoneTransform += blendWeight[1] * ReadPreBoneData(blendIndices[1], boneUv);
	SkinBoneTransform += blendWeight[2] * ReadPreBoneData(blendIndices[2], boneUv);
	SkinBoneTransform += weight4 * ReadPreBoneData(blendIndices[3], boneUv);
	return SkinBoneTransform;
}

float4x3 PreSkinMatrixCalcCompressed(int4 blendWeight,int4 blendIndices)
{
	float4x3 SkinBoneTransform;

	float4 weight = DecompressBlendWeights( blendWeight );
	SkinBoneTransform = weight[0] * ReadPreBoneData(blendIndices[0]);
	SkinBoneTransform += weight[1] * ReadPreBoneData(blendIndices[1]);
	SkinBoneTransform += weight[2] * ReadPreBoneData(blendIndices[2]);
	SkinBoneTransform += weight[3] * ReadPreBoneData(blendIndices[3]);
	return SkinBoneTransform;
}

float4x3 PreSkinMatrixCalcCompressed(int4 blendWeight,int4 blendIndices,float2 boneUv)
{
	float4x3 SkinBoneTransform;

	float4 weight = DecompressBlendWeights( blendWeight );
	SkinBoneTransform  = weight[0] * ReadPreBoneData(blendIndices[0], boneUv);
	SkinBoneTransform += weight[1] * ReadPreBoneData(blendIndices[1], boneUv);
	SkinBoneTransform += weight[2] * ReadPreBoneData(blendIndices[2], boneUv);
	SkinBoneTransform += weight[3] * ReadPreBoneData(blendIndices[3], boneUv);
	return SkinBoneTransform;
}


#endif//QSSHADER_QSSkinning_H