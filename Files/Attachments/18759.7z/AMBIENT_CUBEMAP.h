#ifndef AMBIENT_CUBEMAP_H
#define AMBIENT_CUBEMAP_H 

#include "QSConstant.fxh"

#if FILTER_IBL || FILTER_LATLONG 
#define HAMMERSLEY_MAP_LENGTH			(256)

float4 PackedParams;
#define fRoughness			(PackedParams.x)
#define fSampleNums			(PackedParams.y)

Texture2D HammersleyMap;

#if FILTER_IBL
// for cube
TextureCube AmbientCubeMap;
#endif

#if FILTER_LATLONG
// for lat long
Texture2D AmbientSrcSampler;
#endif

float3 TangentToWorld(float3 Vec, float3 N)
{
    float3 UpVector = abs(N.z) < 0.999 ? float3(0, 0, 1) : float3(1, 0, 0);
    float3 TangentX = normalize(cross(UpVector, N));
    float3 TangentY = cross(N, TangentX);
    return TangentX * Vec.x + TangentY * Vec.y + N * Vec.z;
}

float D_GGX(in float roughness, in float ndotH)
{
    float m = roughness * roughness;
    float m2 = m * m;
    float denominator = (ndotH*ndotH)*(m2 - 1) + 1;
    denominator *= denominator * PI;
    return m2 / denominator;
}

float3 ImportanceSampleGGX(float2 E, float Roughness)
{
    float m = Roughness * Roughness;
    float m2 = m * m;

    float Phi = 2 * PI * E.x;
    float CosTheta = sqrt((1 - E.y) / (1 + (m2 - 1) * E.y));
    float SinTheta = sqrt(1 - CosTheta * CosTheta);

    float3 H;
    H.x = SinTheta * cos(Phi);
    H.y = SinTheta * sin(Phi);
    H.z = CosTheta;

    return H;
}

float sampleHammersleyMap(int Index)
{
    float4 uv = float4((Index + 0.5) / HAMMERSLEY_MAP_LENGTH, 0.5, 0, 0);
    return tex2Dlod(HammersleyMap, NoMipMapPointClamp, uv).r;
}

float2 Hammersley(int Index, int NumSamples)
{
    float E1 = (float)Index / NumSamples;
    float E2 = sampleHammersleyMap(Index);
    return float2(E1, E2);
}

float3 prefilterEnv(float Roughness, float3 R)
{
    float3 N = R;
    float3 V = R;
    float3 PrefilteredColor = 0;
    float2 Xi = 0;
    int iNumSamples = fSampleNums;
    float TotalWeight = 0;
    [loop] for (int i = 0; i < iNumSamples; i++)
    {
        float2 Xi = Hammersley(i, iNumSamples);
        float3 H = TangentToWorld(ImportanceSampleGGX(Xi, Roughness), N);
        float fNdotH = saturate(dot(H, N));
        float fVdotH = saturate(dot(H, V));
        float3 L = 2 * dot(V, H) * H - V;
        float fNoL = saturate(dot(N, L));
        float fHoL = saturate(dot(H, L));
        // Probability Distribution Function
        float fPdf = D_GGX(fRoughness, fNdotH)  * fNdotH / (4.0f * fHoL);
        if (fNoL > 0)
        {

#if FILTER_IBL
            PrefilteredColor += texCUBElod(AmbientCubeMap, MipMapLinear, float4(L, 0)) * fNoL;
#endif

#if FILTER_LATLONG // lat-long texture
            float2 uv;
            uv.x = 1.0f - (atan2(L.y, L.x)) / TwoPi;
            uv.y = acos(L.z) / PI;
            PrefilteredColor += AmbientSrcSampler.SampleLevel(MipMapLinear, uv, 0) * fNoL;
#endif

            TotalWeight += fNoL;
        }
    }
    return PrefilteredColor / max(TotalWeight, 0.001);
}
#endif

#endif