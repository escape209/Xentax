#ifndef QSSHADER_QSHairScatter_H
#define QSSHADER_QSHairScatter_H

#include "DX12Defines.fxh"

/*
*   full lighting       normal mapping, shadowing
*   normal map 			if disable, will disable specular lighting too
*   shadow              depth only, possible with alpha test
*/
struct VsIn
{
    half4 pos:             		POSITION;   

#if ALPHATEST || LIGHTING || HAIR_WIND_INTENSITY
	float2 uv0:					TEXCOORD0;    //alpha test always enable for current
#endif//ALPHATEST||LIGHTING

#if SECOND_UV || HAIR_WIND_INTENSITY
	float2 uv1:					TEXCOORD1;
#endif
#if SKINNING
	#if VERTEX_COMPRESSION
		int4   blendWeight :    BLENDWEIGHT;
	#else
		float3 blendWeight :    BLENDWEIGHT;
	#endif//VERTEX_COMPRESSION
    int4   blendIndices:    	BLENDINDICES;
#endif//SKINNING
    
#if LIGHTING || SVOGI
	#if VERTEX_COMPRESSION		
			int4 normal:		NORMAL;				
			int4 binormal:      BINORMAL;
			int4 tangent:       TANGENT;
	#else
			float3 normal:		NORMAL;		
		#if APEX_CLOTH
			float4 tangent:     TANGENT;
		#else
			float3 binormal:    BINORMAL;
			float3 tangent:     TANGENT;
		#endif
	#endif//VERTEX_COMPRESSION	
#endif//LIGHTING		

#undef COLOR

#if WIND || CLOTH_WIND
#if VERTEX_COMPRESSION
			int4   vertexColor :    COLOR;
#else
			float3 vertexColor :    COLOR;
#endif //VERTEX_COMPRESSION
#endif // WIND

#define COLOR           SV_Target0

};


struct VsOut 
{
    float4 pos		:		POSITION;

#if ALPHATEST || LIGHTING || HAIR_WIND_INTENSITY
	#if SECOND_UV || HAIR_WIND_INTENSITY
		float4 uv0 :		TEXCOORD0;
	#else
		float2 uv0 :		TEXCOORD0;
	#endif
#endif//ALPHATEST||LIGHTING

#if LIGHTING
    float3 normal  :        TEXCOORD1;     
	float3 tangent :		TEXCOORD3;    //normal mapping
	float3 binormal:		TEXCOORD4;    //normal mapping        
#else
    #if (DEPTH && WRITE_VELOCITY)
		float4 curPos : TEXCOORD5;
		float4 prePos : TEXCOORD6;	
	#endif
	#if SVOGI
		float3 normal  :        TEXCOORD1;
		#if CLOTH_WIND
			float4 smoothNormal :    COLOR0;
			float4 wrinkleParam :	COLOR1;
		#endif // CLOTH_WIND
	#endif
	
#endif//LIGHTING

#if FORWARD_LIGHTING
	float3 worldPos			: TEXCOORD5;	
	#if HW_REGULAR_PCF || ELECTRONIZE
		float4 projPos		: TEXCOORD6;
	#endif//HW_REGULAR_PCF

	#undef COLOR0
	#undef COLOR1

		#if CLOTH_WIND
			float4 smoothNormal :    COLOR0;
			float4 wrinkleParam :	COLOR1;
		#endif // CLOTH_WIND

	#define COLOR0          SV_Target0
	#define COLOR1          SV_Target1

#endif
#if ELECTRONIZE
		float3 objPos : TEXCOORD7;
#endif
	float2  homoDepth	: TEXCOORD8;
};

#endif // QSSHADER_QSHairScatter_H
