#ifndef QSSHADER_COMMON_CONST_H
#define QSSHADER_COMMON_CONST_H

//ATTENTION HERE
//in this file, we only define some common const, 
//only define const here, nothing else, to avoid unnecessary const include 
#define COLOR_LUT_RESOLUTION 32


#endif //QSSHADER_COMMON_CONST_H