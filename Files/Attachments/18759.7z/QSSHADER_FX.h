#ifndef QSSHADER_FX_H
#define QSSHADER_FX_H

#define HW_REGULAR_PCF 1
#define CSM_4 1 // we lack of shader macro, receive shadow always use CSM_4

#include "QSConstant.h"
#include "QSPhysicalLighting.h"
#include "PostFx.h"
#include "QSShaderAtmosphere.h"
#include "QSLighting.h"
#include "QSScreenSpaceDepth.h"
#include "QSMaterialCommon.h"
#include "QSDeferredLighting.h"
#include "FxShadow.h"

#if DISTORTION_MASK
sampler2D DistortionMaskSampler;
#endif

#if NORMAL_MAP
sampler2D NormalSampler;
#endif

#if SPECULAR_MAP
sampler2D SpecularMap;
#endif

#if MASK_MAP
sampler2D MaskSampler;
float4 MaskMapRotation;
#endif

#if UV_MAP
sampler2D UVSampler;
float4 UVMapRotation;
#endif

#if DETAIL_MAP
sampler2D DetailSampler;
float4 DetailMapRotation;
#endif

#if ENV_MAP
samplerCUBE EnvSampler;
#endif

#if LIGHTMASK_MAP
sampler2D LightMaskSampler;
float4 LightMaskDarkness;
#endif

#if GRADIENT_MAP_NORMALDOTVIEW || GRADIENT_MAP_ALPHATESTREF
sampler2D GradientSampler;
#endif

#if DEFORM
float4 DeformInfo;
#endif

#if MASK_MAP_EDGE_NORMAL
float4 EdgeNormalData;
#endif

#if !LIGHTING
float3 FxLightColor;
#endif

float4 BaseUVRotation;
float4 DiffuseColor;
float4 SpecularColor;
float4 EnvColor;

float4 UVOffset0;
float4 UVOffset1;
float4 UVOffset0FrameInterpolation;
float4 MaterialData0;
float4 MaterialData1;
float4 MaterialData2;
float4 MaterialData3;

#define BaseUVOffset	UVOffset0.xy
#define MaskMapOffset	UVOffset0.zw
#define DetailMapOffset	UVOffset1.xy
#define UVMapOffset		UVOffset1.zw
#define BaseUVOffset_NextFrame	(UVOffset0FrameInterpolation.xy)
#define FrameInterpolationValue	(UVOffset0FrameInterpolation.z)
#define UVMapIntensity	EnvColor.w
#define DeformFreq			DeformInfo.x
#define DeformAmp0			DeformInfo.y
#define DeformAmp1			DeformInfo.z
#define DeformWavelenInc	DeformInfo.w

#define DistortionWeight	MaterialData0.x
#define SoftEdge			MaterialData0.y
#define SoftDepth			MaterialData0.z
#define AlphaTestRef		MaterialData0.w
#define FadeBegin			MaterialData1.xy
#define FadeRange			MaterialData1.zw
#define RefractionIndex			MaterialData2.x
#define RefractionAlpha			MaterialData2.y
#define SoftDepthLerp			MaterialData2.z // [shunleitang]
#define SoftDepthFade			MaterialData2.w // [shunleitang]
#define ShadowRatio             (MaterialData3.x)   
#define EdgeNormalRange			EdgeNormalData.x
#define EdgeNormalFlat			EdgeNormalData.y
#define MaskMapEdgeNormalResW	EdgeNormalData.z
#define MaskMapEdgeNormalResH	EdgeNormalData.w

struct VSOutBase
{
    float4 pos			: POSITION;
    float2 tex			: TEXCOORD0;
    float3 norm			: NORMAL;
    float3 tangent		: TANGENT;
};


/////////////////////////////////////////////////////////////////////
#if DISTORTION_MASK

#if MASK_MAP
    float4 DistortionPS(float2 uvDistortionMap, float2 uvMaskMap)
    {	
        float4 color;
        color = tex2D(DistortionMaskSampler, uvDistortionMap);
        float fade = tex2D(MaskSampler, uvMaskMap).a;
        color.rg = (color.rg - 0.5f) * DistortionWeight * fade + 0.5f;
        color.a *= fade;

        return color;
    }
#else
    float4 DistortionPS(float2 uvDistortionMap)
    {	
        float4 color;
        color = tex2D(DistortionMaskSampler, uvDistortionMap);
        color.rg = (color.rg - 0.5f) * DistortionWeight + 0.5f;
        return color;
    }
#endif

#endif
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
#if LIGHTMASK_MAP

	#define LightMaskBrightDir (normalize(float2(-1, -1)))

	float3 Rotate(float3 from, float3 to, float3 pos)
	{
		const float3 hv = normalize(from + to);

		const float qs = dot(from, hv);
		const float3 qv = cross(from, hv);

		return (qs * qs - dot(qv, qv)) * pos + 2 * qs * cross(qv, pos) + 2 * dot(qv, pos) * qv;
	}

	float4 ComputeLightMaskUV(float3 worldNormal, float3 worldBinorm, float3 worldTangent, float3 worldSunLightDir, float2 localPos)
	{
		const float3x3 invTBN = transpose(float3x3(worldTangent, worldBinorm, worldNormal));
		const float2 sunLightDirTS = mul(-worldSunLightDir, invTBN).xy;
		const float sunLightStrength = length(sunLightDirTS);
		const float2 sunLightDir = normalize(sunLightDirTS);

		const float2 pUv = localPos;
		const float3 rotUv = Rotate(float3(sunLightDir, 0), float3(LightMaskBrightDir, 0), float3(pUv, 0)) + 0.5;

		return float4(rotUv.xy, 0, sunLightStrength);
	}

#endif
/////////////////////////////////////////////////////////////////////

struct FxParam
{
    float4 color		    : COLOR0;
#if DISTORTION_MASK || BASE_MAP || NORMAL_MAP || SPECULAR_MAP
    float2 uv_BaseUV		: TEXCOORD0;
	#if FLIPBOOK_FRAME_INTERPOLATION
        float2 uv_BaseUV_NextFrame		: TEXCOORD10;
	#endif
#endif

#if MASK_MAP || UV_MAP
    float4 mapUV_Mask_UV    : TEXCOORD1;
#endif

#if DETAIL_MAP
    float2 mapUV_Detail	: TEXCOORD2;
#endif

#if DEPTH_SOFT || VIEW_SOFT
    float viewDepth		: TEXCOORD3;
#endif

#if (LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT || LIGHTMASK_MAP
    float3 worldNormal  : TEXCOORD4;
    #if ((LIGHTING || ENV_MAP || REFRACTION) && NORMAL_MAP) || MASK_MAP_EDGE_NORMAL || LIGHTMASK_MAP
        float3 worldTangent : TEXCOORD5;
        float3 worldBinorm	: TEXCOORD6;
    #endif
#endif

#if FORWARD_LIGHTING || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT
    float3 toCamera  : TEXCOORD7;
#endif

#if GRADIENT_MAP_NORMALDOTVIEW
	float uvY  : TEXCOORD8;
#endif	 

#if LIGHTMASK_MAP
    float4 uv_LightMaskUV   : TEXCOORD9;
#endif

#if RECV_SHADOW
    float4 devicePos	: TEXCOORD11;
#endif

};

struct FxPsOut
{
    float4 color : COLOR0;

#if LIGHTING && !FORWARD_LIGHTING
	float4 norm     : COLOR1;
	float4 specular : COLOR2;
#endif
};

/////////////////////////////////////////////////////////////////////

void ConstructFxParam(inout FxParam result)
{
	result.color = 1;

#if DISTORTION_MASK || BASE_MAP || NORMAL_MAP || SPECULAR_MAP
	result.uv_BaseUV = 0;
#endif

#if MASK_MAP || UV_MAP
	result.mapUV_Mask_UV = 0;
#endif

#if DETAIL_MAP
	result.mapUV_Detail = 0;
#endif

#if DEPTH_SOFT || VIEW_SOFT
	result.viewDepth = 0;
#endif

#if (LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT || LIGHTMASK_MAP
	result.worldNormal = 1;
	#if ((LIGHTING || ENV_MAP || REFRACTION) && NORMAL_MAP) || MASK_MAP_EDGE_NORMAL || LIGHTMASK_MAP
		result.worldTangent = 1;
		result.worldBinorm = 1;
	#endif       
#endif

#if FORWARD_LIGHTING || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW
	result.toCamera = 1;      
#endif

#if GRADIENT_MAP_NORMALDOTVIEW
	result.uvY = 1;      
#endif

#if RECV_SHADOW
    result.devicePos = 1;
#endif

}

/////////////////////////////////////////////////////////////////////
#include "QSUnderWater.h"

void WaterFog(inout float3 color, float3 viewDir, float3 attenuation)
{
	float angle = -dot(RefractSunOrMoonDir, viewDir);
	float g = 0.9 - 0.9 * attenuation.y;
	float phase = MiePhase(angle, g);
	{
  		float3 fogColor = phase * UnderWaterFogColor * attenuation.y;
  		color = lerp(fogColor, color, attenuation.z);
	}
}

void ApplyWaterFog(inout float3 color, float3 worldPos, float3 viewDir, float3 toCamera)
{
	float viewDist = length(toCamera);

	float surfacePointToWaterPlaneHeight = WaterHeight - worldPos.z;
	float viewPointToWaterPlaneHeight = WaterHeight - cameraPos.z;
	
	float distance = clamp(viewDist - FogStartDistance, 0, viewDist);
	float3 attenuation = saturate(exp(-float3(surfacePointToWaterPlaneHeight * LightAttenuationHight, viewPointToWaterPlaneHeight * LightAttenuationHight, distance * FogDensity)));
	
	WaterFog(color, viewDir, attenuation);
}

/////////////////////////////////////////////////////////////////////
// projPos is not necessary without shadow

void ConstructFxParam(inout FxParam result, float4 uv, float4 projPos, float3 worldNormal, float3 worldTangent, float3 worldBinormal)
{
    result.color = DiffuseColor;

#if DISTORTION_MASK || BASE_MAP || NORMAL_MAP || SPECULAR_MAP
    {
        float2 baseUV = uv.xy;
        float2x2 uvRotation = float2x2(BaseUVRotation.x, BaseUVRotation.y, BaseUVRotation.z, BaseUVRotation.w);
		result.uv_BaseUV = mul(baseUV, uvRotation) + BaseUVOffset;
		#if FLIPBOOK_FRAME_INTERPOLATION
			result.uv_BaseUV_NextFrame = mul(baseUV, uvRotation) + BaseUVOffset_NextFrame;
		#endif
    }
#endif

#if MASK_MAP || UV_MAP
    result.mapUV_Mask_UV = 0;
#endif

#if DETAIL_MAP
    result.mapUV_Detail = 0;
#endif

#if MASK_MAP
    {
        float2x2 uvRotation = float2x2(MaskMapRotation.x, MaskMapRotation.y, MaskMapRotation.z, MaskMapRotation.w);
    #if SECOND_UV
        result.mapUV_Mask_UV.xy = mul(uv.zw, uvRotation) + MaskMapOffset;
    #else
        result.mapUV_Mask_UV.xy = mul(uv.xy, uvRotation) + MaskMapOffset;
    #endif
    }
#endif

#if UV_MAP
    {
        float2x2 uvRotation = float2x2(UVMapRotation.x, UVMapRotation.y, UVMapRotation.z, UVMapRotation.w);
        result.mapUV_Mask_UV.zw = mul(uv.xy, uvRotation) + UVMapOffset;
    }
#endif

#if DETAIL_MAP
    {
        float2x2 uvRotation = float2x2(DetailMapRotation.x, DetailMapRotation.y, DetailMapRotation.z, DetailMapRotation.w);
        result.mapUV_Detail.xy =  mul(uv.xy, uvRotation) + DetailMapOffset;
    }
#endif



#if DEPTH_SOFT || VIEW_SOFT
    result.viewDepth = projPos.w;
#endif

#if RECV_SHADOW
    result.devicePos = projPos * (1.0 / projPos.w);
#endif

#if (LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT || LIGHTMASK_MAP
    result.worldNormal = worldNormal;
    #if ((LIGHTING || ENV_MAP || REFRACTION) && NORMAL_MAP) || MASK_MAP_EDGE_NORMAL || LIGHTMASK_MAP
        result.worldTangent = worldTangent;
        result.worldBinorm = worldBinormal;
    #endif
#endif

#if FORWARD_LIGHTING || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW
    result.toCamera = GetPartialWorldPosFromScreenPos(projPos);
#endif

#if GRADIENT_MAP_NORMALDOTVIEW
	result.uvY = uv.y;      
#endif
}

void ConstructFxParam(inout FxParam result, float4 uv, float4 projPos, float3 normal, float3 tangent, float3 binormal, float3x3 worldRot)
{   
#if (LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT || LIGHTMASK_MAP
    normal = normalize(mul(normal, worldRot));
    #if ((LIGHTING || ENV_MAP || REFRACTION) && NORMAL_MAP) || MASK_MAP_EDGE_NORMAL || LIGHTMASK_MAP
        tangent = normalize(mul(tangent, worldRot));
        binormal = normalize(mul(binormal, worldRot));
    #endif
#endif
    ConstructFxParam(result, uv, projPos, normal, tangent, binormal);
}

/////////////////////////////////////////////////////////////////////

FxPsOut CalcColor(float2 vPos, float vFace, FxParam param)
{	
    FxPsOut result;

#if DISTORTION_MASK
    #if MASK_MAP
        result.color = DistortionPS(param.uv_BaseUV, param.mapUV_Mask_UV.xy);
    #else
        result.color = DistortionPS(param.uv_BaseUV);
    #endif
    return result;
#else

#if (LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT
	float3 worldNormal = normalize(param.worldNormal);
#endif

#if FORWARD_LIGHTING || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW
	float3 viewDir = normalize(param.toCamera);
#endif

    float4 diffuseColor = param.color;

    #if BASE_MAP || NORMAL_MAP || SPECULAR_MAP

        float2 uvBase = param.uv_BaseUV;

        #if UV_MAP
            uvBase += (tex2D(UVSampler, param.mapUV_Mask_UV.zw).xy * 2 - 1) * UVMapIntensity;
        #endif

        #if BASE_MAP
			#if FLIPBOOK_FRAME_INTERPOLATION
				float4 dc0 = tex2D(BaseSampler, uvBase);
				float4 dc1 = tex2D(BaseSampler, param.uv_BaseUV_NextFrame);
				diffuseColor *= lerp(dc0, dc1, FrameInterpolationValue);
			#else
                diffuseColor *= tex2D(BaseSampler, uvBase);
            #endif
        #endif

        #if LIGHTMASK_MAP
			#if USE_LEGACY_LIGHTMASK_MAP
				float3 normal;
				normal.xyz = tex2D(LightMaskSampler, param.uv_BaseUV.xy).rgb * 2 - 1;
				normal = normalize(normal);
				float cos = saturate(dot(normal, SunLightDir) + LightMaskDarkness.x / 2.2);
				diffuseColor.rgb *= cos * /*SunColor.xyz*/float3(1.45, 1.45, 1.55);
			#else
				const float fakeSunLightStrength = param.uv_LightMaskUV.w;
				const float2 lightMaskUv = param.uv_LightMaskUV.xy;
				diffuseColor.rgb *= tex2D(LightMaskSampler, lightMaskUv).rgb * fakeSunLightStrength + LightMaskDarkness.x / 2.2;
			#endif
        #endif

    #endif

    #if FORWARD_LIGHTING
        diffuseColor.rgb = pow(diffuseColor.rgb, 2.2f);
    #endif

    #if MASK_MAP
	{
		float4 maskMapColor = tex2D(MaskSampler, param.mapUV_Mask_UV.xy);
		diffuseColor *= maskMapColor;
		#if MASK_MAP_EDGE_NORMAL && ((LIGHTING || ENV_MAP || REFRACTION) || DEPTH_EDGE || GRADIENT_MAP_NORMALDOTVIEW || DEPTH_SOFT)
		{
			// ��������4�����ڵ�߶�
			float alphaTestRef = AlphaTestRef * EdgeNormalRange;
			float l = saturate((tex2D(MaskSampler, float2(param.mapUV_Mask_UV.x - MaskMapEdgeNormalResW, param.mapUV_Mask_UV.y)).a*EdgeNormalRange - alphaTestRef));
			float r = saturate((tex2D(MaskSampler, float2(param.mapUV_Mask_UV.x + MaskMapEdgeNormalResW, param.mapUV_Mask_UV.y)).a*EdgeNormalRange - alphaTestRef));
			float u = saturate((tex2D(MaskSampler, float2(param.mapUV_Mask_UV.x, param.mapUV_Mask_UV.y - MaskMapEdgeNormalResH)).a*EdgeNormalRange - alphaTestRef));
			float d = saturate((tex2D(MaskSampler, float2(param.mapUV_Mask_UV.x, param.mapUV_Mask_UV.y + MaskMapEdgeNormalResH)).a*EdgeNormalRange - alphaTestRef));
			float m = saturate((maskMapColor.a*EdgeNormalRange - alphaTestRef));
			float3 edgeNormal = float3(l-r, u-d, m*EdgeNormalFlat);
			worldNormal = mul(edgeNormal, float3x3(param.worldTangent, param.worldBinorm, worldNormal));
			worldNormal = normalize(worldNormal);
		}
		#endif
	}
    #endif

    #if DETAIL_MAP
        diffuseColor *= tex2D(DetailSampler, param.mapUV_Detail.xy) * 2;
    #endif

    #if GRADIENT_MAP_NORMALDOTVIEW || DEPTH_EDGE
        float VdotN = saturate(vFace * dot(viewDir, worldNormal));
    #endif

    #if GRADIENT_MAP_NORMALDOTVIEW
        diffuseColor *= tex2D(GradientSampler, float2(VdotN, param.uvY));
    #endif

    #if ALPHA_TEST
        clip(diffuseColor.a - AlphaTestRef);
    #endif

    #if (LIGHTING || ENV_MAP || REFRACTION)
        float3 normalWorldSpace;
        float gloss;
        #if NORMAL_MAP     
            float3 normalTexSpace;    
            ReadNormalGloss(NormalSampler, uvBase, normalTexSpace, gloss);
			normalTexSpace.z *= -vFace;	// fix CullMode(false, false) lighting bug
            normalWorldSpace = mul(normalTexSpace, float3x3(param.worldTangent, param.worldBinorm, worldNormal));    
            normalWorldSpace = normalize(normalWorldSpace);
        #else
			normalWorldSpace = worldNormal;
			normalWorldSpace *= -vFace; // inaccurate
            gloss = SpecularColor.w;
        #endif       
    #endif

    #if LIGHTING
        float3 specColor = SpecularColor.rgb;
            
        #if SPECULAR_MAP
            specColor *= tex2D(SpecularMap, uvBase).rgb;
        #endif
        #if FORWARD_LIGHTING
            specColor = pow(specColor, 2.2f);
        #endif
    #endif

    #if FORWARD_LIGHTING
        float shadow = 1.0;

        #if RECV_SHADOW
            float xBias;
            float2 smUv;  	
			float4 screenPos = float4(param.devicePos.xyz, 1.0);
			screenPos.xy = screenPos.xy * float2(1.0, -1.0) * 0.5 + 0.5;
			shadow = lerp(1.0 - ShadowRatio, 1.0, CascadedShadowMapLowRes(screenPos, CSM_INUSE_NUM - 1, xBias, smUv));
        #endif

        #if REFRACTION
            float4 dir = float4(refract(viewDir, normalWorldSpace, RefractionIndex), 0);
            dir = mul(dir, PartialViewProj);
			dir.xyz /= dir.w; 
            dir.y = -dir.y;
			float3 background = tex2D(SrcSampler, dir.xy * 0.5 + 0.5 + BufferResolution.zw * 0.5) * diffuseColor.rgb;
        #endif

        #if LIGHTING
        {	        
            //-----direct lighting------
            float3 finalLighting, diffuseLighting, specLighting, adjustDiffuse;            
			float ndl, ndh;
            QSDirectLighting(
                //output
                finalLighting, diffuseLighting, specLighting, adjustDiffuse, ndl, ndh,
                //light property
                SunLightDir, SunColor.xyz,
                //material property
                normalWorldSpace, viewDir, diffuseColor.rgb, gloss, specColor, SunColor.w, shadow);		

            //------env lighting--------
            float3 envDiffuse;
            QSAmbientLighting( 
                envDiffuse, 
                SkyLightColor.xyz, GroundLightColor.xyz, 
                normalWorldSpace, adjustDiffuse, 0);

            finalLighting += envDiffuse;

            //---------------------------
            diffuseColor.rgb = finalLighting;
            
            #if REFRACTION
                background += specLighting;
            #endif
        }
        #else
            diffuseColor.rgb *= FxLightColor * shadow;
        #endif

        #if REFRACTION
            diffuseColor.rgb = lerp(background, diffuseColor.rgb, RefractionAlpha);
        #endif

        #if ENV_MAP
            float3 reflVec = reflect(viewDir, normalWorldSpace);
            float4 refl = texCUBE(EnvSampler, reflVec.xzy);
            diffuseColor.rgb += refl.xyz * EnvColor.xyz;
        #endif

        #if GRADIENT_MAP_ALPHATESTREF
            float4 gradientColor = tex2D(GradientSampler, diffuseColor.a - AlphaTestRef);
            diffuseColor.rgb = lerp(diffuseColor.rgb, gradientColor.rgb, gradientColor.a);
        #endif

        #if DEPTH_SOFT || FOG
            float2 screenUv = (vPos + 0.5f) * BufferResolution.zw;
        #endif

        #if FOG
   			if (WaterHeight < cameraPos.z)
			{
                #if !USE_LEGACY_LIGHTMASK_MAP
                    ApplyFogWithZFade(diffuseColor, param.toCamera, screenUv);
                #else
                    ApplyFog(diffuseColor.rgb, param.toCamera, screenUv);
                #endif
			}
			else
			{
				ApplyWaterFog(diffuseColor.rgb, cameraPos - param.toCamera, viewDir, param.toCamera);
			}
        #endif

        #if DEPTH_EDGE
            float aa = VdotN;
            aa = SoftEdge * aa / sqrt(1-aa*aa);
            aa = saturate(aa);
            diffuseColor.a *= aa;
        #endif

        #if DEPTH_SOFT
		{
			float sceneScreenSpaceZ = GetDeviceZ(screenUv);
			float sceneViewDepth = CalcViewZFromDeviceZ(sceneScreenSpaceZ);
            float depthSoftFactor = saturate(abs(param.viewDepth - sceneViewDepth) * SoftDepth * 0.01f);
			float comDepthSoftFactor = max(0, 1 - SoftDepthFade * depthSoftFactor);

			// �ų���ƽ����
			float3 scenePartialWorldPos = GetPartialWorldPosFromDeviceZ(screenUv, sceneScreenSpaceZ);
			float3 dx = ddx(scenePartialWorldPos);
			float3 dy = ddy(scenePartialWorldPos);
			float3 sceneNormal = cross(normalize(dx), normalize(dy));
			comDepthSoftFactor *= saturate((0.9 - abs(dot(sceneNormal, worldNormal))) * 10);

            diffuseColor.a *= saturate((1 - SoftDepthLerp) * depthSoftFactor + SoftDepthLerp * comDepthSoftFactor * comDepthSoftFactor);
		}
        #endif

		#if VIEW_SOFT
			float2 fade = saturate((param.viewDepth - NearPlane) * FadeRange + FadeBegin);
			diffuseColor.a *= fade.x * (1 - fade.y);
        #endif
        result.color = diffuseColor;
    #else
        #if LIGHTING
            PackGBufferWithGloss(result.color, result.norm, result.specular, diffuseColor, normalWorldSpace, specColor, gloss);
        #else   // UI
            diffuseColor.rgb *= FxLightColor;
            result.color = diffuseColor;
        #endif
    #endif

    return result;

#endif
}

#endif//QSSHADER_FX_H