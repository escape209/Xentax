#ifndef QSSHADER_TerrainEditShaderNavFlag_H
#define QSSHADER_TerrainEditShaderNavFlag_H

#include "TerrainEditSimBit.fxh"

static const float kNavFlagWalkable = 1.0f/255.0f;
float3 DecodeNavFlagValue3(float v)
{
	float4 decode0, decode1;
	DecodeBit8(v, decode0, decode1);
	return decode0.xyz;
}

float4 DecodeNavFlagValue4(float v)
{
	float4 decode0, decode1;
	DecodeBit8(v, decode0, decode1);
	return decode0;
}

float EnacodeNavFlagValue3(float baseValue, float3 v) 
{
	float4 decode0, decode1;
	DecodeBit8(baseValue, decode0, decode1);
	decode0.xyz = v;

	return EncodeBit8(decode0, decode1);
}

float EnacodeNavFlagValue4(float baseValue, float4 v) 
{
	float4 decode0, decode1;
	DecodeBit8(baseValue, decode0, decode1);
	decode0 = v;

	return EncodeBit8(decode0, decode1);
}

float EncodeNavFlagPathfindingValue3(float baseValue, float3 v, bool low)
{
	float4 r0,r1;
	DecodeBit8(baseValue, r0, r1);

	float delta = 0.2f;
	float3 result;
	result.x = v.x > 1.0f-delta ? 1.0f : 0.0f;
	result.y = v.y > 1.0f-delta ? 1.0f : 0.0f;
	result.z = v.z > 1.0f-delta ? 1.0f : 0.0f;

	if(low)
	{
		r0.xyz = result;
	}
	else
	{
		r1.xyz = result;
	}

	return EncodeBit8(r0, r1);
}

float3 DecodeNavFlagPathfindingValue3(float v, bool low)
{
	float4 decode0, decode1;
	DecodeBit8(v, decode0, decode1);

	return low ? decode0.xyz : decode1.xyz;
}



#endif//QSSHADER_TerrainEditShaderNavFlag_H