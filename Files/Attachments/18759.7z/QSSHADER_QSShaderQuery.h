#ifndef QSSHADER_QSShaderQuery_H
#define QSSHADER_QSShaderQuery_H

#if SCENE_QUERY
	const float4 QueryId; 
	const float4 QueryViewPortInfo;	//xy: const f32 x = query->mX*2.0f-sizeX;const f32 y = sizeY-query->mY*2.0f; zw:screen size 

	void ExtendHomoPos(inout float4 pos)
	{
		pos.xy = pos.xy*QueryViewPortInfo.zw-pos.w*QueryViewPortInfo.xy;
	}

	float4 EncodingId(float v)
	{
		float d = fmod(v,256.0f);
		v-=d;
		v/=256.0f;

		float c = fmod(v,256.0f);
		v-=c;
		v/=256.0f;

		float b = fmod(v,256.0f);
		v-=b;
		v/=256.0f;

		float a = v;

		//return float4(a,b,c,d)/255.0f;
		return float4(b,c,d,a)/255.0f;
	}
#endif

#endif//QSSHADER_QSShaderQuery_H