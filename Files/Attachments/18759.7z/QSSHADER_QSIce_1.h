#ifndef QSSHADER_QSIce_H
#define QSSHADER_QSIce_H

#include "QSShaderIndirectLighting.h"
#include "QSPhysicalLighting.h"
#include "QSLighting.h"

float EncodeByte(float lower, float high)
{
    return (int(high * 15 + 0.5) * 16 + int(lower * 15 + 0.5)) / 255.0f;
}

void DecodeByte(float src, out float lower, out float high)
{	
    int a = src * 255 + 0.5;
    lower = (a % 16) / 15.0f;
    high = (a / 16) / 15.0f;
}

void IceLighting(out float3 finalLighting, out float3 diffuseLighting, out float3 specLighting, 
                    float3 normal, float3 viewDir, float3 diffuseColor, float gloss, float3 specColor, float shadow, float iceTrans, float iceWeight)
{
    float3 adjustDiffuse;
    float ndl, ndh;	
#if PRIMARY_DIR_LIGHT
    QSDirectLighting(
        //output
        finalLighting, diffuseLighting, specLighting, adjustDiffuse, ndl, ndh,
        //light property
        SunLightDir, SunColor.xyz,
        //material property
        normal, viewDir, diffuseColor, gloss, specColor, SunColor.w, shadow);	
#else
    finalLighting = 0.0f;
    adjustDiffuse = diffuseColor * (1.0f-gloss);		
    diffuseLighting = 0.0f;
    specLighting = 0.0f;

    float3 h = normalize(-SunLightDir.xyz - viewDir);
    ndh = saturate(dot(normal, h));
    ndl = saturate(dot(-SunLightDir.xyz, normal)); 
#endif
    
    float3 ambientDiffuse;

    QSAmbientLighting(ambientDiffuse, 
        SkyLightColor.xyz, GroundLightColor.xyz, 
        normal, adjustDiffuse, SpecularIndirectLightingEnhance);

    float envGloss = gloss*gloss*2.0f;
    float3 envMapColor = SampleEnvMapLightColor(viewDir.xyz, normal, envGloss);	

    //-------------
    float3 iceColor = ambientDiffuse;

#if !FORWARD_LIGHTING
    float3 sunColor = saturate(SunColor);
    float3 backUV = viewDir.xzy + normal * 0.1f;	
    float3 backColor = texCUBE(EnvMap, backUV);
//     float backLum = dot(backColor, 0.333f);
//     backColor = lerp(backLum, backColor, 0.5f);
    backColor *= sunColor * diffuseColor;
    iceColor = lerp(iceColor, backColor, iceTrans);

    // silhouette
    float silhouette = 1 - saturate(dot(normal, -viewDir));	
    silhouette *= silhouette;
    float iceEnv = dot(envMapColor, 0.333f);
    iceColor = lerp(iceColor, iceEnv * sunColor, silhouette);
#endif
    iceColor += specLighting * 0.1f;
    float shadowWeight = 0.5f;
    iceColor *= shadowWeight * shadow + (1-shadowWeight);

    finalLighting += ambientDiffuse;
    finalLighting = lerp(finalLighting, iceColor, iceWeight);

#if ENV_MAP_APPLY
    float3 envSpec = PhyLightingImageBasedSpecular(normal, viewDir, envGloss, specColor, EnvMapProbePos.w, envMapColor);
    finalLighting += envSpec;
#endif
}

#endif //QSSHADER_QSIce_H