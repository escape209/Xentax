#ifndef QSSHADER_DX12_DEFINES_H
#define QSSHADER_DX12_DEFINES_H

// Kai created these helper macros/functions to make HLSL porting life easier 
// We can extend these macros/functions to write once and compile for both DX9 & DX11 if necessary.


/// System value semantics
#define VPOS 			SV_POSITION
#define VFACE 			SV_IsFrontFace

#define POSITION        SV_Position
#define COLOR           SV_Target0
#define COLOR0          SV_Target0
#define COLOR1          SV_Target1
#define COLOR2          SV_Target2
#define COLOR3          SV_Target3
#define DEPTH0          SV_Depth



//compatible tex and samples
#define sampler2D		Texture2D		
#define sampler3D       Texture3D
#define samplerCUBE TextureCube
#define tex2D(tex, s, uv) tex.Sample(s,uv)
#define tex3D(tex, s, uv) tex.Sample(s,uv)
#define tex2Dbias(tex, s, uv) tex.SampleBias(s,uv,uv.w)
#define texCUBE(tex, s, uv) tex.Sample(s,uv)

#define texCUBElod(tex, s, uv) tex.SampleLevel(s, uv.xyz, uv.w)
#define tex2Dlod(tex, s, uv) tex.SampleLevel(s, uv.xy, uv.w)
#define tex3Dlod(tex, s, uv) tex.SampleLevel(s, uv.xyz, uv.w)
#define tex2Dgrad(tex, s, uv, deltaX, deltaY) tex.SampleGrad(s, uv.xy, deltaX.xy, deltaY.xy)


//sampler state def
SamplerState MipMapLinear:register(s0);
SamplerState NoMipMapPoint:register(s1);
SamplerState NoMipMapPointClamp:register(s2);
SamplerState MipMapLinearBorder:register(s3);
SamplerState MipMapLinearClamp:register(s4);
SamplerState MipMapLinearBorderW:register(s5);
SamplerState NoMipMapLinear:register(s6);
SamplerState NoMipMapLinearClamp:register(s7);
SamplerState NoMipMapLinearWrapU:register(s8);
SamplerState AnisoSrgb:register(s9);
SamplerState MipMapLinearMirror:register(s10);
SamplerState MipMapLinearMirrorZ:register(s11);
SamplerState MipMapLinearBorderWhite:register(s12);
SamplerComparisonState LinearCmp:register(s13); //used for shadow, make sure it's the last one



#endif //QSSHADER_DX12_DEFINES_H
