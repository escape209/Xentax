#ifndef QSSHADER_TerrainMaterial_H
#define QSSHADER_TerrainMaterial_H

#include "FunctionLib.fxh"
#include "CommonNormalFunc.fxh"
/*
 *	constants
 */
sampler2D 		DiffuseMap;
sampler2D 		NormalMap;
sampler2D 		LowResDiffuseMap;
sampler2D 		MaterialMaskSampler;
sampler2D 		GrassMaskSampler;
sampler2D       GrassMaskSampler_1;

float4          MaterialLodInfo; //x near threshold, y smooth fade len, z 1.0f/y, w for low res diffuse factor

//merged layer
sampler2D 		DiffuseMap0;
sampler2D 		DiffuseMap1;
sampler2D 		DiffuseMap2;
sampler2D 		DiffuseMap3;
sampler2D 		DiffuseMap4;
sampler2D 		NormalMap0;
sampler2D 		NormalMap1;
sampler2D 		NormalMap2;
sampler2D 		NormalMap3;
sampler2D 		NormalMap4;

#if BLINK_NOISE
//To avoid too many textures for terrain shader, only support one globle blink noise texture now.
sampler2D 		BlinkNoiseSampler;
float           BlinkNoiseGridUVTileFactor;       // grid tile UI factor
#endif

/*
 *	functions
 */
//util functions
int GetLayerNum()
{
#if MERGE_LAYER_1
	return 1;
#elif MERGE_LAYER_2
	return 2;
#elif MERGE_LAYER_3
	return 3;
#elif MERGE_LAYER_4
	return 4;
#elif MERGE_LAYER_5
	return 5;
#endif
}

float GetMaskValue(float4 mask, float4 selector, float2 processor)
{
    float maskValue = dot(mask, selector);
    maskValue = maskValue*processor.y+processor.x;
    return maskValue;
}

//param is dist on z
float CalcMatLodRatio(float distZ)
{
    return clamp((distZ-MaterialLodInfo.x)*MaterialLodInfo.z, 0.0f, 1.0f);
}

void SampleTex(
    //in
    sampler2D diffuseMap, sampler2D normalMap, float2 uv, 
    //out
    out float4 diffuseColor, out float specularValue, out float3 normalTangentSpace
    )
{
    diffuseColor = tex2D(diffuseMap, AnisoSrgb, uv);
	float4 normalColor = tex2D(normalMap, AnisoSrgb, uv);

#if SPEC_FROM_ALPHA
	specularValue = normalColor.a;
	normalTangentSpace = BiDecompress(normalColor.xyz);
#else	
	specularValue = normalColor.z;    
	float2 nmXy = BiDecompress(normalColor.xy);
	normalTangentSpace = float3(nmXy, sqrt(1.0f-dot(nmXy,nmXy)));
#endif
}

void SampleTexLayer(
    //in
    int layerIdx, float2 uv, float2 specularChannel,
    //out
    out float3 diffuseColor, out float specularValue, out float3 normalTangentSpace
    )
{
    float4 normalColor;

    if(0==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap0, AnisoSrgb, uv).xyz;
        normalColor = tex2D(NormalMap0, AnisoSrgb, uv);
    }
    else if(1==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap1, AnisoSrgb, uv).xyz;
        normalColor = tex2D(NormalMap1, AnisoSrgb, uv);
    }
    else if(2==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap2, AnisoSrgb, uv).xyz;
        normalColor = tex2D(NormalMap2, AnisoSrgb, uv);
    }
    else if(3==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap3, AnisoSrgb, uv).xyz;
        normalColor = tex2D(NormalMap3, AnisoSrgb, uv);
    }
    else if(4==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap4, AnisoSrgb, uv).xyz;
        normalColor = tex2D(NormalMap4, AnisoSrgb, uv);
    }

    specularValue = dot(normalColor.zw, specularChannel);    
    float2 nmXy = BiDecompress(normalColor.xy);
    normalTangentSpace = float3(nmXy, sqrt(saturate(1.0f-dot(nmXy,nmXy))));
}

void SampleTex(
    //in
    int layerIdx, float2 uv,
    //out
    out float3 diffuseColor
    )
{
    if(0==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap0, AnisoSrgb, uv).xyz;
    }
    else if(1==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap1, AnisoSrgb, uv).xyz;
    }
    else if(2==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap2, AnisoSrgb, uv).xyz;
    }
    else if(3==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap3, AnisoSrgb, uv).xyz;
    }
    else //if(4==layerIdx)
    {
        diffuseColor = tex2D(DiffuseMap4, AnisoSrgb, uv).xyz;
    }
}

void SampleDiffuseNormal(sampler2D diffuseMap, sampler2D normalMap, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float4 diffuseColor, out float3 worldNormal, out float specularValue)
{
#if PROJ_X
    {        
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 normalTangentSpace;
        SampleTex(diffuseMap, normalMap, uv, diffuseColor, specularValue, normalTangentSpace);
        
        float signValue = dot(inNormal, float3(1.0f, 0.0f, 0.0f))<0.0f?1.0f:-1.0f;

        float3 tangentBase = float3(0.0f,1.0f,0.0f);	
        float3 normal = inNormal; 
        float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 tangent = cross(binormal, normal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,normal);
        worldNormal = normalize(mul(normalTangentSpace, tangentMatrix)); 
    }
#endif//PROJ_X

#if PROJ_Y
    {        
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 normalTangentSpace;
        SampleTex(diffuseMap, normalMap, uv, diffuseColor, specularValue, normalTangentSpace);

        float signValue = dot(inNormal, float3(0.0f, -1.0f, 0.0f))<0.0f?1.0f:-1.0f;		
        float3 tangentBase = float3(1.0f,0.0f,0.0f);

        float3 normal = inNormal; 
        float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 tangent = cross(binormal, normal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,normal);
        worldNormal = normalize(mul(normalTangentSpace, tangentMatrix)); 
    }
#endif//PROJ_Y

#if PROJ_Z
    {        
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float3 normalTangentSpace;
        SampleTex(diffuseMap, normalMap, uv, diffuseColor, specularValue, normalTangentSpace);

        worldNormal = ReorientNormal(inNormal, normalTangentSpace);
    }
#endif//PROJ_Z

    worldNormal = normalize(worldNormal);
}

void SampleDiffuseNormal(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor, out float3 worldNormal, out float specularValue)
{
	float2 specChannel = selectorV.xy;
#if PROJ_X
	{        
		float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

		float3 normalTangentSpace;		
		SampleTexLayer(layerIdx, uv, specChannel, diffuseColor.xyz, specularValue, normalTangentSpace);

        //opt for float signValue = dot(inNormal, float3(1.0f, 0.0f, 0.0f))<0.0f?1.0f:-1.0f;
        float signValue = inNormal.x<0.0f ? 1.0f : -1.0f;

        //opt for 
        //float3 tangentBase = float3(0.0f,1.0f,0.0f);	 
        //float3 binormal = cross(inNormal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(-inNormal.z, 0.0f, inNormal.x);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);

        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix)); 
        worldNormal += mul(normalTangentSpace, tangentMatrix); 
	}
#endif//PROJ_X

#if PROJ_Y
	{        
		float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

		float3 normalTangentSpace;
		SampleTexLayer(layerIdx, uv, specChannel, diffuseColor.xyz, specularValue, normalTangentSpace);

        //optimize for dot(inNormal, float3(0.0f, -1.0f, 0.0f))<0.0f?1.0f:-1.0f;		
        float signValue = inNormal.y>0.0f?1.0f:-1.0f;		        

        //opt for
        //float3 tangentBase = float3(1.0f,0.0f,0.0f);
        //float3 binormal = cross(inNormal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(0.0f, inNormal.z, -inNormal.y);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);

        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix)); 
        worldNormal += mul(normalTangentSpace, tangentMatrix); 
	}
#endif//PROJ_Y

#if PROJ_Z
	{        
		float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

		float3 normalTangentSpace;
		SampleTexLayer(layerIdx, uv, specChannel, diffuseColor.xyz, specularValue, normalTangentSpace);

        worldNormal += ReorientNormal(inNormal, normalTangentSpace);
	}
#endif//PROJ_Z
}

//sample diffuse and normal information on multiple direction proj
void SampleDifNormMultiProj(sampler2D diffuseMap, sampler2D normalMap, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float4 diffuseColor, out float3 worldNormal, out float specularValue)
{
	diffuseColor = 0.0f;
	worldNormal = 0.0f;
	specularValue = 0.0f;

	float3 factorSrc = inNormal*inNormal;	
	float multiplier = 0.0f;
#if PROJ_X
	multiplier += factorSrc.x;
#endif
#if PROJ_Y
	multiplier += factorSrc.y;
#endif
#if PROJ_Z
	multiplier += factorSrc.z;
#endif
	if(multiplier>0.0f)
	{
		factorSrc /= multiplier;
	}

#if PROJ_X
	{
		float factor = abs(factorSrc.x);
		float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);
        
        float spec;
        float3 normalTangentSpace;
        float4 dif;
        SampleTex(diffuseMap, normalMap, uv, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;

		float signValue = dot(inNormal, float3(1.0f, 0.0f, 0.0f))<0.0f?1.0f:-1.0f;

        float3 tangentBase = float3(0.0f,1.0f,0.0f);	
		float3 normal = inNormal; 
		float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
		float3 tangent = cross(binormal, normal);
		float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,normal);
		worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
	}
#endif//PROJ_X

#if PROJ_Y
	{
		float factor = abs(factorSrc.y);
		float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float spec;
        float3 normalTangentSpace;
        float4 dif;
        SampleTex(diffuseMap, normalMap, uv, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;

		float signValue = dot(inNormal, float3(0.0f, -1.0f, 0.0f))<0.0f?1.0f:-1.0f;		
        float3 tangentBase = float3(1.0f,0.0f,0.0f);

		float3 normal = inNormal; 
		float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
		float3 tangent = cross(binormal, normal);
		float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,normal);
		worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
	}
#endif//PROJ_Y

#if PROJ_Z
	{
		float factor = abs(factorSrc.z);
		float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float spec;
        float3 normalTangentSpace;
        float4 dif;
        SampleTex(diffuseMap, normalMap, uv, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;

		worldNormal += ReorientNormal(inNormal, normalTangentSpace)*factor; 
	}
#endif//PROJ_Z

	worldNormal = normalize(worldNormal);
}


void SampleDifNormMultiProj(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor, out float3 worldNormal, out float specularValue)
{
    //const
    float2 specChannel = selectorV.xy;

    diffuseColor = 0.0f;
    worldNormal = 0.0f;
    specularValue = 0.0f;



//#if (PROJ_X+PROJ_Y+PROJ_Z)>1
	float3 factorSrc = inNormal*inNormal;	
	float multiplier = 0.0f;
	#if PROJ_X
		multiplier += factorSrc.x;
	#endif
	#if PROJ_Y
		multiplier += factorSrc.y;
	#endif
	#if PROJ_Z
		multiplier += factorSrc.z;
	#endif
	if(multiplier>0.0f)
	{
		factorSrc /= multiplier;
	}
	else
	{
		factorSrc += 1.0f;
	}
 //#if ((PROJ_X+PROJ_Y+PROJ_Z)==1)
 	//factorSrc = 1.0f;
 //#endif

//#else
//float3 factorSrc = 1.0f;
//#endif
   

#if PROJ_X
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;
        specularValue += spec*factor;

        //opt for float signValue = dot(inNormal, float3(1.0f, 0.0f, 0.0f))<0.0f?1.0f:-1.0f;
        float signValue = inNormal.x<0.0f ? 1.0f : -1.0f;

        //opt for 
        //float3 tangentBase = float3(0.0f,1.0f,0.0f);	 
        //float3 binormal = cross(inNormal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(-inNormal.z, 0.0f, inNormal.x);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);

        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
        worldNormal += mul(normalTangentSpace, tangentMatrix)*factor; 
    }
#endif//PROJ_X

#if PROJ_Y
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;
        specularValue += spec*factor;

        //optimize for dot(inNormal, float3(0.0f, -1.0f, 0.0f))<0.0f?1.0f:-1.0f;		
        float signValue = inNormal.y>0.0f?1.0f:-1.0f;		        

        //opt for
        //float3 tangentBase = float3(1.0f,0.0f,0.0f);
        //float3 binormal = cross(inNormal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(0.0f, inNormal.z, -inNormal.y);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);

        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
        worldNormal += mul(normalTangentSpace, tangentMatrix)*factor; 
    }
#endif//PROJ_Y

#if PROJ_Z
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;
        specularValue += spec*factor;

        worldNormal +=  ReorientNormal(inNormal, normalTangentSpace)*factor; 
    }
#endif//PROJ_Z

    //worldNormal = normalize(worldNormal);
}

void SampleDifNormMultiProjBranch(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor, out float3 worldNormal, out float specularValue)
{
    //const
    float2 specChannel = selectorV.xy;

    //default value
    diffuseColor = 0.0f;
    worldNormal = 0.0f;
    specularValue = 0.0f;

    //proj dir
    bool projX = selectorU.x>0.0f;
    bool projY = selectorU.y>0.0f;
    bool projZ = selectorU.z>0.0f;

    //blend factor
    float3 factorSrc = inNormal*inNormal;	
    float multiplier = dot(selectorU.xyz, factorSrc);

    if(multiplier>0.0f)
    {
        factorSrc /= multiplier;
    }

    if(projX)
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;

        //opt for float signValue = dot(inNormal, float3(1.0f, 0.0f, 0.0f))<0.0f?1.0f:-1.0f;
        float signValue = inNormal.x<0.0f ? 1.0f : -1.0f;
                
        //opt for 
        //float3 tangentBase = float3(0.0f,1.0f,0.0f);	 
        //float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(-inNormal.z, 0.0f, inNormal.x);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);
        
        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
        worldNormal += mul(normalTangentSpace, tangentMatrix)*factor; 
    }

    if(projY)
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;

        //optimize for dot(inNormal, float3(0.0f, -1.0f, 0.0f))<0.0f?1.0f:-1.0f;		
        float signValue = inNormal.y>0.0f?1.0f:-1.0f;		        

        //opt for
        //float3 tangentBase = float3(1.0f,0.0f,0.0f);
        //opt for float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 binormal = float3(inNormal.y, -inNormal.x, 0.0f);
        float3 tangent = cross(binormal, inNormal);
        float3x3 tangentMatrix = float3x3(tangent,binormal*signValue,inNormal);

        //opt for
        //worldNormal += normalize(mul(normalTangentSpace, tangentMatrix))*factor; 
        worldNormal += mul(normalTangentSpace, tangentMatrix)*factor; 
    }
    
    if(projZ)
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float spec;
        float3 normalTangentSpace;
        float3 dif;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);
        diffuseColor += dif*factor;
        specularValue += spec*factor;
                
        worldNormal +=  ReorientNormal(inNormal, normalTangentSpace)*factor; 
    }

    //opt
    //worldNormal = normalize(worldNormal);
}

float3 SampleTerrainWorldSpaceNormal(sampler2D normMap, float2 uv)
{
    float4 normalInfo = tex2D(normMap, MipMapLinearClamp, uv);

#if DXT5N_NORMAL
    float3 result;	
    result.xy = normalInfo.ag*2.0f-1.0f;
    result.z = sqrt(max(1.0f-dot(result.xy,result.xy),0.0f));	
    return result;
#else
    return normalInfo.xyz*2.0f-1.0f;	
#endif
}

void SampleDif(int layerIdx, float3 uvw, float4 selectorU, out float3 diffuseColor)
{
    float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);
    SampleTex(layerIdx, uv, diffuseColor);
}

void SampleDif3Dir(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor)
{
    //default value
    diffuseColor = 0.0f;

    //proj dir
    bool projX = selectorU.x>0.0f;
    bool projY = selectorU.y>0.0f;
    bool projZ = selectorU.z>0.0f;

    //blend factor
	float3 factorSrc = selectorU.xyz;
	if(selectorU.x+selectorU.y+selectorU.z>1.0f)
	{
		factorSrc = inNormal*inNormal;	
		float multiplier = dot(selectorU.xyz, factorSrc);

		if(multiplier>0.0f)
		{
			factorSrc /= multiplier;
		}
	}

    if(projX)
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;
    }

    if(projY)
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;        
    }

    if(projZ)
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;   
    }
}

void SampleDif(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor)
{
    //default value
    diffuseColor = 0.0f;

    //blend factor
    float3 factorSrc = inNormal*inNormal;	
    float multiplier = 0.0f;
#if PROJ_X
    multiplier += factorSrc.x;
#endif
#if PROJ_Y
    multiplier += factorSrc.y;
#endif
#if PROJ_Z
    multiplier += factorSrc.z;
#endif

    if(multiplier>0.0f)
    {
        factorSrc /= multiplier;
    }

#if PROJ_X
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;
    }
#endif

#if PROJ_Y
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;        
    }
#endif

#if PROJ_Z
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        SampleTex(layerIdx, uv, dif);
        diffuseColor += dif*factor;   
    }
#endif
}

void SampleDifSpec3Dir(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor, out float specularValue)
{
    float2 specChannel = selectorV.xy;

    //default value
    diffuseColor = 0.0f;
    specularValue = 0.0f;

    //proj dir
    bool projX = selectorU.x>0.0f;
    bool projY = selectorU.y>0.0f;
    bool projZ = selectorU.z>0.0f;

    //blend factor
    float3 factorSrc = selectorU.xyz;
    if(selectorU.x+selectorU.y+selectorU.z>1.0f)
    {
        factorSrc = inNormal*inNormal;	
        float multiplier = dot(selectorU.xyz, factorSrc);

        if(multiplier>0.0f)
        {
            factorSrc /= multiplier;
        }
    }

    if(projX)
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);
        diffuseColor += dif * factor;
        specularValue += spec * factor;
    }

    if(projY)
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);
        
        diffuseColor += dif*factor;  
        specularValue += spec * factor;
    }

    if(projZ)
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.y*selectorU.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;  
        specularValue += spec * factor;
    }
}

void SampleDifSpec(int layerIdx, float3 uvw, float3 inNormal, float4 selectorU, float4 selectorV, out float3 diffuseColor, out float specularValue)
{
    float2 specChannel = selectorV.xy ; 

    //default value
    diffuseColor = 0.0f;
    specularValue = 0.0f;

    //blend factor
    float3 factorSrc = inNormal*inNormal;	
    float multiplier = 0.0f;
#if PROJ_X
    multiplier += factorSrc.x;
#endif
#if PROJ_Y
    multiplier += factorSrc.y;
#endif
#if PROJ_Z
    multiplier += factorSrc.z;
#endif

    if(multiplier>0.0f)
    {
        factorSrc /= multiplier;
    }

#if PROJ_X
    {
        float factor = factorSrc.x;
        float2 uv = float2(uvw.y*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;  
        specularValue += spec * factor;
    }
#endif

#if PROJ_Y
    {
        float factor = factorSrc.y;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;  
        specularValue += spec * factor;    
    }
#endif

#if PROJ_Z
    {
        float factor = factorSrc.z;
        float2 uv = float2(uvw.x*selectorU.w, 1.0f-uvw.z*selectorV.w);

        float3 dif;
        float3 normalTangentSpace;		
        float spec;
        SampleTexLayer(layerIdx, uv, specChannel, dif, spec, normalTangentSpace);

        diffuseColor += dif*factor;  
        specularValue += spec * factor;
    }
#endif
}

void ApplyLowResDif(inout float3 color, float2 uv)
{    
	float lowResFactor = MaterialLodInfo.w;
	color *= tex2D(LowResDiffuseMap, MipMapLinearBorderW, uv).xyz * lowResFactor;
}

#endif//QSSHADER_TerrainMaterial_H

