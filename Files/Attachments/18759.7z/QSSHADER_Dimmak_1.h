#ifndef QSSHADER_Dimmak_H
#define QSSHADER_Dimmak_H


sampler2D DimmakMap;
const float4 DimmakFactor;			//a--dimmak lerp factor(-1 disable, 0--1 enable), rgb dimmak freeze result    
const float4 DimmakTriggerColor;
const float4 DimmakUVAnim;
const float4 DimmakUVTiling;

void Dimmak(float mask, float factor, inout float3 srcColor, float4 freezeColor, float3 triggerColor)
{
	float lerpFactor = 0.0f;

	float3 targetFrezColor = lerp(srcColor.rgb, dot(srcColor.rgb, 1.0f/3.0f)*freezeColor.rgb, freezeColor.a);
	float3 freColor = lerp(srcColor.rgb, targetFrezColor, factor);
	//default state
	if(factor<0.0f)
	{
		return;
	}
	//trigger state
	else if(factor>=0.0f&&factor<1.0f)
	{
		float lerpFactor = mask>factor?1.0f:0.0f;        
		srcColor = lerp(freColor, triggerColor,lerpFactor);        
		return;
	}
	else if(factor==1.0f)
	{
		srcColor.rgb = freColor;                
		return;
	}
	else
	{        
		srcColor.rgb = lerp(freColor, srcColor.rgb, factor-1.0f);
		return;
	}
}

#endif//QSSHADER_Dimmak_H