#ifndef QSSHADER_QSMaterialDetail_H
#define QSSHADER_QSMaterialDetail_H

// detail:
// * masked colorize, enabled when mask texture is available
// * masked detailed with texture(diffuse/normal/gloss/specular color), enabled when at least one channel's d/n/g/s/uv is available
//  definition macro
//  DETAIL_MASK_TEXTURE
//  DETAIL_MASK_TEXTURE_R
//  DETAIL_MASK_SPECULAR_R
//  DETAIL_MASK_TEXTURE_G
//  DETAIL_MASK_SPECULAR_G

//  algorithm comments :   replaceMode	//decide if the blending mode is multiply or replace

// texture&constants
sampler2D DetailMaskMap;

sampler2D DetailDiffuseMapR;
sampler2D DetailMetallicMapR;
sampler2D DetailNormalMapR;          //xy for normal, z for gloss

sampler2D DetailDiffuseMapG;
sampler2D DetailMetallicMapG;
sampler2D DetailNormalMapG;          //xy for normal, z for gloss

float4 DetailUvScaleBiasR;          //xy for bais, zw for scale
float4 DetailUvScaleBiasG;          //xy for bais, zw for scale

float4 DetailDiffuseColorR;			//xyz for diffuse color, w for replace model control
float4 DetailDiffuseColorG;			//xyz for diffuse color, w for replace model control
float4 DetailSpecularColorR;        //xyz for specular color, w for gloss
float4 DetailSpecularColorG;

void ComposeColor(inout float3 srcColor, float3 composeColor, float mask, float replaceMode)
{
    float3 factor = replaceMode != 0.0f ? 1.0f : srcColor;
    srcColor = lerp(srcColor, composeColor*factor, mask);
}

void ComposeColor(inout float srcColor, float composeColor, float mask, float replaceMode)
{
    float factor = replaceMode != 0.0f ? 1.0f : srcColor;
    srcColor = lerp(srcColor, composeColor*factor, mask);
}

float3 DetailOverlay(float3 baseColor, float3 detailColor)
{
    const float3 lumCoeff = float3(0.2125, 0.7154, 0.0721);
    const float luminance = dot(detailColor.rgb, lumCoeff.rgb);
    const float indexVal = 2.0;
    return (luminance < 0.5) ? (indexVal * detailColor * baseColor) : (1.0 - indexVal * ((1.0 - detailColor)*(1.0 - baseColor)));
}

void ComposeNormal(inout float3 normal, float2 detailNormal, float mask, float replaceMode)
{
    //replace on lerp
    if (replaceMode != 0.0f)
    {
        normal.xy = lerp(normal.xy, detailNormal, mask);
        normal.z = sqrt(max(1.0f - dot(normal.xy, normal.xy), 0.0f));
    }
    //compose on base matrix
    else
    {
        float3 tangentBase = float3(1.0f, 0.0f, 0.0f);
        float3 binormal = cross(normal, tangentBase);	//need to reverse the cross factor of tangent and normal, as the v dir is the reverse of y dirs
        float3 tangent = cross(binormal, normal);
        float3x3 tangentMatrix = float3x3(tangent, binormal, normal);

        float detailNormalZ = sqrt(1.0f - dot(detailNormal.xy, detailNormal.xy));
        float3 scaledDetailNormal = lerp(float3(0, 0, 1.0f), float3(detailNormal, detailNormalZ), mask);
        normal = mul(scaledDetailNormal, tangentMatrix);
    }

    normal = normalize(normal);
}

void ColorizeDetailMapDNGS(
    float2 uv, float mask,
    sampler2D difMap, sampler2D normMap, sampler2D specMap,
    float4 detailUvScaleBias, float3 DetailDiffuseColor, float4 DetailSpecColor, float replaceMode,
    inout float3 normal, inout float3 diffuse, inout float3 specColor, inout float gloss)
{
    float2 detailUv = uv * detailUvScaleBias.zw + detailUvScaleBias.xy;

    //diffuse
    float3 detailDif = tex2D(difMap, detailUv).xyz*DetailDiffuseColor;
    float3 detailOverlay = DetailOverlay(diffuse, detailDif);
    ComposeColor(diffuse, detailOverlay, mask, replaceMode);

    //specular
    float3 detailSpec = tex2D(specMap, detailUv).xyz*DetailSpecColor.xyz;

    ComposeColor(specColor, detailSpec, mask, replaceMode);

    float3 detailNormGloss = tex2D(normMap, detailUv);

    //normal    
    float2 detailNormXy = detailNormGloss.xy*2.0f - 1.0f;
    float3 detailGlossOverlay = DetailOverlay(gloss, (1.0 - detailNormGloss.z));

    ComposeNormal(normal, detailNormXy, mask, replaceMode);

    //gloss
    ComposeColor(gloss, detailGlossOverlay*DetailSpecColor.w, mask, replaceMode);
}

void ColorizeDetailMapDNG(
    float2 uv, float mask,
    sampler2D difMap, sampler2D normMap,
    float4 detailUvScaleBias, float3 DetailDiffuseColor, float DetailGloss, float replaceMode,
    inout float3 normal, inout float3 diffuse, inout float gloss)
{
    float2 detailUv = uv * detailUvScaleBias.zw + detailUvScaleBias.xy;

    //diffuse
    float3 detailDif = tex2D(difMap, detailUv).xyz*DetailDiffuseColor;
    float3 detailOverlay = DetailOverlay(diffuse, detailDif);
    ComposeColor(diffuse, detailOverlay, mask, replaceMode);

    float3 detailNormGloss = tex2D(normMap, detailUv);

    //normal    
    float2 detailNormXy = detailNormGloss.xy*2.0f - 1.0f;
    float3 detailGlossOverlay = DetailOverlay(gloss, (1.0 - detailNormGloss.z));

    ComposeNormal(normal, detailNormXy, mask, replaceMode);

    //gloss
    ComposeColor(gloss, detailGlossOverlay*DetailGloss, mask, replaceMode);
}

//no normal calc version
void ColorizeDetailMapDGS(
    float2 uv, float mask,
    sampler2D difMap, sampler2D normMap, sampler2D specMap,
    float4 detailUvScaleBias, float3 DetailDiffuseColor, float4 DetailSpecColor, float replaceMode,
    inout float3 diffuse, inout float3 specColor, inout float gloss)
{
    float2 detailUv = uv * detailUvScaleBias.zw + detailUvScaleBias.xy;

    //diffuse
    float3 detailDif = tex2D(difMap, detailUv).xyz*DetailDiffuseColor;
    float3 detailOverlay = DetailOverlay(diffuse, detailDif);
    ComposeColor(diffuse, detailOverlay, mask, replaceMode);

    //specular
    float3 detailSpec = tex2D(specMap, detailUv).xyz*DetailSpecColor.xyz;
    ComposeColor(specColor, detailSpec, mask, replaceMode);

    float3 detailNormGloss = tex2D(normMap, detailUv);
    float3 detailGlossOverlay = DetailOverlay(gloss, (1.0 - detailNormGloss.z));

    //gloss
    ComposeColor(gloss, detailGlossOverlay*DetailSpecColor.w, mask, replaceMode);
}

void ColorizeDetailMapDS(
    float2 uv, float mask,
    sampler2D difMap, sampler2D normMap,
    float4 detailUvScaleBias, float3 DetailDiffuseColor, float DetailGloss, float replaceMode,
    inout float3 diffuse, inout float gloss)
{
    float2 detailUv = uv * detailUvScaleBias.zw + detailUvScaleBias.xy;

    //diffuse
    float3 detailDif = tex2D(difMap, detailUv).xyz*DetailDiffuseColor;
    float3 detailOverlay = DetailOverlay(diffuse, detailDif);
    ComposeColor(diffuse, detailOverlay, mask, replaceMode);

    float3 detailNormGloss = tex2D(normMap, detailUv);
    float3 detailGlossOverlay = DetailOverlay(gloss, (1.0 - detailNormGloss.z));

    //gloss
    ComposeColor(gloss, detailGlossOverlay*DetailGloss, mask, replaceMode);
}

float ComposeDetail(float2 uv, inout float3 normal, inout float3 diffuse, inout float3 specColor, inout float gloss)
{
    float3 mask = float3(1.0f, 1.0f, 1.0f);

#if DETAIL_MASK_TEXTURE
    mask = tex2D(DetailMaskMap, uv).xyz;
#endif

    //texture detail
#if DETAIL_MASK_TEXTURE_R
#if DETAIL_MASK_SPECULAR_R
    ColorizeDetailMapDNGS(uv, mask.r,
        DetailDiffuseMapR, DetailNormalMapR, DetailMetallicMapR,
        DetailUvScaleBiasR, DetailDiffuseColorR.xyz, DetailSpecularColorR, DetailDiffuseColorR.w,
        normal, diffuse, specColor, gloss);
#else
    ColorizeDetailMapDNG(uv, mask.r,
        DetailDiffuseMapR, DetailNormalMapR,
        DetailUvScaleBiasR, DetailDiffuseColorR.xyz, DetailSpecularColorR.w, DetailDiffuseColorR.w,
        normal, diffuse, gloss);
#endif
#endif

#if DETAIL_MASK_TEXTURE_G
#if DETAIL_MASK_SPECULAR_G
    ColorizeDetailMapDNGS(uv, mask.g,
        DetailDiffuseMapG, DetailNormalMapG, DetailMetallicMapG,
        DetailUvScaleBiasG, DetailDiffuseColorG.xyz, DetailSpecularColorG, DetailDiffuseColorG.w,
        normal, diffuse, specColor, gloss);
#else
    ColorizeDetailMapDNG(uv, mask.g,
        DetailDiffuseMapG, DetailNormalMapG,
        DetailUvScaleBiasG, DetailDiffuseColorG.xyz, DetailSpecularColorG.w, DetailDiffuseColorG.w,
        normal, diffuse, gloss);
#endif    
#endif
    return mask.b;
}

float ComposeDetail(float2 uv, inout float3 diffuse, inout float3 specColor, inout float gloss)
{
    float3 mask = float3(1.0f, 1.0f, 1.0f);

#if DETAIL_MASK_TEXTURE
    mask = tex2D(DetailMaskMap, uv).xyz;
#endif

    //texture detail
#if DETAIL_MASK_TEXTURE_R
#if DETAIL_MASK_SPECULAR_R
    ColorizeDetailMapDGS(uv, mask.r,
        DetailDiffuseMapR, DetailNormalMapR, DetailMetallicMapR,
        DetailUvScaleBiasR, DetailDiffuseColorR.xyz, DetailSpecularColorR, DetailDiffuseColorR.w,
        diffuse, specColor, gloss);
#else
    ColorizeDetailMapDS(uv, mask.r,
        DetailDiffuseMapR, DetailNormalMapR,
        DetailUvScaleBiasR, DetailDiffuseColorR.xyz, DetailSpecularColorR.w, DetailDiffuseColorR.w,
        diffuse, gloss);
#endif
#endif//DETAIL_MASK_TEXTURE_R

#if DETAIL_MASK_TEXTURE_G
#if DETAIL_MASK_SPECULAR_G
    ColorizeDetailMapDGS(uv, mask.g,
        DetailDiffuseMapG, DetailNormalMapG, DetailMetallicMapG,
        DetailUvScaleBiasG, DetailDiffuseColorG.xyz, DetailSpecularColorG, DetailDiffuseColorG.w,
        diffuse, specColor, gloss);
#else
    ColorizeDetailMapDS(uv, mask.g,
        DetailDiffuseMapG, DetailNormalMapG,
        DetailUvScaleBiasG, DetailDiffuseColorG.xyz, DetailSpecularColorG.w, DetailDiffuseColorG.w,
        diffuse, gloss);
#endif    
#endif   
    return mask.b;
}


#endif//QSSHADER_QSMaterialDetail_H