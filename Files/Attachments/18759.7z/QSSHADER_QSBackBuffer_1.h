#ifndef QSSHADER_QSBackBuffer_H
#define QSSHADER_QSBackBuffer_H

float4 BufferResInfo; //xy back buffer res's inv

float2 GetBackBufferUV(float2 vpos)
{
	return (vpos+0.5f) * BufferResInfo.xy;
}

#endif//QSSHADER_QSBackBuffer_H