#ifndef QSSHADER_QSPhysicalLightingGGX_H
#define QSSHADER_QSPhysicalLightingGGX_H
#include "DX12Defines.fxh"
#include "QSConstant.fxh"
#include "FunctionLib.fxh"
#include "QSShaderIndirectLighting.fxh"

float3 DiffuseLambert(float3 diffuseColor)
{
	return diffuseColor * InvPi;//inv pi
}

// [Burley 2012, "Physically-Based Shading at Disney"]
float3 DiffuseBurley(float3 diffuseColor, float roughness, float ndv, float ndl, float vdh)
{
	float fd90 = 0.5 + 2 * vdh * vdh * roughness;
	float fdv = 1 + (fd90 - 1) * QSPow5(1 - ndv);
	float fdl = 1 + (fd90 - 1) * QSPow5(1 - ndl);
	return diffuseColor * InvPi * fdv * fdl;
}

// GGX / Trowbridge-Reitz
// [Walter et al. 2007, "Microfacet models for refraction through rough surfaces"]
float DGGX(float roughness, float ndh)
{
	float a = roughness * roughness;
	float a2 = a * a;
	float d = (ndh * a2 - ndh) * ndh + 1;  // 2 mad
	return a2 * InvPi / (d * d);
}

// [Beckmann 1963, "The scattering of electromagnetic waves from rough surfaces"]
float D_Beckmann(float roughness, float ndh)
{
	float a = roughness * roughness;
	float a2 = a * a;
	float ndh2 = ndh * ndh;
	return exp((ndh2 - 1) / (a2 * ndh2)) / (PI * a2 * ndh2 * ndh2);
}

// Appoximation of joint Smith term for GGX
// [Heitz 2014, "Understanding the Masking-Shadowing Function in Microfacet-Based BRDFs"]
float VisSmithJointApprox(float roughness, float ndv, float ndl)
{
	float a = roughness * roughness;
	float visSmithV = ndl * (ndv * (1 - a) + a);
	float visSmithL = ndv * (ndl * (1 - a) + a);
	// Note: will generate NaNs with roughness = 0, prevent roughness to be 0.
	return 0.5 / (visSmithV + visSmithL);
}

// [Schlick 1994, "An Inexpensive BRDF Model for Physically-Based Rendering"]
float3 FSchlick(float3 specularColor, float vdh)
{
	float fc = QSPow5(1 - vdh);
	return saturate(50.0 * specularColor.g) * fc + (1 - fc) * specularColor;
	//return specularColor + (1 - specularColor) * fc;
}

inline void GGXDirectLighting(inout float3 diffuseLighting, inout float3 specularLighting, out float ndl, out float ndh, float3 diffuseColor, float3 specularColor, float3 lightColor, float roughness, float3 l, float3 v, float3 n, float shadowValue)
{
	float3 h = normalize(-v - l);
	ndl = clamp(dot(n, -l), 1e-5, 1.0f);
	float ndv = saturate(abs(dot(n, -v)) + 1e-5);
	ndh = saturate(dot(n, h));
	float vdh = saturate(dot(-v, h));

	//microfacet specular
	float D = DGGX(roughness, ndh);
	float Vis = VisSmithJointApprox(roughness, ndv, ndl);
	float3 F = FSchlick(specularColor, vdh);
	specularLighting = (D * Vis) * F;

	diffuseLighting = DiffuseLambert(diffuseColor);
	float3 lightingCommon = lightColor * ndl * shadowValue;
	diffuseLighting *= lightingCommon;
	specularLighting *= lightingCommon;
}

//env lighting part
sampler2D PreIntegratedGF;
float3 EnvBRDF(float3 specularColor, float roughness, float ndv)
{
	float2 AB = tex2D(PreIntegratedGF, NoMipMapLinearClamp, float2(ndv, roughness)).rg;
	// Anything less than 2% is physically impossible and is instead considered to be shadowing 
	float3 GF = specularColor * AB.x + saturate(50.0f * specularColor.g) * AB.y;
	return GF;
}

float3 EnvBRDFApprox(float3 specularColor, float roughness, float ndv)
{
	// [ Lazarov 2013, "Getting More Physical in Call of Duty: Black Ops II" ]
	// Adaptation to fit our G term.
	const half4 c0 = { -1, -0.0275, -0.572, 0.022 };
	const half4 c1 = { 1, 0.0425, 1.04, -0.04 };
	half4 r = roughness * c0 + c1;
	float a004 = min(r.x * r.x, exp2(-9.28 * ndv)) * r.x + r.y;
	half2 AB = half2(-1.04, 1.04) * a004 + r.zw;
	AB.y *= saturate(50.0f * specularColor.g);
	return specularColor * AB.x + AB.y;
}

float ComputeCubemapMipFromRoughness(float roughness, float mipCount)
{
	float level = 3 - 1.15f * log2(roughness);
	return max(mipCount - 1 - level, 0);
}

#define REFLECTION_CAPTURE_ROUGHEST_MIP 1
#define REFLECTION_CAPTURE_ROUGHNESS_MIP_SCALE 1.2

/**
 * Compute absolute mip for a reflection capture cubemap given a roughness.
 */
float ComputeReflectionCaptureMipFromRoughness(float Roughness, float CubemapMaxMip)
{
    // Heuristic that maps roughness to mip level
    // This is done in a way such that a certain mip level will always have the same roughness, regardless of how many mips are in the texture
    // Using more mips in the cubemap just allows sharper reflections to be supported
    float LevelFrom1x1 = REFLECTION_CAPTURE_ROUGHEST_MIP - REFLECTION_CAPTURE_ROUGHNESS_MIP_SCALE * log2(Roughness);
    return max(CubemapMaxMip - 1 - LevelFrom1x1, 0);
}

#if ENV_MAP_APPLY || ENHANCE_INDIRECT_LIGHTING
TextureCube IBLSpecularCubeMap;
TextureCube IBLDiffuseCubeMap;
Texture2D IrradianceVolume0;
Texture2D IrradianceVolume1;
Texture2D IrradianceVolume2;
Texture2D IrradianceVolume3;
Texture2D IrradianceVolume4;
Texture2D IrradianceVolume5;
Texture2D IrradianceVolume6;
float4 IBLDiffuseTintColor;
float4 IBLSpecularTintColor;
float  IBLDiffuseMipLevel;
float4 IrradianceVolumeParam;
#define VolumeOrigin IrradianceVolumeParam.xy
#define VolumeScale IrradianceVolumeParam.zw

#define IBLSpecularSaturationAdjust  (IBLSpecularTintColor.w)
#define IBLDiffuseSaturationAdjust	 (IBLDiffuseTintColor.w)

void AdjustSaturation(inout float3 finalColor, float deltaS)
{
	float cArray[3] = { finalColor.r, finalColor.g, finalColor.b };
	int minIdx = 1;
	int maxIdx = 0;
	int midIdx = 0;
	if (cArray[0] < cArray[1])
	{
		minIdx = 0;
		maxIdx = 1;
	}

	maxIdx = cArray[2] > cArray[maxIdx] ? 2 : maxIdx;
	minIdx = cArray[2] <= cArray[minIdx] ? 2 : minIdx;
	midIdx = 3 - maxIdx - minIdx;

	float cMax = cArray[maxIdx];
	float cMin = cArray[minIdx];
	float cMid = cArray[midIdx];

	if (cMax == cMin)
	{
		return;
	}

	float cDelta = cMax - cMin;
	float satSrc = cDelta / cMax;
	float satDest = saturate(satSrc + deltaS);
	float satDelta = satDest - satSrc;

	float cMinNew = cMin - satDelta * cMax;
	float cMidNew = min(cMinNew + (cMid - cMin) * (cMax - cMinNew) / cDelta, cMax);
	cArray[minIdx] = cMinNew;
	cArray[midIdx] = cMidNew;
	finalColor = float3(cArray[0], cArray[1], cArray[2]);
}

float2 GetIrradianceUV(float3 worldPos)
{
	const float2 uv = (worldPos.xy - VolumeOrigin) * VolumeScale;
	return uv;
}

float3 SampleIrradianceVolume(float3 worldPos, float3 normal)
{
	float4 uv = float4(GetIrradianceUV(worldPos), 0, 0);

	// https://developer.amd.com/wordpress/media/2012/10/Tatarchuk_Irradiance_Volumes.pdf
	float4 cAr = tex2Dlod(IrradianceVolume0, NoMipMapLinearClamp, uv); // first 4 red irradiance coefficients
	float4 cAg = tex2Dlod(IrradianceVolume1, NoMipMapLinearClamp, uv); // first 4 green irradiance coefficients
	float4 cAb = tex2Dlod(IrradianceVolume2, NoMipMapLinearClamp, uv); // first 4 blue irradiance coefficients
	float4 cBr = tex2Dlod(IrradianceVolume3, NoMipMapLinearClamp, uv); // second 4 red irradiance coefficients
	float4 cBg = tex2Dlod(IrradianceVolume4, NoMipMapLinearClamp, uv); // second 4 green irradiance coefficients
	float4 cBb = tex2Dlod(IrradianceVolume5, NoMipMapLinearClamp, uv); // second 4 blue irradiance coefficients
	float4 cC = tex2Dlod(IrradianceVolume6, NoMipMapLinearClamp, uv); // last 1 irradiance coefficient for red, blue and green

	float3 x1, x2, x3;
	float4 vNormal = float4(normal.xzy, 1);
	// Linear + constant polynomial terms
	x1.r = dot(cAr, vNormal);
	x1.g = dot(cAg, vNormal);
	x1.b = dot(cAb, vNormal);
	// 4 of the quadratic polynomials
	float4 vB = vNormal.xyzz * vNormal.yzzx;
	x2.r = dot(cBr, vB);
	x2.g = dot(cBg, vB);
	x2.b = dot(cBb, vB);
	// Final quadratic polynomial
	float vC = vNormal.x*vNormal.x - vNormal.y*vNormal.y;
	x3 = cC.rgb * vC;
	float3 cubeColor =  x1 + x2 + x3;	// Do not need divide PI because already divided in constants
	
	if (IBLDiffuseSaturationAdjust != 0.0f)
	{
		AdjustSaturation(cubeColor.xyz, IBLDiffuseSaturationAdjust);
	}
    return cubeColor*IBLDiffuseTintColor.xyz;
}

float3 SampleDiffuseIBL(float3 reflectDir)
{
	float3 cubeColor = IBLDiffuseCubeMap.SampleLevel(MipMapLinear, reflectDir.xzy, IBLDiffuseMipLevel).xyz;
	if (IBLDiffuseSaturationAdjust != 0.0f)
	{
		AdjustSaturation(cubeColor.xyz, IBLDiffuseSaturationAdjust);
	}
    return cubeColor*IBLDiffuseTintColor.xyz;
}

float3 SampleSpecularIBL(float3 reflectDir, float mip)
{
#if (AMBIENT_CUBEMAP_OUTDOOR || AMBIENT_CUBEMAP_INDOOR) && !ENV_CAPTURE_OUTDOOR && !ENV_CAPTURE_INDOOR
	float4 cubeColor = IBLSpecularCubeMap.SampleLevel(MipMapLinear, reflectDir.xzy, mip);
	if (IBLSpecularSaturationAdjust != 0.0f)
	{
		AdjustSaturation(cubeColor.xyz, IBLSpecularSaturationAdjust);
	}
	float4 envMapColor = cubeColor * EnvMapPSParam.y;
    envMapColor.xyz *= IBLSpecularTintColor.xyz;
#else
    float4 envMapColor = EnvMap.SampleLevel(MipMapLinear, reflectDir.xzy, mip)*EnvMapPSParam.x;    
#endif

    return envMapColor.xyz;
}

float3 EnvLighting(float3 specularColor, float roughness, float3 v, float3 n, float ao)
{
    float mipNum = EnvMapPSParam.w;
    float ndv = dot(v, n);
	float3 reflectDir = 2 * ndv * n - v;
	// Point lobe in off-specular peak direction
	float a = roughness * roughness;
	float3 r = lerp(n, reflectDir, (1 - a) * (sqrt(1 - a) + a));
	float mip = ComputeCubemapMipFromRoughness(roughness, mipNum);

    float3 envSpecLighting = EnvBRDFApprox(specularColor, roughness, ndv);

    float specOcclusion = saturate( Square( ndv + ao ) - 1.0f + ao );
    envSpecLighting *= specOcclusion;

    float3 envMapColor = SampleSpecularIBL(r,mip);	
	return envMapColor.rgb * envSpecLighting;
}
#endif
#endif//QSSHADER_QSPhysicalLightingGGX_H