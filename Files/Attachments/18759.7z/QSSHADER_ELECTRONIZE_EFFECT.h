#ifndef QSSHADER_ELECTRONIZE_EFFECT_H
#define QSSHADER_ELECTRONIZE_EFFECT_H
#include "QSGameTime.h"
sampler NoiseTex0;
sampler ScanlineTex;
//global param
float4 ScanlineEmissiveParam;
float4 OpacityParam;
float4 ParticalColorAdjust;
float4 FringeColor;
float4 DiffuseColorAdjust;

//per instance param
float4 DissolveControlParam;
float4 FlowingLightControlParam;
float4 ObjBBMin;
float4 ObjBBMax;
float4x4 AttLocalTransform;

sampler EdgeColorAdjustTex;
sampler EdgeCloudTex;
sampler EdgeProjectorScanlineTex;

float4 FlowingLightScanlineEmissiveParam;
float4 FlowingLightOpacityParam;
float4 FlowingLightParticalColorAdjust;
float4 FlowingLightFringeColor;

//bait effect param
float4 ScanColorParam;
float4 ShakeParam;

float  UseAlphaForRoughness;

#define PlaneVector               float3(0,0,1)
#define OpacityLength             OpacityParam.x
#define FringeAmount              OpacityParam.y
#define NoiseFade                 OpacityParam.z
#define OpacityPower              OpacityParam.w
#define DissolveAmount            DissolveControlParam.x
#define Bost                      DissolveControlParam.y
#define EmissiveControl           DissolveControlParam.z

#define FringePower               FringeColor.w
#define ScanlineInvFadeDistance   ScanlineEmissiveParam.x
#define ScanlineScale             ScanlineEmissiveParam.y


#define FlowingLightOpacityLength             FlowingLightOpacityParam.x
#define FlowingLightFringeAmount              FlowingLightOpacityParam.y
#define FlowingLightNoiseFade                 FlowingLightOpacityParam.z
#define FlowingLightOpacityPower              FlowingLightOpacityParam.w
#define FlowingLightDissolveAmount            FlowingLightControlParam.x
#define FlowingLightBost                      FlowingLightControlParam.y
#define FlowingLightEmissiveControl           FlowingLightControlParam.z

#define FlowingLightFringePower               FlowingLightFringeColor.w
#define FlowingLightScanlineInvFadeDistance0  FlowingLightScanlineEmissiveParam.x
#define FlowingLightScanlineScale0            FlowingLightScanlineEmissiveParam.y
#define FlowingLightScanlineInvFadeDistance1  FlowingLightScanlineEmissiveParam.z
#define FlowingLightScanlineScale1            FlowingLightScanlineEmissiveParam.w


#define NOISE_TILING_0 float2(5,5)
#define NOISE_TILING_1 float2(2,2)
#define NOISE_TILING_2 float2(5,5)
#define NOISE_TILING_3 float2(8,8)

#define ScanLineJitter float2(ScanColorParam.x, ScanColorParam.y)
#define ColorDrift float2(ScanColorParam.z, ScanColorParam.w)
#define VerticalJump float2(ShakeParam.x, ShakeParam.y)
#define HorizontalShake ShakeParam.z


#define CLIP_VALUE 0.3333333

//textures
//-------------------------------------------------------------------------
//lighting ps and vs
//-------------------------------------------------------------------------
#if ELECTRONIZE
float sphereMask(float distance, float invRadius, float hardness)
{
	return saturate((1 + hardness * 0.01) * (1 - distance * invRadius));

}

void GetOpacityMaskAndEmissive(float3 objBBMin, float3 objBBMax, float3 objPos, float3 planeVec, float opacityLength, float noise, float noiseFade,
	float dissolveAmount, float3 fringeColor, float fringeAmount, float fringePower, float opacityPower, float vFace,
	inout float opacityMask, inout float3 emissiveColor)
{

	float percent = dot(planeVec, 1 - (objPos - objBBMin) / (objBBMax - objBBMin)) / opacityLength;
	float noiseValue = noise * noiseFade + percent;
	float dissolvedNoise = saturate(pow(max(noiseValue - (dissolveAmount + fringeAmount), 0), opacityPower));
	opacityMask = max(dissolvedNoise, saturate(noiseValue - dissolveAmount));
	emissiveColor = lerp(fringeColor, lerp(fringeColor, fringePower, dissolvedNoise), vFace);//
}

float2 Planner(float2 uv, float time, float2 speed)
{
	return uv + time * speed;
}

float NRand(float x, float y)
{
	return frac(sin(dot(float2(x, y), float2(12.9898, 78.233))) * 43758.5453);
}

void GetDistortionUV(float2 uv0, inout float2 uv1, inout float2 uv2)
{
	float u = uv0.x;
	float v = uv0.y;

	float jitter = NRand(v, GameTime.x) * 2 - 1;
	jitter *= step(ScanLineJitter.y, abs(jitter)) * ScanLineJitter.x;

	float jump = lerp(v, frac(v + VerticalJump.y), VerticalJump.x);
	float shake = (NRand(GameTime.x, 2) - 0.5) * HorizontalShake;
	float drift = sin(jump + ColorDrift.y) * ColorDrift.x;

	uv1 = frac(float2(u + jitter + shake, jump));
	uv2 = frac(float2(u + jitter + shake + drift, jump));
}

float GetNoise(float2 uv, float2 noiseTiling0, float2 noiseTiling1)
{
	float2 uv0 = Planner(uv * noiseTiling0, GameTime.x, float2(0, 0.5));
	float2 uv1 = Planner(uv * noiseTiling1, GameTime.x, float2(0, 1.0));

	float noise0 = tex2Dlod(NoiseTex0, float4(uv0, 0, 0)).r;
	float noise1 = tex2Dlod(NoiseTex0, float4(uv1, 0, 0)).g;

	return noise0 * noise1;
}

float GetFresnel(float3 normal, float3 viewDir, float f0, float exponent)
{
	return f0 + (1 - f0) * pow(1 - saturate(dot(normal, viewDir)), exponent);
}

float3 GetScanline(float2 uv, float2 screenUv, float3 viewDir, float3 normal, float pixelDepth
	, float scanlineScale, float3 particalColorAdjust, float scanlineInvFadeDistance, float2 uvModifier = 1.0)
{
	float cameraDistFade = clamp(1 - sphereMask(pixelDepth, scanlineInvFadeDistance, 30.0), 0.2, 1.0);
	float scanline = tex2D(ScanlineTex, screenUv * (1.0 / scanlineScale * 10000) * uvModifier).r;

	float3 colorAdjust = particalColorAdjust.rgb * saturate(GetFresnel(normal, viewDir, 0.0, 1.0));

	return colorAdjust * lerp(cameraDistFade, 1.0, scanline);
}

float3 BlendOverlay(float3 base, float3 blend)
{
	float3 base0 = 2 * (1 - base);
	float3 blendFinal = 1 - (1 - blend) * base0;
	float3 baseFinal = base * 2 * blend;

	return base > 0.5 ? blendFinal : baseFinal;
}

#define EDGE_CONSTANT_COLOR float3(0.119,0.077,0.2)
float3 GetEdgeColor(float2 uv, float2 screenUv, float3 viewDir, float3 normal, float pixelDepth, float3 particalColorAdjust)
{
	float fresnel0 = GetFresnel(normal, viewDir, 0.0, 7.0);

	float zFade = 1 - saturate((GetViewZFromScreenUv(screenUv) - pixelDepth) / 30);
	float zFadeFactor = saturate(GetFresnel(normal, viewDir, 0.0, 2.0) + zFade);

	float2 reflectVecRG = reflect(-viewDir, normal).rg;
	float3 colorAdjust = tex2D(EdgeColorAdjustTex, reflectVecRG);

	float3 particalColor = (particalColorAdjust * (fresnel0 + zFade) * 4.0 + colorAdjust) * 0.7;
	float3 particalEdgeBlend = lerp(particalColorAdjust, colorAdjust, 0.4) + particalColor;

	return lerp(EDGE_CONSTANT_COLOR * particalColorAdjust, 1, zFadeFactor) * particalEdgeBlend;
}

float3 GetBodyLine(float2 uv)
{
	return tex2D(EdgeCloudTex, uv).r * tex2D(EdgeProjectorScanlineTex, Planner(uv, GameTime.x, float2(0.0, 0.05))).g * 0.35;
}

#endif

#endif