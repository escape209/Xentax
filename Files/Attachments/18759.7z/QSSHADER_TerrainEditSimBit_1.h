#ifndef QSSHADER_TerrainEditSimBit_H
#define QSSHADER_TerrainEditSimBit_H

//src : 8bit float source
//dst0 : decode result, lower 4 bit
//dst1 : high 4bit
void DecodeBit8(float src, out float4 dst0, out float4 dst1)
{	
	float bitValue[8];
		
	for(int i=7; i>=0; i--)
	{
		src *= 2.0f;
		if(src>=1.0f)
		{
			bitValue[i] = 1.0f;
			src -= 1.0f;
		}
		else
		{
			bitValue[i] = 0.0f;
		}
	}

	dst0 = float4(bitValue[0], bitValue[1], bitValue[2], bitValue[3]);
	dst1 = float4(bitValue[4], bitValue[5], bitValue[6], bitValue[7]);
}

//encode 8 bit value into one float, src0 lower 4bit, src1 higher 4bit
float EncodeBit8(float4 src0, float4 src1)
{	
	float4 factor0 = float4(1.0f, 2.0f, 4.0f, 8.0f);
	float4 factor1 = float4(16.0f, 32.0f, 64.0f, 128.0f);
	float result = dot(src0, factor0)+dot(src1, factor1);
	return result/255.0f;
}

float OperationOr(float a, float b)
{
	return (a>0.0f || b>0.0f) ? 1.0f : 0.0f;
}

float4 OperationOr(float4 a, float4 b)
{
	float4 result;
	result.x = OperationOr(a.x,b.x);
	result.y = OperationOr(a.y,b.y);
	result.z = OperationOr(a.z,b.z);
	result.w = OperationOr(a.w,b.w);
	return result;
}

float OperationAnd(float a, float b)
{
	return (a>0.0f && b>0.0f) ? 1.0f : 0.0f;
}

float4 OperationAnd(float4 a, float4 b)
{
	float4 result;
	result.x = OperationAnd(a.x,b.x);
	result.y = OperationAnd(a.y,b.y);
	result.z = OperationAnd(a.z,b.z);
	result.w = OperationAnd(a.w,b.w);
	return result;
}

float OperationNot(float a)
{
	return a>0.0f ? 0.0f : 1.0f;
}

float4 OperationNot(float4 a)
{
	float4 result;
	result.x = OperationNot(a.x);
	result.y = OperationNot(a.y);
	result.z = OperationNot(a.z);
	result.w = OperationNot(a.w);

	return result;
}

float SimOr(float v1, float v2)
{
	float4 v10, v11, v20, v21;
	DecodeBit8(v1, v10, v11);
	DecodeBit8(v2, v20, v21);

	v10 = OperationOr(v10, v20);
	v11 = OperationOr(v11, v21);

	return EncodeBit8(v10, v11);
}

float SimAnd(float v1, float v2)
{
	float4 v10, v11, v20, v21;
	DecodeBit8(v1, v10, v11);
	DecodeBit8(v2, v20, v21);

	v10 = OperationAnd(v10, v20);
	v11 = OperationAnd(v11, v21);

	return EncodeBit8(v10, v11);
}

float SimNAnd(float v1, float v2)
{
	float4 v10, v11, v20, v21;
	DecodeBit8(v1, v10, v11);
	DecodeBit8(v2, v20, v21);

	v20 = OperationNot(v20);
	v21 = OperationNot(v21);

	v10 = OperationAnd(v10, v20);
	v11 = OperationAnd(v11, v21);

	return EncodeBit8(v10, v11);
}

float SimBitRead(float src, int bitIdx)
{
	for(int i=7; i>=0; i--)
	{
		src *= 2.0f;
		if(src>=1.0f)
		{
            if (bitIdx == i)
                return 1.0f;
			src -= 1.0f;
		}
		else
		{
            if (bitIdx == i)
                return 0.0f;
		}
	}

	return 0.0f;
}

#endif // QSSHADER_TerrainEditSimBit_H