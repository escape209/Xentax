#ifndef QSSHADER_CommonNormalFunc_H
#define QSSHADER_CommonNormalFunc_H

//param baseNormal, the base normal, we'll reorient detail normal based on baseNormal;
//make sure baseNormal's normalized；and baseNormal.z>0, otherwise u need to handle the singularity case//
//original func is; from https://blog.selfshadow.com/publications/blending-in-detail/
float3 ReorientNormal(float3 baseNormal, float3 detailNormal)
{
	float3 t = float3(baseNormal.xy,baseNormal.z+1.0f);
    float3 u = float3(-detailNormal.xy, detailNormal.z);
    return t*dot(t,u)/t.z-u;    
}

float3 DecodeNormal(float2 xy)
{
    float z = sqrt(max(1.0f - dot(xy,xy),0.0f));
    return float3(xy,z);
}
#endif//QSSHADER_NormalCompose_H