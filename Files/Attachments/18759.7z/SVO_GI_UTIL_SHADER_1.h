#ifndef SVO_GI_UTIL_SHADER_H
#define SVO_GI_UTIL_SHADER_H

#include "DX12Defines.fxh"
#include "QSScreenSpaceDepth.fxh"
#include "PostFx.fxh"
texture2D GIBuffer;
float4 GIBaseDiffuseParam;
#define BaseDiffuseNearIntensity		   (GIBaseDiffuseParam.x)
#define BaseDiffuseFarIntensity			   (GIBaseDiffuseParam.y)
#define BaseDiffuseIntensityFadeStart	   (GIBaseDiffuseParam.z)
#define BaseDiffuseIntensityFadeRange	   (GIBaseDiffuseParam.w)

float3 CompositeGI(float3 baseDiffuse, float viewDepth, float2 screenUv, float3 matDiffuse)
{
    float baseDiffuseIntensity =
		lerp(BaseDiffuseNearIntensity, BaseDiffuseFarIntensity,
		saturate((viewDepth - BaseDiffuseIntensityFadeStart) / BaseDiffuseIntensityFadeRange));
    float3 GI = GIBuffer.SampleLevel(NoMipMapPointClamp, screenUv, 0).xyz;
    return baseDiffuseIntensity * baseDiffuse + GI * matDiffuse;
}

Texture2D SceneRgbTexMin;
Texture2D SceneAldTexMin;
Texture2D SceneRgbTexMax;
Texture2D SceneAldTexMax;
float4 GIBufferResolution;
float3 CompositeHairTransparencyGI(float3 normal, float3 baseDiffuse, float viewDepth, float2 screenUv, float3 matDiffuse)
{
	const float fDepthRange = .12;
	const float fDotMax = .20;
	const float fLinearDepthC = viewDepth / FarPlane;
	const float fDepthClampMin = 400.f / FarPlane;
	float4 vRGB = 0;
	float4 vALD = 0;

	// define sampling kernel
	const int samplesNum = 5;
	const float4 sampleTM = float4(GIBufferResolution.zw * 1.5f, GIBufferResolution.zw * 0.25f);
	const float2 arrSamples[samplesNum] =
	{
		// TODO: try (-1,0), (0,1) ....
		float2(0, -1) * sampleTM.xy - sampleTM.zw,
		float2(0, 1) * sampleTM.xy - sampleTM.zw,
		float2(-1, 0) * sampleTM.xy - sampleTM.zw,
		float2(1, 0) * sampleTM.xy - sampleTM.zw,
		float2(0, 0) * sampleTM.xy - sampleTM.zw,
	};

	for (int s = 0; s < samplesNum; s++)
	{
		const float4 tc = float4(screenUv + arrSamples[s], 0, 0);

		const float4 vDiff_RGB_Min = tex2D(SceneRgbTexMin, NoMipMapLinearClamp, tc.xy);
		const float4 vDiff_ALD_Min = tex2D(SceneAldTexMin, NoMipMapLinearClamp, tc.xy);
		const float4 vDiff_RGB_Max = tex2D(SceneRgbTexMax, NoMipMapLinearClamp, tc.xy);
		const float4 vDiff_ALD_Max = tex2D(SceneAldTexMax, NoMipMapLinearClamp, tc.xy);

		// reduce artifacts around 1p weapon
		const float fDepthMin = max(fDepthClampMin, vDiff_RGB_Min.w);
		const float fDepthMax = max(fDepthClampMin, vDiff_RGB_Max.w);

		float fLerp = saturate((fLinearDepthC - fDepthMin) / max(fDepthMax - fDepthMin, 0.0001f));

		float4 vDiff_RGB = lerp(vDiff_RGB_Min, vDiff_RGB_Max, fLerp);
		float4 vDiff_ALD = lerp(vDiff_ALD_Min, vDiff_ALD_Max, fLerp);

		const float fDepth1 = vDiff_RGB.w;

		const float3 vNorm = vDiff_ALD;

		float fDotTest = lerp(.25, saturate(dot(normalize(vNorm), normal) - fDotMax),
		saturate(length(vNorm) / max(0.0001, vDiff_ALD.w) * 8.f));

		float fDepTest = saturate((fDepthRange - abs(1.f - fLinearDepthC / fDepth1)) * 4);

		float fW = fDepTest * fDotTest;

		fW += +.001;

		vRGB.xyz += vDiff_RGB.xyz * fW;
		vALD += vDiff_ALD * fW;
		vRGB.w += fW;
	}

	if (vRGB.w)
	{
		vRGB.xyz /= vRGB.w;
		vALD /= vRGB.w;
	}

	// copmute lighting
	const float fDirIntens = max(0, length(vALD.xyz));
	const float3 vH = normalize(vALD.xyz);
	const float NdotH = dot(normal, vH);
	const float fIntensity = fDirIntens * (saturate(NdotH)) + max(0, vALD.w - fDirIntens);
	const float brdf = InvPi;
	float3 gi = vRGB * fIntensity * brdf;
	
	float baseDiffuseIntensity =
		lerp(BaseDiffuseNearIntensity, BaseDiffuseFarIntensity,
		saturate((viewDepth - BaseDiffuseIntensityFadeStart) / BaseDiffuseIntensityFadeRange));
	return baseDiffuseIntensity * baseDiffuse + gi * matDiffuse;
}
#endif 