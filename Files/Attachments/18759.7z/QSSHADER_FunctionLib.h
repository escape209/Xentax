#ifndef QSSHADER_FunctionLib_H
#define QSSHADER_FunctionLib_H
//common functions

#ifdef 0
#define HLSL_ISOLATE [isolate]
#define HLSL_BRANCH  [branch]
#define HLSL_FLATTEN [flatten]
#define HLSL_LOOP    [loop]
#else
#define HLSL_ISOLATE
#define HLSL_BRANCH
#define HLSL_FLATTEN
#define HLSL_LOOP
#endif
/*
 *	decompress
 */

#define SAMPLE_TEX(tex,uv)		tex2D(tex,uv)

float4 BiDecompress(float4 v)
{
    return v * 2.0f - 1.0f;
}

float3 BiDecompress(float3 v)
{
    return v * 2.0f - 1.0f;
}

float2 BiDecompress(float2 v)
{
    return v * 2.0f - 1.0f;
}

float BiDecompress(float v)
{
    return v * 2.0f - 1.0f;
}

half4 BiDecompress(half4 v)
{
    return v * 2.0h - 1.0h;
}

half3 BiDecompress(half3 v)
{
    return v * 2.0h - 1.0h;
}

half2 BiDecompress(half2 v)
{
    return v * 2.0h - 1.0h;
}

half BiDecompress(half v)
{
    return v * 2.0h - 1.0h;
}

/*
 *	compress
 */

float BiCompress(float param)
{
    return param * 0.5f + 0.5f;
}

float3 BiCompress(float3 param)
{
    return param * 0.5f + 0.5f;
}

float4 BiCompress(float4 param)
{
    return param * 0.5f + 0.5f;
}

float2 ComplexMul(float2 a, float2 b)
{
    float2 result = float2(a.r*b.r-a.g*b.g, a.r*b.g+a.g*b.r);
    return result;
}

float4 DecompressCharToFloat( int4 val )
{
	float4 vec = val * 0.007874f - 1.0;

	/*vec.x = (float)(val[0]  / 127.00f)-1.0;
	vec.y = (float)(val[1]  / 127.00f)-1.0;
	vec.z = (float)(val[2]  / 127.00f)-1.0;
	vec.w = (float)(val[3]  / 127.00f)-1.0;*/
	return vec;
}

float4 DecompressColorbToFloat( int4 val )
{
	float4 vec = val * 0.003921569f;    // val/255
	return vec;
}

float3 DecodeByteToNormalizeF( int4 val )
{
	float4 weights;
	weights[0] = (val[0] / 255.0f);
	weights[1] = (val[1] / 255.0f);
	weights[2] = (val[2] / 255.0f);
	return weights;
}

void DecodeQTangents(float4 qtangents, out float3 normal, out float3 tangent, out float3 binormal)
{
	tangent = float3(
		1 - 2 * (qtangents.y * qtangents.y + qtangents.z * qtangents.z),
		2 * (qtangents.x * qtangents.y + qtangents.w * qtangents.z),
		2 * (qtangents.x * qtangents.z - qtangents.w * qtangents.y));
	binormal = float3(
		2 * (qtangents.x * qtangents.y - qtangents.w * qtangents.z),
		1 - 2 * (qtangents.x * qtangents.x + qtangents.z * qtangents.z),
		2 * (qtangents.y * qtangents.z + qtangents.w * qtangents.x));
	normal = cross(tangent, binormal) * sign(qtangents.w);
}

//specular power and gloss transition
//util functions
#define GLOSS_ENCODE_FACTOR 13.0f

float GetSpecPowerFromGloss(float gloss)
{
    return pow(2,GLOSS_ENCODE_FACTOR*gloss);
}

float GetGlossFromSpecPower(float specPower)
{
    return log2(specPower)/GLOSS_ENCODE_FACTOR;
}

//Use shpere map to save normal in 2 channels
half2 NormalEncode (float3 n)
{
	half p = sqrt(n.z*8+8);
	return half2(n.xy/p + 0.5);
}

float3 NormalDecode (half2 enc)
{
	half2 fenc = enc*4-2;
	half f = dot(fenc,fenc);
	half g = sqrt(1-f/4);
	float3 n;
	n.xy = fenc*g;
	n.z = 1-f/2;
	return n;
}

void AlphaTest(float alpha)
{
	clip(alpha-0.5f);
}

void TranslucentAlphaTest(float alpha)
{
	clip(alpha-1.0f);
}

float2 ScreenToTex(float2 screenPos)
{
	return screenPos * float2(0.5f,-0.5f) + 0.5f;
}
float2 TexToScreen(float2 uv)
{
	return (uv - 0.5f) * float2(2.0f,-2.f);
}

float4 CubicSmooth(float4 vData)
{
	return vData * vData * (3.0 - 2.0 * vData);
}

float4 TriangleWave(float4 vData)
{
	return abs((frac(vData + 0.5) * 2.0) - 1.0);
}
float4 TrigApproximate(float4 vData)
{
	return (CubicSmooth(TriangleWave(vData)) - 0.5) * 2.0;
}

float4 TrigApproximate0to1(float4 vData)
{
	return (CubicSmooth(TriangleWave(vData)));
}

float3 ColorContrast(float3 src, float c)
{	
	float3 result = src*(1.0f+c)-0.5f*c;
	return saturate(result);
}
#include "PostFxColor.h"
float3 CalcUnderwaterFog( float3 srcColor, float3 fogColor, float sat, float lum, float depthDelta, float density )
{
	float factor = density * depthDelta * 0.0006;
	float delta = 1/exp( factor*factor );

	float3 finalColor = lerp(fogColor, srcColor, delta);
	//Saturation and luminance adjust
	float3 hsl = RgbToHsl(finalColor.rgb);

	hsl.g *= sat;
	hsl.b *= lum;
	finalColor.rgb = HslToRgb(hsl);

	return finalColor;

}
//Function for rgb & yuv convert
float3 rgb_to_yuv(float3 RGB)
{
	float y = dot(RGB,float3(0.299,0.587,0.114));
	float u = (RGB.z - y) * 0.565;
	float v = (RGB.x - y) * 0.713;
	return float3(y,u,v);
}

float3 yuv_to_rgb(float3 YUV)
{
	float u = YUV.y;
	float v = YUV.z;
	float r = YUV.x + 1.403*v;
	float g = YUV.x - 0.344*u - 1.403*v;
	float b = YUV.x + 1.770*u;
	return float3(r,g,b);
}

float GetSaturation(float3 rgb)
{
	rgb *= 255.0f;
	float maxValue = max(rgb.r, max(rgb.g, rgb.b));
	float minValue = min(rgb.r, min(rgb.g, rgb.b));

	return ((maxValue - minValue)/maxValue);
}

float QSPow5(float v)
{
    float r = v * v;
    r *= r;
    return r*v;
}

//from unity shader code
//temply use the same version
inline float3 GammaToLinearSpace (float3 sRGB)
{
	// Approximate version from http://chilliant.blogspot.com.au/2012/08/srgb-approximations-for-hlsl.html?m=1
	//return sRGB * (sRGB * (sRGB * 0.305306011f + 0.682171111f) + 0.012522878f);
	return pow(sRGB, 2.2f);
}

float Square( float x )
{
    return x*x;
}

float2 Square( float2 x )
{
    return x*x;
}

float3 Square( float3 x )
{
    return x*x;
}

float4 Square( float4 x )
{
    return x*x;
}

float Pow2( float x )
{
    return x*x;
}

float2 Pow2( float2 x )
{
    return x*x;
}

float3 Pow2( float3 x )
{
    return x*x;
}

float4 Pow2( float4 x )
{
    return x*x;
}

float Pow3( float x )
{
    return x*x*x;
}

float2 Pow3( float2 x )
{
    return x*x*x;
}

float3 Pow3( float3 x )
{
    return x*x*x;
}

float4 Pow3( float4 x )
{
    return x*x*x;
}

float Pow4( float x )
{
    float xx = x*x;
    return xx * xx;
}

float2 Pow4( float2 x )
{
    float2 xx = x*x;
    return xx * xx;
}

float3 Pow4( float3 x )
{
    float3 xx = x*x;
    return xx * xx;
}

float4 Pow4( float4 x )
{
    float4 xx = x*x;
    return xx * xx;
}

float Pow5( float x )
{
    float xx = x*x;
    return xx * xx * x;
}

float2 Pow5( float2 x )
{
    float2 xx = x*x;
    return xx * xx * x;
}

float3 Pow5( float3 x )
{
    float3 xx = x*x;
    return xx * xx * x;
}

float4 Pow5( float4 x )
{
    float4 xx = x*x;
    return xx * xx * x;
}

float Pow6( float x )
{
    float xx = x*x;
    return xx * xx * xx;
}

float2 Pow6( float2 x )
{
    float2 xx = x*x;
    return xx * xx * xx;
}

float3 Pow6( float3 x )
{
    float3 xx = x*x;
    return xx * xx * xx;
}

float4 Pow6( float4 x )
{
    float4 xx = x*x;
    return xx * xx * xx;
}
// for velocity rendering, motionblur and temporal AA
// velocity needs to support -2..2 screen space range for x and y
// texture is 16bit 0..1 range per channel
float2 EncodeVelocityToTexture(float2 In)
{
    // 0.499f is a value smaller than 0.5f to avoid using the full range to use the clear color (0,0) as special value
    // 0.5f to allow for a range of -2..2 instead of -1..1 for really fast motions for temporal AA
    return In * (0.499f * 0.5f) + 32767.0f / 65535.0f;
}

// see EncodeVelocityToTexture()
float2 DecodeVelocityFromTexture(float2 In)
{
    const float InvDiv = 1.0f / (0.499f * 0.5f);
    // reference
    //	return (In - 32767.0f / 65535.0f ) / (0.499f * 0.5f);
    // MAD layout to help compiler
    return (In  - 32767.0f / 65535.0f) * InvDiv;
}

#endif //QSSHADER_FunctionLib_H