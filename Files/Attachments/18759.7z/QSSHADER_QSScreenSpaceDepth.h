#ifndef QSSHADER_QSScreenSpaceDepth_H
#define QSSHADER_QSScreenSpaceDepth_H
#include "DX12Defines.fxh"
#include "QSConstant.fxh"
#include "FunctionLib.fxh"

Texture2D DepthSampler;
float4 DepthParam;//x--near*far, y--far, z--far-near  w--near
float4 ProjParam;//x--w==tan(fovw/2), y--tan(fovh/2)
float4 FrustumParam; //x = near, y = far
float4x4 ScreenToPartialWorldTransform;
float4x4 invPartialViewProj;
float4x4 invView;

#define NearPlane			FrustumParam.x
#define FarPlane			FrustumParam.y
#define NearPlaneDeviceZ	FrustumParam.z
#define FarPlaneDeviceZ		FrustumParam.w

Texture2D<int2> StencilTexture;
float4 StencilResolution;
uint GetStencil(float2 uv)
{
	return StencilTexture.Load(int3(uv * StencilResolution.xy, 0)).g;
}
//calc viewspace z from screen space depth
float CalcViewZFromDeviceZ(float depth)
{
    return DepthParam.x / (DepthParam.y - depth*DepthParam.z);
}

float CalcViewZFromDeviceZ(float depth, float4 depthParam)
{
	return depthParam.x / (depthParam.y - depth * depthParam.z);
}

float CalcHomoZFromViewSpace(float depth)
{
    return DepthParam.y / DepthParam.z - DepthParam.x / (depth * DepthParam.z);
}

float3 GetViewPosFromViewZ(float2 uv, float viewSpaceZ)
{
	float3 viewPos;
	viewPos.y = viewSpaceZ;
	viewPos.x = (uv.x * 2 - 1) * viewSpaceZ * ProjParam.x;
	viewPos.z = -(uv.y * 2 - 1) * viewSpaceZ * ProjParam.y;
	return viewPos;
}

float3 GetWorldPosFromViewZ(float2 uv, float viewSpaceZ)
{
	float4 viewPos;
	viewPos.xyz = GetViewPosFromViewZ(uv, viewSpaceZ);
	viewPos.w = 1;
	return mul(viewPos, invView);
}

float3 GetPartialWorldPosFromScreenPos(float4 screenPos)
{
	float4 partialPos = mul(screenPos, invPartialViewProj);
	return partialPos.xyz / partialPos.w;
}

float3 GetPartialWorldPosFromDeviceZ(float2 uv, float deviceZ)
{
	float4 partialWorldPos = mul(float4(uv, deviceZ, 1.0f), ScreenToPartialWorldTransform);
	return partialWorldPos.xyz / partialWorldPos.w;
}


//-------------------------------------------

float GetDeviceZ(float2 uv)
{
	return DepthSampler.SampleLevel(NoMipMapPointClamp, uv, 0).r;	
}

float GetDeviceZ(float2 uv, Texture2D depthSampler)
{
	return depthSampler.SampleLevel(NoMipMapPointClamp, uv, 0).r;
}

float GetViewZFromScreenUv(float2 uv)
{
	float screenSpaceZ = GetDeviceZ(uv);
	return CalcViewZFromDeviceZ(screenSpaceZ);
}

float GetViewZFromScreenUv(float2 uv, Texture2D depthSampler)
{
	float screenSpaceZ = GetDeviceZ(uv, depthSampler);
	return CalcViewZFromDeviceZ(screenSpaceZ);
}

float3 GetViewPosFromScreenUv(float2 uv)
{
	return GetViewPosFromViewZ(uv, GetViewZFromScreenUv(uv));
}

float3 GetWorldPosFromScreenUv(float2 uv)
{
	float deviceZ = GetDeviceZ(uv);
	float4 partialWorldPos = mul(float4(uv, deviceZ, 1.0f), ScreenToPartialWorldTransform);
	return partialWorldPos.xyz / partialWorldPos.w + cameraPos;
}

float3 GetWorldPosFromScreenUv(float2 uv, Texture2D depthSampler)
{
	float deviceZ = GetDeviceZ(uv, depthSampler);
	float4 partialWorldPos = mul(float4(uv, deviceZ, 1.0f), ScreenToPartialWorldTransform);
	return partialWorldPos.xyz / partialWorldPos.w + cameraPos;
}

float DepthSoftenEdge(float2 uv, float viewDepth, float edge)
{
	float sceneViewDepth = GetViewZFromScreenUv(uv);
	return saturate(abs(viewDepth-sceneViewDepth)*edge*0.01f);
}

#endif //QSSHADER_QSScreenSpaceDepth_H
