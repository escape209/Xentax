#ifndef QSSHADER_QSEmissive_H
#define QSSHADER_QSEmissive_H

/*
*   full lighting       normal mapping, shadowing
*   normal map 			if disable, will disable specular lighting too
*   shadow              depth only, possible with alpha test
*/
struct VSIn
{
	half4 pos:             		POSITION;

#if ALPHATEST||LIGHTING||EMISSIVE
	float2 uv0:						TEXCOORD0;    //alpha test always enable for current
#if SECOND_UV&&EMISSIVE
	float2 uv1:					TEXCOORD1;	//second UV for emissive
#endif//SECOND_UV
#endif//ALPHATEST||LIGHTING||EMISSIVE


#if SKINNING
#if VERTEX_COMPRESSION
	int4   blendWeight :    BLENDWEIGHT;
#else
	float3 blendWeight :    BLENDWEIGHT;
#endif//VERTEX_COMPRESSION
	int4   blendIndices:    	BLENDINDICES;
#endif//SKINNING

#if LIGHTING
#if VERTEX_COMPRESSION
#if QTANGENTS
	int4 qtangents:           TANGENT;
#else
	#if HAS_NORMAL
		int4 normal:          NORMAL;
	#endif//HAS_NORMAL
	#if NORMALMAP//non simplify case, with normal mapping
		int4 binormal:        BINORMAL;
		int4 tangent:         TANGENT;
	#endif//NORMALMAP
#endif
#else
	float3 normal:				NORMAL;
#if NORMALMAP//non simplify case, with normal mapping
	float3 binormal:        BINORMAL;
	float3 tangent:         TANGENT;
#endif//NORMALMAP
#endif//VERTEX_COMPRESSION
#endif//LIGHTING			
};



struct VSOut
{
	float4 pos  :		POSITION;
#if ALPHATEST||LIGHTING||EMISSIVE
#if EMISSIVE&&SECOND_UV
	float4 uv0:		TEXCOORD0;
#else
	float2 uv0 :		TEXCOORD0;
#endif
#endif//ALPHATEST||LIGHTING||EMISSIVE

#if LIGHTING

	float3 normal :     TEXCOORD1;

#if NORMALMAP//when disable normal mapping, disable specular too, not very necessary to take specular when no normal mapping
	float3 tangent :    TEXCOORD2;    //normal mapping
	float3 binormal :   TEXCOORD3;    //normal mapping        
#endif//NORMALMAP
#if FORWARD_LIGHTING
	float4 projPos : TEXCOORD4;
#endif

#if WRITE_VELOCITY
	float4 curPos : TEXCOORD5;
	float4 prePos : TEXCOORD6;
#endif

#if SNOW_ACCUMULATION
	float3 objNormal : TEXCOORD7;
	float3 objPos : TEXCOORD8;
#endif

#else
#if DEPTH_COLOR
	float2  homoDepth	: TEXCOORD5;
#endif
#endif//LIGHTING
};

#endif //QSSHADER_QSEmissive_H
