#ifndef QSSHADER_INDIRECT_MORPH_H
#define QSSHADER_INDIRECT_MORPH_H

#if INDIRECT_EXECUTE

sampler2D LodMap;

float GetLodSampleDir(float v)
{
	if(v==0.0f)
	{
		return -1.0f;
	}
	if(v==1.0f)
	{
		return 1.0f;
	}
	return 0.0f;
}

bool EuqalEpsilon(float a, float b)
{
	return abs(a-b)<0.00001f;
}
 
 float2 MorphLodPos(float2 pos, float2 uv, float lodBase, float2 terrainMultiplier, float gridNum) 
{
	//dir
	bool edge = pos.x==0.0f || pos.y==0.0f || pos.x==1.0f || pos.y==1.0f;
	float2 result = pos;
	float curLod = tex2Dlod(LodMap, NoMipMapPointClamp, float4(uv,0,0));

	float lodRatio = saturate(curLod - lodBase);//0 is current, 1 is next lod

	if(edge)
	{
		float2 biasDir;
		biasDir.x = GetLodSampleDir(pos.x);
		biasDir.y = GetLodSampleDir(pos.y);
		
		float2 neighborUv = uv + biasDir * terrainMultiplier;
		float neighborLod = tex2Dlod(LodMap, NoMipMapPointClamp, float4(neighborUv,0,0));
		if(EuqalEpsilon(floor(neighborLod)-1.0f,lodBase))
		{
			 lodRatio = 1.0f;
		}
		else
		{
			 lodRatio = 0.0f;
		}
	}
	else
	{
		// lodRatio = 0.0f;//for debug edge
	}

	{
		int2 uvLod = floor(pos*gridNum);
		if(uvLod.x%2==1)
		{
			if(((uvLod.x-1)/2)%2==0)
			{				
				result.x -= lodRatio/gridNum;
			}
			else
			{
				result.x += lodRatio/gridNum;
			}
		}

		if(uvLod.y%2==1)
		{

			if(((uvLod.y-1)/2)%2==0)
			{
				result.y -= lodRatio/gridNum;
			}
			else
			{
				result.y += lodRatio/gridNum;
			}
		}
		return result;
	}

	return result;
}

#endif

#endif//QSSHADER_INDIRECT_MORPH_H