#ifndef QSSHADER_DynamicGI_H
#define QSSHADER_DynamicGI_H

#include "DX12Defines.fxh"

//consts
sampler2D IrradianceVolumeRtBig;//logically 4D, linear sampling

float4 IrrVolRTParam;//w, h, 1/w, 1/h
float4 IrrVolLogicalParam;//IV_XY, IV_XY, IV_Z, PROBE_DIR_COUNT
float4 IrrVolOffset0;//pos.xyz, group
float4 IrrVolInvGridSize0;//1.0f / grid size in xyz, 0
float4 IrrVolOffset;//pos.xyz, group

static const float4 RadianceDir[6] = 
{
    float4(1.0f, 0.0f, 0.0f, 1.0f),
    float4(-1.0f, 0.0f, 0.0f, 2.0f),
    float4(0.0f, 1.0f, 0.0f, 3.0f),
    float4(0.0f, -1.0f, 0.0f, 4.0f),
    float4(0.0f, 0.0f, 1.0f, 5.0f),
    float4(0.0f, 0.0f, -1.0f, 6.0f)
};

float4 AmbientLight(const float3 worldNormal, float4 cAmbientCube[6])
{
	float3 nSquared = worldNormal * worldNormal;
	int3 isNegative = ( worldNormal < 0.0 );
	float4 linearColor;
	linearColor = nSquared.x * cAmbientCube[isNegative.x] +
		nSquared.y * cAmbientCube[isNegative.y+2] +
		nSquared.z * cAmbientCube[isNegative.z+4];
	return linearColor;
} 

// Irradiance Volume 4D layout
// [S] -> (128 x 128)
//
// unwrap
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...x 32 a row
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...
// [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S] [S]...
// 6 rows, each for a direction of probe
float GetIrradianceCube(float3 position, out float4 cAmbientCube[6])
{
	float3 deltaPos0 = position - IrrVolOffset0.xyz;
	deltaPos0 *= IrrVolInvGridSize0.xyz;//cm to meter
	deltaPos0 /= IrrVolLogicalParam.xyz;

	float3 clampPosIV0 = saturate(deltaPos0);

	bool outside0 = any(deltaPos0 > clampPosIV0) || any(deltaPos0 < 0);//!=deltaPos0?

	if (outside0)
	{
		return 0.0f;
	}
	else
	{
		//return float4(1.0, 0, 0, 1);
		//return float4(deltaPos0,1);
	}

	float3 clampPosIV = clampPosIV0;

	float3 gridID0 = clampPosIV;//{[0,1), [0,1), [0,1)}

	//return float4(gridID0,1);

	gridID0.xy /= IrrVolLogicalParam.zw;

	gridID0.z *= IrrVolLogicalParam.z;
	float clampPosIVLerpZ = frac(gridID0.z);
	gridID0.z -= clampPosIVLerpZ;
	
	float groupOffset = IrrVolOffset0.w * 0.5f;

	//opt : 3 basis is ok
	for (int i = 0; i < 6; ++i)
	{
		float2 uv2d = gridID0.xy;		
		uv2d.x += gridID0.z / IrrVolLogicalParam.z;
		uv2d.y += (float)i / IrrVolLogicalParam.w;

		//with group
		uv2d.y = uv2d.y * 0.5f + groupOffset;
		uv2d.xy += 0.5f * IrrVolRTParam.zw;

		float4 irr0 = tex2Dlod(IrradianceVolumeRtBig, MipMapLinearClamp, float4(uv2d, 0, 1));

		uv2d.x += 1.0f / IrrVolLogicalParam.z;

		float4 irr1 = tex2Dlod(IrradianceVolumeRtBig, MipMapLinearClamp, float4(uv2d, 0, 1));

		float4 irrLerp = lerp(irr0, irr1, clampPosIVLerpZ);
		cAmbientCube[i] = irrLerp;
	}

	return 1.0f;
}

float4 GetRadiance(float3 position, float3 normal, float group)
{
	float3 deltaPos0 = position - IrrVolOffset0.xyz;
	deltaPos0 *= IrrVolInvGridSize0.xyz;//cm to meter
	deltaPos0 /= IrrVolLogicalParam.xyz;

	float3 clampPosIV0 = saturate(deltaPos0);

	bool outside0 = any(deltaPos0 > clampPosIV0) || any(deltaPos0 < 0);//!=deltaPos0?

	if (outside0)
	{
		return 0.0f;
	}

	float3 clampPosIV = clampPosIV0;

	float3 gridID0 = clampPosIV;//{[0,1), [0,1), [0,1)}

	//return float4(gridID0,1);

	gridID0.xy /= IrrVolLogicalParam.zw;

	gridID0.z *= IrrVolLogicalParam.z;
	float clampPosIVLerpZ = frac(gridID0.z);
	gridID0.z -= clampPosIVLerpZ;

	float groupOffset = group * 0.5f;
	//3 basis is ok
	float3 nSquared = normal * normal;
	int3 isNegative = ( normal < 0.0 );

	float4 vIrBasis[3];
	float basicIDs[3];
	basicIDs[0] = isNegative.x;
	basicIDs[1] = isNegative.y + 2;
	basicIDs[2] = isNegative.z + 4;

	for (int i = 0; i < 3; ++i)
	{
		float2 uv2d = gridID0.xy;		
		uv2d.x += gridID0.z / IrrVolLogicalParam.z;
		uv2d.y += (float)basicIDs[i] / IrrVolLogicalParam.w;

		//with group
		uv2d.y = uv2d.y * 0.5f + groupOffset;
		uv2d.xy += 0.5f * IrrVolRTParam.zw;

		float4 irr0 = tex2Dlod(IrradianceVolumeRtBig, MipMapLinearClamp, float4(uv2d, 0, 1));

		uv2d.x += 1.0f / IrrVolLogicalParam.z;

		float4 irr1 = tex2Dlod(IrradianceVolumeRtBig, MipMapLinearClamp, float4(uv2d, 0, 1));

		float4 irrLerp = lerp(irr0, irr1, clampPosIVLerpZ);
		vIrBasis[i] = irrLerp;
	}

	float4 linearColor;
	linearColor = nSquared.x * vIrBasis[0] + nSquared.y * vIrBasis[1] + nSquared.z * vIrBasis[2];

	return linearColor;
}

float4 GetDynamicGI(float3 position, float3 normal)
{
	float4 result = 0;
	result = GetRadiance(position, normal, IrrVolOffset0.w);
	return result;
}

float4 GetDynamicGIForward(float3 position, float3 normal, float outdoorScaling, float indoorScaling)
{	
	float4 result0 = GetRadiance(position, normal, 0);//outdoor
	result0.rgb *= outdoorScaling;
	float4 result1 = GetRadiance(position, normal, 1);//indoor
	result1.rgb *= indoorScaling;
	//float4 result = (result0.a > result1.a) ? result0 : result1;
	float4 result = 0;
	result.rgba = (result0.rgba * result0.a + result1.rgba * result1.a) / (result0.a + result1.a + 0.001f);
	return result;
}

void GetDynamicGI2(out float4 diffuse, out float4 specularAppx, float3 position, float3 normal, float3 normal2)
{
	float4 cAmbientCube[6];
	float weight = GetIrradianceCube(position, cAmbientCube);
	diffuse = AmbientLight(normal, cAmbientCube);
	specularAppx = AmbientLight(normal2, cAmbientCube);	
}

//attribute abstract from surfel data
float3 GetDiffuseFromSuffelPackData(float packData)
{
    float3 diffuse = 0;
    diffuse.z = frac(packData);
    float remain = (packData - diffuse.z) * 0.01f;
    diffuse.y = frac(remain);
    diffuse.x = (remain - diffuse.y) * 0.01f;

    return diffuse;
}

float3 GetPosFromSurfelData(float4 surfelData)
{
    return surfelData.xyz;
}

float GetBlendingFactor(float3 worldPos)//inside IV:0.0f, outside IV:1.0f
{
	/*float3 deltaPos0 = worldPos.xyz - IrrVolOffset0.xyz;
	deltaPos0 *= IrrVolInvGridSize0.xyz;
	deltaPos0 /= IrrVolLogicalParam.xyz;
	deltaPos0 -= 0.5f;//relative iv center
	float lengthInUnitBox = length(deltaPos0);
	float distScaling = (lengthInUnitBox - 0.5f) / 0.01f;
	distScaling = saturate(distScaling);*/

	float3 viewVec = worldPos.xyz - cameraPos.xyz;
	float viewDist2D = length(viewVec.xy);
	const float distGI = 12800.0f;
	const float distBlend = 400.0f;
	float distScaling1 = (viewDist2D - distGI) / distBlend;
	distScaling1 = saturate(distScaling1);

	return distScaling1;
}
#endif //QSSHADER_DynamicGI_H