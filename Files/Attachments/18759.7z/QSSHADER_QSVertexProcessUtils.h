#ifndef QSSHADER_QSVertexProcessUtils_H
#define QSSHADER_QSVertexProcessUtils_H


/////////////////////////////////////////////////////////////////////////////////////////////////////////
// QSVertexCalc.h(191)
void VertexTransformCalc_Skinning(float3 pos, float3 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
    float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);

    skinnedPos = mul(float4(pos, 1.0f), SkinBoneTransform);
    dir0 = mul(dir0, (float3x3)SkinBoneTransform);
    dir1 = mul(dir1, (float3x3)SkinBoneTransform);
    dir2 = mul(dir2, (float3x3)SkinBoneTransform);
}

// QSVertexCalc.h(337)
void VertexTransformCalc_Skinning(float3 pos, int4 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
    float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);

    skinnedPos = mul(float4(pos, 1.0f), SkinBoneTransform);
    dir0 = mul(dir0, (float3x3)SkinBoneTransform);
    dir1 = mul(dir1, (float3x3)SkinBoneTransform);
    dir2 = mul(dir2, (float3x3)SkinBoneTransform);
}

void VertexTransformCalc_Transform(float3 skinnedPos, float4x4 worldTrans, float4x4 mvpTrans, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
    homoPos = mul(float4(skinnedPos, 1.0f), mvpTrans);
    worldPos = mul(float4(skinnedPos, 1.0f), worldTrans);

    dir0 = mul(dir0, (float3x3)worldTrans);
    dir1 = mul(dir1, (float3x3)worldTrans);
    dir2 = mul(dir2, (float3x3)worldTrans);
}

// QSVertexCalc.h(58)
void VertexTransformCalc_Skinning(float3 pos, float3 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedPos)
{
    float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);
    skinnedPos = float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f);
}

// QSVertexCalc.h(253)
void VertexTransformCalc_Skinning(float3 pos, int4 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedPos)
{
    float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);
    skinnedPos = float4(mul(float4(pos.xyz, 1.0f), SkinBoneTransform), 1.0f);
}

void VertexTransformCalc_Transform(float3 skinnedPos, float4x4 mvpTrans, out float4 homoPos)
{
    homoPos = mul(float4(skinnedPos, 1.0f), mvpTrans);
}

// QSVertexCalc.h(67)
void VertexTransformCalc_Skinning(float3 pos, float3 blendWeight, int4 blendIndices, float2 boneUv, float2 preBoneUv, out float3 skinnedPos, out float3 skinnedCurPos, out float3 skinnedPrePos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);
	skinnedPos = mul(float4(pos, 1.0f), SkinBoneTransform);
	skinnedCurPos = skinnedPos;

	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices, preBoneUv);
	skinnedPrePos = mul(float4(pos, 1.0f), SkinBoneTransform);
}

// QSVertexCalc.h(263)
void VertexTransformCalc_Skinning(float3 pos, int4 blendWeight, int4 blendIndices, float2 boneUv, float2 preBoneUv, out float3 skinnedPos, out float3 skinnedCurPos, out float3 skinnedPrePos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);
	skinnedPos = mul(float4(pos.xyz, 1.0f), SkinBoneTransform);
	skinnedCurPos = skinnedPos;

	SkinBoneTransform = PreSkinMatrixCalcCompressed(blendWeight, blendIndices, preBoneUv);
	skinnedPrePos = mul(float4(pos, 1.0f), SkinBoneTransform);
}

void VertexTransformCalc_Transform(float3 skinnedPos, float3 skinnedCurPos, float3 skinnedPrePos, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos)
{
	homoPos = mul(float4(skinnedPos, 1.0f), mvpTrans);
	curPos = mul(float4(skinnedCurPos, 1.0f), curMvpTrans);
	prePos = mul(float4(skinnedPrePos, 1.0f), preMvpTrans);
}

void VertexTransformCalc_Transform(float3 skinnedPos, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos)
{
	homoPos = mul(float4(skinnedPos, 1.0f), mvpTrans);
	curPos = mul(float4(skinnedPos, 1.0f), curMvpTrans);
	prePos = mul(float4(skinnedPos, 1.0f), preMvpTrans);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////

void VertexTransformCalc_SkinningDir(float3 dir, float3 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedDir)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);
	skinnedDir = mul(dir, (float3x3)SkinBoneTransform);
}

void VertexTransformCalc_SkinningDir(float3 dir, int4 blendWeight, int4 blendIndices, float2 boneUv, out float3 skinnedDir)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);
	skinnedDir = mul(dir, (float3x3)SkinBoneTransform);
}

void VertexTransformCalc_Skinning(float3 pos, float3 blendWeight, int4 blendIndices, float2 boneUv, float2 preBoneUv, out float3 skinnedPos, out float3 skinnedCurPos, out float3 skinnedPrePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);

	skinnedPos = float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f);
	skinnedCurPos = skinnedPos;

	dir0 = mul(dir0, (float3x3)SkinBoneTransform);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform);

	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices, preBoneUv);
	skinnedPrePos = float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f);
}

void VertexTransformCalc_Skinning(float3 pos, int4 blendWeight, int4 blendIndices, float2 boneUv, float2 preBoneUv, out float3 skinnedPos, out float3 skinnedCurPos, out float3 skinnedPrePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);

	skinnedPos = float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f);
	skinnedCurPos = skinnedPos;

	dir0 = mul(dir0, (float3x3)SkinBoneTransform);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform);

	SkinBoneTransform = PreSkinMatrixCalcCompressed(blendWeight, blendIndices, preBoneUv);
	skinnedPrePos = float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f);
}

void VertexTransformCalc_Transform(float3 skinnedPos, float3 skinnedCurPos, float3 skinnedPrePos, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	homoPos = mul(float4(skinnedPos, 1.0f), mvpTrans);
	curPos = mul(float4(skinnedCurPos, 1.0f), curMvpTrans);
	prePos = mul(float4(skinnedPrePos, 1.0f), preMvpTrans);

	dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)worldTrans);
}


#endif // QSSHADER_QSVertexProcessUtils_H