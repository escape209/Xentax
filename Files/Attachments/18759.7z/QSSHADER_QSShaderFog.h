#ifndef QSSHADER_QSShaderFog_H
#define QSSHADER_QSShaderFog_H

#include "Zfade.h"

/*
 *	atmosphere param&impl
 */
float4 HeightFalloff;
float4 Greenstein;  // 1-g^2, 1+g^2, 2*g,Gamma
float3 BetaRay;
float4 BetaMie;
//float3 DashRay;
float3 DashMie;
float3 LightDir;
float3 LightColor;
float4 HeightFogColor;
float4 FogData;
#if DOUBLE_LIGHTING
//float3 DashRaySecond;
float3 DashMieSecond;
float3 LightDirSecond;
float3 LightColorSecond;
#endif

float4 ZFadeRange; //x zfadrragne, y invFadeRange*invFadeRange, z: zfaderange start square, w: precision factor

sampler2D FogSkyColorSampler;
sampler2D FogSkyBackGroundSampler;

#define FogStartDistance BetaMie.w
#define HeightFogDensity HeightFalloff.w
#define FogColor  FogData.xyz
#define AffectSky FogData.w

float3 CalcExtinction(float distance, float height)
{
    float3 falloff = HeightFalloff.xyz * height;
    float3 density = 1;
    if(falloff.x != 0.0f) 
    {
        density *= (1.0 - exp(-falloff)) / falloff;
    }
    return exp(-((BetaRay.xyz * density.x + BetaMie.xyz * density.y) * FogColor + clamp(HeightFogDensity * density.z, 0, HeightFogColor.a * 4e-5) * HeightFogColor.rgb) * distance);	
}

float3 CalcExtinctionSky(float distance, float height, float affectSky)
{
	float2 falloff = HeightFalloff.xy * height;
	float2 density = 1;
	if(falloff.x != 0.0f) 
	{
		density *= (1.0 - exp(-falloff)) / falloff;
	}
	return exp(-((BetaRay.xyz * density.x + BetaMie.xyz * density.y) * (FogColor * affectSky + 1 - affectSky) + (clamp(HeightFogDensity * density.y, 0, HeightFogColor.a * 4e-5) * affectSky) * HeightFogColor.rgb) * distance);	
}

float3 CalcExtinctionSky(float distance, float height)
{
	return CalcExtinctionSky(distance, height, AffectSky);	
}

// ɢ�������ͼ�ó�, ����Ϊ�����ɫ
float3 GetInscattering(float2 screenUv)
{
    return tex2D(FogSkyColorSampler, screenUv);
}

float CalcHenyeyGreenstein(float VdotL)
{
	return Greenstein.x / pow(Greenstein.y - Greenstein.z * VdotL, 1.5);
};
float3 GetMieInscattering(float3 viewDir)
{
    float angle = -dot(viewDir, LightDir);
    float mie_phase = CalcHenyeyGreenstein(angle);
    float3 inscattering = DashMie * mie_phase;	

#if DOUBLE_LIGHTING
    angle = -dot(viewDir, LightDirSecond);
    mie_phase = CalcHenyeyGreenstein(angle);
    inscattering += DashMieSecond * mie_phase;
#endif
    return inscattering;
}

float3 GetMieScatteringSky(float3 viewDir, float distance)
{
    float3 extinction = CalcExtinctionSky(distance, viewDir.z * distance, 1);
    float3 inscattering = GetMieInscattering(viewDir) + HeightFogColor.rgb * (10000 * HeightFogDensity * HeightFogColor.a);
    inscattering = inscattering - inscattering * extinction;
    return inscattering;
}

void ApplyFog(inout float3 srcColor, float3 viewDir, float distance, float2 ssUv)
{
	float heightToCam = viewDir.z * distance;
#if !SKY_PASS
	distance = clamp(distance - FogStartDistance, 0, 1e6);
#endif
    float3 extinction = CalcExtinction(distance, heightToCam);
    float3 rayInscattering = GetInscattering(ssUv);
    srcColor = lerp(rayInscattering, srcColor, extinction);
}

void ApplyFog(inout float3 srcColor, float3 toCamera, float2 ssUv)
{
    float distance = length(toCamera);
    float3 viewDir = toCamera * (1.0f / distance);
    ApplyFog(srcColor, viewDir, distance, ssUv);
}

void ApplyFogWithZFade(inout float4 srcColor, float3 toCamera, float2 ssUv)
{
    ApplyFog(srcColor.rgb, toCamera, ssUv);
    float distSqr = dot(toCamera, toCamera);
#if ZFADEBACKGRD
	float zfadeRatio = 1 - CalcZFadeRatio(ZFadeRange.y, ZFadeRange.z, distSqr);
	float4 bkgrd = tex2D(FogSkyColorSampler, ssUv);
	srcColor.rgb = lerp(bkgrd.rgb, srcColor.rgb, zfadeRatio);
#else
    float zfadeRatio = 1 - CalcZFadeRatio(ZFadeRange.y, ZFadeRange.z, distSqr);	
    srcColor.a *= zfadeRatio;	
#endif
}

/*
float3 CalcMieExtinction(float distance, float height)
{
    float falloff = HeightFalloff.x * height;
    float density = falloff == 0? 1 : (1.0 - exp(-falloff)) / falloff;
    return exp(-BetaMie.xyz * (density * distance));	
}

float3 CalcRayExtinction(float distance, float height)
{
    float falloff = HeightFalloff.x * height;
    float density = falloff == 0? 1 : (1.0 - exp(-falloff)) / falloff;
    return exp(-BetaRay.xyz * (density * distance));	
}

// ����rayɢ���������ó�
float3 CalcInscattering(float3 viewDir)
{
    float angle = -dot(viewDir, LightDir);
    float ray_phase = 1.0 + angle * angle;
    float mie_phase = CalcHenyeyGreenstein(angle);
    float3 inscattering = DashRay * ray_phase + DashMie * mie_phase;	

#if DOUBLE_LIGHTING
    angle = -dot(viewDir, LightDirSecond);
    ray_phase = 1.0 + angle * angle;
    mie_phase = CalcHenyeyGreenstein(angle);
    inscattering += DashRaySecond * ray_phase + DashMieSecond * mie_phase;
#endif
    return inscattering;
}
*/

#endif//QSSHADER_QSShaderFog_H
