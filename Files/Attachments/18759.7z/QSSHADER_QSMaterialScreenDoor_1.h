#ifndef QSSHADER_QSMaterialScreenDoor_H
#define QSSHADER_QSMaterialScreenDoor_H
//material deoraction impl, screen door
//use macro of SCREEN_DOOR
sampler2D NoiseTex;

void ScreenDoor(float2 uv)
{
#if SCREEN_DOOR
    float randValue = tex2D(NoiseTex, uv).r;
    clip(TransFactor - randValue / 2.0f);
#endif
}



#endif//QSSHADER_QSMaterialScreenDoor_H