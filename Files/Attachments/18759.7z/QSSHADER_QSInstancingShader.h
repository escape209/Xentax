#ifndef QSSHADER_QSInstancingShader_H
#define QSSHADER_QSInstancingShader_H
#include "DX12Defines.fxh"
#ifndef WORLD_MATRIX
float4x4 worldMatrix;
#define WORLD_MATRIX
#endif
#ifndef PARTIAL_VIEW_PROJ
#define PARTIAL_VIEW_PROJ
float4x4 PartialViewProj;
#endif

#ifndef WORLD_VIEW_PROJ
#define WORLD_VIEW_PROJ
float4x4 worldViewProj;
#endif

struct VsInInstancing
{
#if SKINNING
	float2 boneTexUv			: TEXCOORD12;
#endif
	float4 worldMatrix0			: TEXCOORD13;
	float4 worldMatrix1			: TEXCOORD14;
	float4 worldMatrix2			: TEXCOORD15;
};

//get world transform, mvp transform and 
#if INSTANCING

void GetTransformData(VsInInstancing instancingParam, float4x4 partialViewProj, out float4x4 worldTrans, out float4x4 mvpTrans, inout float2 boneUv)
{
	worldTrans = float4x4(
		float4(instancingParam.worldMatrix0.xyz, 0.0f), 
		float4(instancingParam.worldMatrix1.xyz, 0.0f), 
		float4(instancingParam.worldMatrix2.xyz, 0.0f),
		float4(instancingParam.worldMatrix0.w,instancingParam.worldMatrix1.w,instancingParam.worldMatrix2.w,1.0f));

	mvpTrans = float4x4(
		float4(instancingParam.worldMatrix0.xyz, 0.0f), 
		float4(instancingParam.worldMatrix1.xyz, 0.0f), 
		float4(instancingParam.worldMatrix2.xyz, 0.0f),
		float4(instancingParam.worldMatrix0.w-cameraPos.x,instancingParam.worldMatrix1.w-cameraPos.y,instancingParam.worldMatrix2.w-cameraPos.z,1.0f));
	mvpTrans = mul(mvpTrans, partialViewProj);	
#if SKINNING
	boneUv = instancingParam.boneTexUv;
#endif
}

void GetTransformData(VsInInstancing instancingParam, out float4x4 worldTrans, out float4x4 mvpTrans, inout float2 boneUv)
{
    GetTransformData(instancingParam, PartialViewProj, worldTrans, mvpTrans, boneUv);
}


#if WRITE_VELOCITY
void GetTransformData(VsInInstancing instancingParam, float4x4 partialViewProj, float4x4 curPartialViewProj, float4x4 prePartialViewProj, 
                      out float4x4 worldTrans, out float4x4 mvpTrans, out float4x4 curMvpTrans, out float4x4 preMvpTrans, inout float2 boneUv)
{
	worldTrans = float4x4(
		float4(instancingParam.worldMatrix0.xyz, 0.0f), 
		float4(instancingParam.worldMatrix1.xyz, 0.0f), 
		float4(instancingParam.worldMatrix2.xyz, 0.0f),
		float4(instancingParam.worldMatrix0.w,instancingParam.worldMatrix1.w,instancingParam.worldMatrix2.w,1.0f));

	float4x4 localMvpTrans = float4x4(
		float4(instancingParam.worldMatrix0.xyz, 0.0f), 
		float4(instancingParam.worldMatrix1.xyz, 0.0f), 
		float4(instancingParam.worldMatrix2.xyz, 0.0f),
		float4(instancingParam.worldMatrix0.w-cameraPos.x,instancingParam.worldMatrix1.w-cameraPos.y,instancingParam.worldMatrix2.w-cameraPos.z,1.0f));
	mvpTrans = mul(localMvpTrans, partialViewProj);
	curMvpTrans = mul(localMvpTrans, curPartialViewProj);
	preMvpTrans = mul(localMvpTrans, prePartialViewProj);
#if SKINNING
	boneUv = instancingParam.boneTexUv;
#endif
}

void GetTransformData(VsInInstancing instancingParam, out float4x4 worldTrans, out float4x4 mvpTrans, out float4x4 curMvpTrans, out float4x4 preMvpTrans, inout float2 boneUv)
{
    GetTransformData(instancingParam, PartialViewProj, curPartialViewProj, prePartialViewProj, worldTrans, mvpTrans, curMvpTrans, preMvpTrans, boneUv);
}
#endif //WRITE_VELOCITY

void GetTransformData(VsInInstancing instancingParam, out float4x4 worldTrans)
{
    worldTrans = float4x4(
        float4(instancingParam.worldMatrix0.xyz, 0.0f), 
        float4(instancingParam.worldMatrix1.xyz, 0.0f), 
        float4(instancingParam.worldMatrix2.xyz, 0.0f),
        float4(instancingParam.worldMatrix0.w,instancingParam.worldMatrix1.w,instancingParam.worldMatrix2.w,1.0f));
}

void GetMvpBoneData(VsInInstancing instancingParam, out float4x4 mvpTrans, inout float2 boneUv)
{
	mvpTrans = float4x4(
		float4(instancingParam.worldMatrix0.xyz, 0.0f), 
		float4(instancingParam.worldMatrix1.xyz, 0.0f), 
		float4(instancingParam.worldMatrix2.xyz, 0.0f),
		float4(instancingParam.worldMatrix0.w-cameraPos.x,instancingParam.worldMatrix1.w-cameraPos.y,instancingParam.worldMatrix2.w-cameraPos.z,1.0f));
	mvpTrans = mul(mvpTrans, PartialViewProj);	
#if SKINNING
	boneUv = instancingParam.boneTexUv;
#endif
}

#else

void GetTransformData(out float4x4 worldTrans, out float4x4 mvpTrans, inout float2 boneUv)
{
	worldTrans = worldMatrix;
	mvpTrans = worldViewProj;
#if SKINNING
	boneUv = BoneTexUv;
#endif
}

#if WRITE_VELOCITY
void GetTransformData(out float4x4 worldTrans, /*out float4x4 preWorldTrans, */out float4x4 mvpTrans, out float4x4 curMvpTrans, out float4x4 preMvpTrans, inout float2 boneUv, inout float2 preBoneUv)
{
	worldTrans = worldMatrix;
	//preWorldTrans = preWorldMatrix;
	mvpTrans = worldViewProj;
	curMvpTrans = curWorldViewProj;
	preMvpTrans = preWorldViewProj;
#if SKINNING
	boneUv = BoneTexUv.xy;
	preBoneUv = BoneTexUv.zw;
#endif
}
#endif //WRITE_VELOCITY

void GetMvpBoneData(out float4x4 mvpTrans, inout float2 boneUv)
{	
	mvpTrans = worldViewProj;
#if SKINNING
	boneUv = BoneTexUv;
#endif
}

#if WRITE_VELOCITY
void GetMvpBoneData(out float4x4 mvpTrans, out float4x4 curMvpTrans, out float4x4 preMvpTrans, inout float2 boneUv, inout float2 preBoneUv)
{	
	mvpTrans = worldViewProj;
	curMvpTrans = curWorldViewProj;
	preMvpTrans = preWorldViewProj;	
#if SKINNING
	boneUv = BoneTexUv.xy;
	preBoneUv = BoneTexUv.zw;
#endif
}
#endif //WRITE_VELOCITY

#endif


#endif//QSSHADER_QSInstancingShader_H