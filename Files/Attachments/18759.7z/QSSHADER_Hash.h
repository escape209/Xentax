//###############################################################################
// white noise function https://www.shadertoy.com/view/4djSRW
// hashNN param should be a integer position (e.g. pixel position on the screen)
// hashSinNN param should be small float (e.g. range[0f, 100f])
// hash return[0,1]; 

#ifndef QSSHADER_Hash_H
#define QSSHADER_Hash_H

#define HASHSCALE1 0.1031
#define HASHSCALE3 float3(0.1031, 0.1030, 0.0973)
#define HASHSCALE4 float4(1031, 0.1030, 0.0973, 0.1099)
//----------------------------------------------------------------------------------------
//  1 out, 1 in...
float hash11(float p)
{
    float3 p3  = frac(p * HASHSCALE1);
    p3 += dot(p3, p3.yzx + 19.19);
    return frac((p3.x + p3.y) * p3.z);
}

//----------------------------------------------------------------------------------------
//  1 out, 2 in...
float hash12(float2 p)
{
    float3 p3  = frac(p.xyx * HASHSCALE1);
    p3 += dot(p3, p3.yzx + 19.19);
    return frac((p3.x + p3.y) * p3.z);
}

//----------------------------------------------------------------------------------------
//  1 out, 3 in...
float hash13(float3 p3)
{
    p3  = frac(p3 * HASHSCALE1);
    p3 += dot(p3, p3.yzx + 19.19);
    return frac((p3.x + p3.y) * p3.z);
}

//----------------------------------------------------------------------------------------
//  2 out, 1 in...
float2 hash21(float p)
{
    float3 p3 = frac(p * HASHSCALE3);
    p3 += dot(p3, p3.yzx + 19.19);
    return frac(float2((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y));
}

//----------------------------------------------------------------------------------------
///  2 out, 2 in...
float2 hash22(float2 p)
{
    float3 p3 = frac(p.xyx * HASHSCALE3);
    p3 += dot(p3, p3.yzx+19.19);
    return frac(float2((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y));
}

//----------------------------------------------------------------------------------------
///  2 out, 3 in...
float2 hash23(float3 p3)
{
    p3 = frac(p3 * HASHSCALE3);
    p3 += dot(p3, p3.yzx+19.19);
    return frac(float2((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y));
}

//----------------------------------------------------------------------------------------
//  3 out, 1 in...
float3 hash31(float p)
{
    float3 p3 = frac(p * HASHSCALE3);
    p3 += dot(p3, p3.yzx+19.19);
    return frac(float3((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y, (p3.y+p3.z)*p3.x));
}


//----------------------------------------------------------------------------------------
///  3 out, 2 in...
float3 hash32(float2 p)
{
    float3 p3 = frac(p.xyx * HASHSCALE3);
    p3 += dot(p3, p3.yxz+19.19);
    return frac(float3((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y, (p3.y+p3.z)*p3.x));
}
//----------------------------------------------------------------------------------------
///  3 out, 3 in...
float3 hash33(float3 p3)
{
    p3 = frac(p3 * HASHSCALE3);
    p3 += dot(p3, p3.yxz+19.19);
    return frac(float3((p3.x + p3.y)*p3.z, (p3.x+p3.z)*p3.y, (p3.y+p3.z)*p3.x));
}

//----------------------------------------------------------------------------------------
// 4 out, 1 in...
float4 hash41(float p)
{
    float4 p4 = frac(p * HASHSCALE4);
    p4 += dot(p4, p4.wzxy+19.19);
    return frac(float4((p4.x + p4.y)*p4.z, (p4.x + p4.z)*p4.y, (p4.y + p4.z)*p4.w, (p4.z + p4.w)*p4.x));

}

//----------------------------------------------------------------------------------------
// 4 out, 2 in...
float4 hash42(float2 p)
{
    float4 p4 = frac(float4(p.xyxy) * HASHSCALE4);
    p4 += dot(p4, p4.wzxy+19.19);
    return frac(float4((p4.x + p4.y)*p4.z, (p4.x + p4.z)*p4.y, (p4.y + p4.z)*p4.w, (p4.z + p4.w)*p4.x));
}

//----------------------------------------------------------------------------------------
// 4 out, 3 in...
float4 hash43(float3 p)
{
    float4 p4 = frac(float4(p.xyzx)  * HASHSCALE4);
    p4 += dot(p4, p4.wzxy+19.19);
    return frac(float4((p4.x + p4.y)*p4.z, (p4.x + p4.z)*p4.y, (p4.y + p4.z)*p4.w, (p4.z + p4.w)*p4.x));
}

//----------------------------------------------------------------------------------------
// 4 out, 4 in...
float4 hash44(float4 p4)
{
    p4 = frac(p4  * HASHSCALE4);
    p4 += dot(p4, p4.wzxy+19.19);
    return frac(float4((p4.x + p4.y)*p4.z, (p4.x + p4.z)*p4.y, (p4.y + p4.z)*p4.w, (p4.z + p4.w)*p4.x));
}


//----------------------------------------------------------------------------------------
float hashSin11(float p)
{
	return frac(sin(p)*753.5453123);
}

float hashSin12(float2 p)
{
    // Two typical hashes...
    return frac(sin(dot(p, float2(12.9898, 78.233))) * 43758.5453);

    // This one is better, but it still stretches out quite quickly...
    // But it's really quite bad on my Mac(!)
    //return frac(sin(dot(p, float2(1.0,113.0)))*43758.5453123);

}

float3 hashSin33( float3 p )
{
    p = float3( dot(p,float3(127.1,311.7, 74.7)),
        dot(p,float3(269.5,183.3,246.1)),
        dot(p,float3(113.5,271.9,124.6)));

    return frac(sin(p)*43758.5453123);
}

#endif  //QSSHADER_Hash_H