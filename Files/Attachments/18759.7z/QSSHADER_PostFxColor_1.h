#ifndef QSSHADER_PostFxColor_H
#define QSSHADER_PostFxColor_H

float3 RgbToHsl(float3 c)
{
	float4 K = float4(0.0f, -1.0f / 3.0f, 2.0f / 3.0f, -1.0f);
	float4 p = lerp(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
	float4 q = lerp(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));

	float d = q.x - min(q.w, q.y);
	float e = 1.0e-10;
	return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

float3 HslToRgb(float3 c)
{
	float4 K = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	float3 p = abs(frac(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * lerp(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

float3 RgbShiftByHsl(float3 src, float3 hslShift)
{
	float3 hsl = RgbToHsl(src);
	hsl += hslShift;
	return HslToRgb(hsl);
}

float3 RgbShiftByHsl(float3 src, float3 hslShift, float mask)
{
	float3 hsl = RgbToHsl(src);
	hsl += hslShift;
	float3 shiftedRgb = HslToRgb(hsl);
	return lerp(src, shiftedRgb, mask);
}

float3 ColorGrading(sampler2D table, float3 src)
{
    // requires a volume texture 16x16x16 unwrapped in a 2d texture 256x16
    // can be optimized by using a volume texture
    float2 offset = float2(0.5f / 256.0f, 0.5f / 16.0f);
    float scale = 15.0f / 16.0f; 

    // Also consider blur value in the blur buffer written by translucency
    float intB = floor(src.b * 14.9999f) / 16.0f;
    float fracB = src.b * 15.0f - intB * 16.0f;

    float u = intB + src.r * scale / 16.0f;
    float v = src.g * scale;

    float3 color0 = tex2D(table, offset + float2(u,v)).rgb;
    float3 color1 = tex2D(table, offset + float2(u + 1.0f / 16.0f, v)).rgb;

    return lerp(color0, color1, fracB);
}

float GetLuminance(float3 color)
{
    const float3 lumWeight = float3(0.2125f, 0.7154f, 0.0721f);
    return dot(color, lumWeight);
}

#endif //QSSHADER_PostFxColor_H