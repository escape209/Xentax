#ifndef QSSHADER_Ocean_H
#define QSSHADER_Ocean_H

#define OceanWaveHeightMax 500.0f
float OceanBaseHeight;

#if INDIRECT_EXECUTE

cbuffer IndirectConst : register(b1)
{
     float2 OceanPos;
     float OceanScale;
	float  LODInfo;
 };

sampler2D QuadTreeLodMap;

float4 IndirectBaseInfo;
#define MinScale (IndirectBaseInfo.x)
#define GridNum (IndirectBaseInfo.y)
#define OceanSize (IndirectBaseInfo.z)

float SampleOceanLod(float2 offset, float scale)
{
     float2 centerPos = offset + scale * 0.5f;
	float2 curUv = centerPos / OceanSize;
	
	return tex2Dlod(QuadTreeLodMap, NoMipMapPointClamp, float4(curUv,0,0));
}

float CalcLodBase(float scale)
{
     return log2(OceanScale.x/MinScale);
}
#endif

#endif//QSSHADER_Ocean_H