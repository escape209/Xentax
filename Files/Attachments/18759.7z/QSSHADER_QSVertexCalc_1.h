#ifndef QSSHADER_QSVertexCalc_H
#define QSSHADER_QSVertexCalc_H

#include "QSSkinning.h"

float3 DecompressPos(float4 pos)
{
#if VERTEX_COMPRESSION
	return pos.xyz*pos.w;
#else
	return pos.xyz;
#endif
}

float3x3 GetLocalToWorldRotation()
{
	return (float3x3)worldMatrix;
}

float3x3 GetLocalToWorldRotation(float3x3 boneTransform)
{
	return mul(boneTransform,(float3x3)worldMatrix);	
}

#if SKINNING

float4x4 GetHomoTransform()
{
	return worldViewProj;
}

#if WRITE_VELOCITY
float4x4 GetCurHomoTransform()
{
	return curWorldViewProj;
}

float4x4 GetPreHomoTransform()
{
	return preWorldViewProj;
}
#endif

float3 CalcWorldPos(float4 skinnedPos)
{
	return mul(skinnedPos, worldMatrix);
}

void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, out float4 homoPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices);

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
	homoPos = mul(skinnedPos, GetHomoTransform());
}

//instancing version
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 mvpTrans, float2 boneUv, out float4 homoPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
	homoPos = mul(skinnedPos, mvpTrans);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
	homoPos = mul(skinnedPos, mvpTrans);
	curPos  = mul(skinnedPos, curMvpTrans);
	
	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices, preBoneUv);

	skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
	prePos     = mul(skinnedPos, preMvpTrans);
}
#endif

void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, GetHomoTransform());

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldMatrix);	
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, GetHomoTransform());
	curPos  = mul(skinnedPos, GetCurHomoTransform());

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldMatrix);	
	
	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices);
	skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);	
	prePos  = mul(skinnedPos, GetPreHomoTransform());
}
#endif

//instancing version
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float2 boneUv, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
}

void VertexTransformCalcForDestruct(float3 pos, float3 camPos, int blendIndice, float4x4 worldTrans, float4x4 partialViewProj, float2 boneUv, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = ReadBoneData(blendIndice, boneUv);

	float3 skinnedLocalPos = mul(float4(pos, 1.0f), SkinBoneTransform);
	float3 skinnedWorldPos = mul(float4(skinnedLocalPos, 1.0f), worldTrans).xyz;

	homoPos = mul(float4(skinnedWorldPos - camPos, 1.0f), partialViewProj);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);
	curPos = mul(skinnedPos, curMvpTrans);	

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);
	
	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices, preBoneUv);	
	skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	prePos = mul(skinnedPos, preMvpTrans);
}

void VertexTransformCalcForDestruct(float3 pos, float3 camPos, int blendIndice, float4x4 worldTrans, float4x4 partialViewProj, float4x4 curPartialViewProj, float4x4 prePartialViewProj, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = ReadBoneData(blendIndice, boneUv);

	float3 skinnedLocalPos = mul(float4(pos, 1.0f), SkinBoneTransform);
	float3 skinnedWorldPos = mul(float4(skinnedLocalPos, 1.0f), worldTrans).xyz;

	homoPos = mul(float4(skinnedWorldPos - camPos, 1.0f), partialViewProj);
	curPos = mul(float4(skinnedWorldPos - camPos, 1.0f), curPartialViewProj);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);

	SkinBoneTransform = ReadPreBoneData(blendIndice, preBoneUv);
	skinnedWorldPos = mul(float4(mul(float4(pos, 1.0f), SkinBoneTransform), 1.0f), worldTrans).xyz;
	prePos = mul(float4(skinnedWorldPos - camPos, 1.0f), prePartialViewProj);
}
#endif

void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, GetHomoTransform());
	worldPos = CalcWorldPos(skinnedPos);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldMatrix);	
}

void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float2 boneUv, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);
	worldPos = mul(skinnedPos, worldTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);
	worldPos = mul(skinnedPos, worldTrans);
	curPos = mul(skinnedPos, curMvpTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
	
	SkinBoneTransform = PreSkinMatrixCalc(blendWeight, blendIndices, preBoneUv);	
	skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
    prePos = mul(skinnedPos, preMvpTrans);	
}
#endif

void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, out float4 homoPos, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform),1.0f);		
	homoPos = mul(skinnedPos, GetHomoTransform());
	worldPos = CalcWorldPos(skinnedPos);
}

//instancing version
void VertexTransformCalc(float3 pos, float3 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans,  float2 boneUv, out float4 homoPos, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalc(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform),1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);
	worldPos = mul(skinnedPos, worldTrans);
}

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, out float4 homoPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);		

	homoPos = mul(skinnedPos, GetHomoTransform());
}

//instancing version
void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 mvpTrans, float2 boneUv, out float4 homoPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);		

	homoPos = mul(skinnedPos, mvpTrans);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	
	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);		
	homoPos = mul(skinnedPos, mvpTrans);
	curPos  = mul(skinnedPos, curMvpTrans);
	
	SkinBoneTransform = PreSkinMatrixCalcCompressed(blendWeight, blendIndices, preBoneUv);
	skinnedPos = float4(mul(float4(pos,1.0f), SkinBoneTransform), 1.0f);
	prePos     = mul(skinnedPos, preMvpTrans);
}
#endif

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos = mul(skinnedPos, GetHomoTransform());

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldMatrix);	
}

//instancing case, it must be bone uv
void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float2 boneUv, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos = mul(skinnedPos, mvpTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos = mul(skinnedPos, mvpTrans);
	curPos = mul(skinnedPos, curMvpTrans);	

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
	
    SkinBoneTransform = PreSkinMatrixCalcCompressed(blendWeight, blendIndices, preBoneUv);
	skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);		
	prePos = mul(skinnedPos, preMvpTrans);
}
#endif

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos = mul(skinnedPos, GetHomoTransform());
	worldPos = CalcWorldPos(skinnedPos);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldMatrix);	
}

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float2 boneUv, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos = mul(skinnedPos, mvpTrans);
	worldPos = mul(skinnedPos, worldTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, float2 boneUv, float2 preBoneUv, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	

	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);	

	homoPos  = mul(skinnedPos, mvpTrans);
	worldPos = mul(skinnedPos, worldTrans);
	curPos   = mul(skinnedPos, curMvpTrans);

	dir0 = mul(dir0, (float3x3)SkinBoneTransform); dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)SkinBoneTransform); dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)SkinBoneTransform); dir2 = mul(dir2, (float3x3)worldTrans);	
	
    SkinBoneTransform = PreSkinMatrixCalcCompressed(blendWeight, blendIndices, preBoneUv);
	skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform), 1.0f);		
	prePos = mul(skinnedPos, preMvpTrans);	
}
#endif

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, out float4 homoPos, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices);	
	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform),1.0f);		
	worldPos = CalcWorldPos(skinnedPos);
	homoPos = mul(skinnedPos, GetHomoTransform());
}

void VertexTransformCalc(float3 pos, int4 blendWeight, int4 blendIndices, float4x4 worldTrans, float4x4 mvpTrans, float2 boneUv, out float4 homoPos, out float3 worldPos)
{
	float4x3 SkinBoneTransform = SkinMatrixCalcCompressed(blendWeight, blendIndices, boneUv);	
	float4 skinnedPos = float4(mul(float4(pos.xyz,1.0f), SkinBoneTransform),1.0f);		
	worldPos = mul(skinnedPos, worldTrans);
	homoPos = mul(skinnedPos, mvpTrans);
}

#else

void VertexTransformCalc(float3 pos, out float4 homoPos)
{
	homoPos = mul(float4(pos,1.0f), worldViewProj);		
}

//instancing version
void VertexTransformCalc(float3 pos, float4x4 mvpTrans, out float4 homoPos)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);		
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);	
    curPos	= mul(float4(pos,1.0f), curMvpTrans);
	prePos  = mul(float4(pos,1.0f), preMvpTrans);
}
#endif

void VertexTransformCalc(float3 pos, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	homoPos = mul(float4(pos,1.0f), worldViewProj);

	dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)worldMatrix);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	homoPos = mul(float4(pos,1.0f), worldViewProj);

	dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)worldMatrix);
	
	curPos = mul(float4(pos,1.0f), curWorldViewProj);
	prePos = mul(float4(pos,1.0f), preWorldViewProj);
}
#endif

void VertexTransformCalc(float3 pos, float4x4 worldTrans, float4x4 mvpTrans, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);

	dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)worldTrans);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);
	curPos = mul(float4(pos,1.0f), curMvpTrans);
	prePos = mul(float4(pos,1.0f), preMvpTrans);

	dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)worldTrans);
}
#endif

void VertexTransformCalc(float3 pos, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	homoPos = mul(float4(pos,1.0f), worldViewProj);
	worldPos = mul(float4(pos,1.0f), worldMatrix); 

	dir0 = mul(dir0, (float3x3)worldMatrix);
	dir1 = mul(dir1, (float3x3)worldMatrix);
	dir2 = mul(dir2, (float3x3)worldMatrix);
}

void VertexTransformCalc(float3 pos, float4x4 worldTrans, float4x4 mvpTrans, out float4 homoPos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);
	worldPos = mul(float4(pos,1.0f), worldTrans); 

	dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)worldTrans);
}

#if WRITE_VELOCITY
void VertexTransformCalc(float3 pos, float4x4 worldTrans, float4x4 mvpTrans, float4x4 curMvpTrans, float4x4 preMvpTrans, out float4 homoPos, out float4 curPos, out float4 prePos, inout float3 dir0, inout float3 dir1, inout float3 dir2, out float3 worldPos)
{
	homoPos = mul(float4(pos,1.0f), mvpTrans);
	worldPos = mul(float4(pos,1.0f), worldTrans); 
	curPos = mul(float4(pos,1.0f), curMvpTrans);
	prePos = mul(float4(pos,1.0f), preMvpTrans);	

	dir0 = mul(dir0, (float3x3)worldTrans);
	dir1 = mul(dir1, (float3x3)worldTrans);
	dir2 = mul(dir2, (float3x3)worldTrans);
}
#endif

void VertexTransformCalc(float3 pos, out float4 homoPos, out float3 worldPos)
{    
	homoPos = mul(float4(pos,1.0f), worldViewProj);
	worldPos = mul(float4(pos,1.0f), worldMatrix);    
}

void VertexTransformCalc(float3 pos, float4x4 worldTrans, float4x4 mvpTrans, out float4 homoPos, out float3 worldPos)
{    
	homoPos = mul(float4(pos,1.0f), mvpTrans);
	worldPos = mul(float4(pos,1.0f), worldTrans);    
}
#endif

#endif//QSSHADER_QSVertexCalc_H