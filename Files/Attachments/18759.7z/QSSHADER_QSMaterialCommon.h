#ifndef QSSHADER_QSMaterialCommon_H
#define QSSHADER_QSMaterialCommon_H
#include "FunctionLib.h"
#include "QSVertexCalc.h"
#include "QSInstancingShader.h"

sampler2D BaseSampler;
float InverseNormal = 1.f; 

/*
*   full lighting       normal mapping, shadowing
*   normal map 			if disable, will disable specular lighting too
*   shadow              depth only, possible with alpha test
*/
struct VsIn
{
    half4 pos					: POSITION;   

#if ALPHATEST||LIGHTING||DEPTH_PEELING||FORCE_UV||ELECTRONIZE
    float2 uv0					: TEXCOORD0;    //alpha test always enable for current
    #if SECOND_UV && LIGHTING
        float2 uv1				: TEXCOORD1;    
    #endif
#endif

#if SKINNING
    #if VERTEX_COMPRESSION
        int4   blendWeight		: BLENDWEIGHT;
    #else
        float3 blendWeight		: BLENDWEIGHT;
    #endif
    int4   blendIndices			: BLENDINDICES;
#endif

#if DEPTH && CLOTH_WIND
	#if VERTEX_COMPRESSION
		int4 normal				: NORMAL;
		int4 vertexColor		: COLOR;
	#else
		float3 normal			: NORMAL;
		float3 vertexColor		: COLOR;
	#endif
#endif

#if LIGHTING || (ELECTRONIZE && !DEPTH)
    #if VERTEX_COMPRESSION
		#if QTANGENTS
			int4 qtangents			: TANGENT;
		#else
			#if HAS_NORMAL || CLOTH_WIND
				int4 normal			: NORMAL;
			#endif
			#if NORMALMAP || BLINGMAP  || CLOTH_WIND//non simplify case, with normal mapping
				int4 binormal		: BINORMAL;
				int4 tangent		: TANGENT;
			#endif
		#endif
    #else
        float3 normal			: NORMAL;
        #if APEX_CLOTH
            float4 tangent		: TANGENT;
        #else
            #if NORMALMAP || BLINGMAP || CLOTH_WIND //non simplify case, with normal mapping
                float3 binormal	: BINORMAL;
                float3 tangent	: TANGENT;
            #endif
        #endif
    #endif

	#if CLOTH_WIND
		#if VERTEX_COMPRESSION
			int4   vertexColor :    COLOR;
		#else
			float3 vertexColor :    COLOR;
		#endif //VERTEX_COMPRESSION
	#endif // CLOTH_WIND

#endif		
};

struct VsOut 
{
    float4 pos					: POSITION;

#if ALPHATEST||LIGHTING||DEPTH_PEELING||FORCE_UV||ELECTRONIZE
    #if SECOND_UV&&LIGHTING
        float4 uv0				: TEXCOORD0;
    #else
        float2 uv0				: TEXCOORD0;
    #endif
#endif//ALPHATEST||LIGHTING

#if LIGHTING||(ELECTRONIZE&&!DEPTH)
    float3 normal				: TEXCOORD1;
    #if NORMALMAP || BLINGMAP || CLOTH_WIND //when disable normal mapping, disable specular too, not very necessary to take specular when no normal mapping
        float3 tangent			: TEXCOORD2;    //normal mapping
        float3 binormal			: TEXCOORD3;    //normal mapping        
    #endif//NORMALMAP

    #if FORWARD_LIGHTING || BLINGMAP || ELECTRONIZE
        float4 projPos			: TEXCOORD4;
    #endif

    #if WRITE_VELOCITY
		float4 curPos : TEXCOORD5;
		float4 prePos : TEXCOORD6;
    #endif

	#if SNOW_ACCUMULATION || ELECTRONIZE
		float3 objNormal : TEXCOORD7;
		float3 objPos : TEXCOORD8;
	#endif

	#if CLOTH_WIND
		float4 smoothNormal :    COLOR0;
		float4 wrinkleParam :	COLOR1;
	#endif // CLOTH_WIND

#else
    #if DEPTH_COLOR
        float2  homoDepth		: TEXCOORD5;
    #endif
	#if ELECTRONIZE && DEPTH
		float3 objPos : TEXCOORD8;
	#endif
#endif//LIGHTING
};

struct PsOut
{
	float4 color0				: COLOR0;
#if FORWARD_LIGHTING
	#if DEPTH_PEELING
		float4 color1			: COLOR1;
	#endif
#elif LIGHTING
	float4 color1				: COLOR1;
	float4 color2				: COLOR2;
#if WRITE_VELOCITY
	float4 velocity             : COLOR3;
#endif
#endif
};

#include "QSClothWind.h"

void VertexDecompression(VsIn param, out float3 pos)
{
#if VERTEX_COMPRESSION
	pos = param.pos.xyz * param.pos.w;
#else
	pos = param.pos.xyz;
#endif
}

//-------------------------------------------------------------------------
//lighting ps and vs
//-------------------------------------------------------------------------
#if LIGHTING || (ELECTRONIZE&&!DEPTH)

#include "QSInstancingShader.h"

void VertexDecompression(VsIn param, out float3 pos, out float3 normal, out float3 tangent, out float3 binormal)
{
#if VERTEX_COMPRESSION	
	pos = param.pos.xyz * param.pos.w;

	#if QTANGENTS
		float4 qtangents = DecompressCharToFloat(param.qtangents);
		DecodeQTangents(qtangents, normal, tangent, binormal);
	#else
		#if HAS_NORMAL
			normal = DecompressCharToFloat(param.normal);		
		#else
			normal = 1;
		#endif

		#if NORMALMAP || BLINGMAP
			float4 tempTangent = DecompressCharToFloat(param.tangent);
			tangent = tempTangent.xyz;
			binormal = DecompressCharToFloat(param.binormal);
			#if !HAS_NORMAL
				normal = cross(tangent, binormal);
				normal = normalize(normal) * tempTangent.w;
			#endif
		#else
			tangent = 1;
			binormal = 1;
		#endif
	#endif
#else
	pos = param.pos.xyz;
	normal = normalize(param.normal.xyz);

	#if APEX_CLOTH
		tangent = normalize(param.tangent.xyz);    
		binormal = -cross(normal, tangent) * param.tangent.w;			
	#else
		#if NORMALMAP || BLINGMAP
			tangent = param.tangent.xyz;
			binormal = param.binormal.xyz;  
		#else
			tangent = 1;
			binormal = 1;
		#endif//NORMALMAP
	#endif//APEX_CLOTH
#endif
}


void LightingVs(out VsOut result, VsIn param
#if INSTANCING
	,VsInInstancing instancingParam
#endif
	, float3 pos, float3 normal, float3 tangent, float3 binormal)
{
	result.pos = 0;
	
	float2 boneUv = float2(0.0f,0.0f);
#if SNOW_ACCUMULATION || ELECTRONIZE
	result.objNormal = normal;
#if NEED_LOCAL_TRANS
	result.objPos = mul(float4(pos.xyz, 1.0f), AttLocalTransform).xyz;
#else
	result.objPos = pos;
#endif
#endif
#if WRITE_VELOCITY
	float2 preBoneUv = float2(0.0f,0.0f);
	float4x4 worldTrans, mvpTrans, curMvpTrans, preMvpTrans;
	
#if INSTANCING
	#if SKINNING //|| DYNAMIC
	//#error "Dynamic should not be instanced."
	#endif
	GetTransformData(instancingParam, worldTrans, mvpTrans, curMvpTrans, preMvpTrans, boneUv);
#else
	GetTransformData(worldTrans, mvpTrans, curMvpTrans, preMvpTrans, boneUv, preBoneUv);
#endif

#if SKINNING
	#if DESTRUCT       
	    // for APEX Destructible and cooked destruct animation
		VertexTransformCalcForDestruct(pos, cameraPos, param.blendIndices.x, worldTrans, PartialViewProj, curPartialViewProj, prePartialViewProj, boneUv, preBoneUv, result.pos, result.curPos, result.prePos, normal, tangent, binormal);
	#else
		float3 skinnedPrePos, skinnedCurPos;
		VertexTransformCalc_Skinning(pos, param.blendWeight, param.blendIndices, boneUv, preBoneUv, pos, skinnedCurPos, skinnedPrePos, normal, tangent, binormal);
	#endif	
#endif  // SKINNING

#if CLOTH_WIND
	ClothWindVs(pos, result.smoothNormal, result.wrinkleParam, param, boneUv);
#endif // CLOTH_WIND

#if SKINNING
	#if DESTRUCT
		// do nothing
	#else
		VertexTransformCalc_Transform(pos, skinnedCurPos, skinnedPrePos, worldTrans, mvpTrans, curMvpTrans, preMvpTrans, result.pos, result.curPos, result.prePos, normal, tangent, binormal); 
	#endif 
#else // SKINNING
	#if DYNAMIC
		//TODO: need fix calculation for local transform case.
		//QSVertexCalc.h: 443
		VertexTransformCalc(pos, worldTrans, mvpTrans, curMvpTrans, preMvpTrans, result.pos, result.curPos, result.prePos, normal, tangent, binormal);
	#else
		VertexTransformCalc(pos, worldTrans, mvpTrans, result.pos, normal, tangent, binormal);
		result.curPos = float4(0, 0, 0, 1);
		result.prePos = float4(0, 0, 0, 1);
	#endif // DYNAMIC
#endif // SKINNING

#else   //WRITE_VELOCITY
	float4x4 worldTrans, mvpTrans;

#if INSTANCING
	#if SKINNING || DYNAMIC
	//#error "Dynamic should not be instanced."
	#endif
	GetTransformData(instancingParam, worldTrans, mvpTrans, boneUv);
#else
	GetTransformData(worldTrans, mvpTrans, boneUv);
#endif

#if SKINNING
	#if DESTRUCT       
	    // for APEX Destructible and cooked destruct animation
		VertexTransformCalcForDestruct(pos, cameraPos, param.blendIndices.x, worldTrans, PartialViewProj, boneUv, result.pos, normal, tangent, binormal);
	#else
		VertexTransformCalc_Skinning(pos, param.blendWeight, param.blendIndices, boneUv, pos, normal, tangent, binormal);
	#endif	
#endif // SKINNING

#if CLOTH_WIND
	ClothWindVs(pos, result.smoothNormal, result.wrinkleParam, param, boneUv);
#endif // CLOTH_WIND

#if DESTRUCT
	// do nothing
#else
	float3 worldPos;
	VertexTransformCalc_Transform(pos, worldTrans, mvpTrans, result.pos, normal, tangent, binormal, worldPos);
#endif // DESTRUCT

#endif  //WRITE_VELOCITY

	result.normal = normal;

#if NORMALMAP || BLINGMAP || CLOTH_WIND
	result.binormal = binormal;
	result.tangent = tangent;	
#endif

	result.normal *= InverseNormal;

#if SECOND_UV
	result.uv0 = float4(param.uv0, param.uv1);  	
#else
	result.uv0 = param.uv0;  	
#endif

#if FORWARD_LIGHTING || BLINGMAP || (ELECTRONIZE &&!DEPTH)
	result.projPos = result.pos;
#endif
}

VsOut LightingVs(VsIn param
	#if INSTANCING
		,VsInInstancing instancingParam
	#endif
	)
{
	float3 pos, normal, tangent, binormal;	
	VertexDecompression(param, pos, normal, tangent, binormal);
	VsOut result;
    LightingVs(result, param 
				#if INSTANCING
					, instancingParam
				#endif
					, pos, normal, tangent, binormal);
	return result;
}

#endif	//LIGHTING

#if DEPTH

VsOut DepthVs(VsIn param)
{
	VsOut result;

	float3 pos;
	VertexDecompression(param, pos);
#if ELECTRONIZE
#if NEED_LOCAL_TRANS
	result.objPos = mul(float4(pos, 1.0f), AttLocalTransform).xyz;
#else
	result.objPos = pos;
#endif
#endif
	//trans data
	float2 boneUv = float2(0.0f,0.0f);
	float4x4 worldTrans, mvpTrans;
	GetTransformData(worldTrans, mvpTrans, boneUv);

	//vertex trans calc
#if SKINNING
	#if DESTRUCT                
		VertexTransformCalc(pos, float3(1.0f,0.0f,0.0f), param.blendIndices.xxxx, mvpTrans, boneUv, result.pos);	
	#else
		VertexTransformCalc_Skinning(pos, param.blendWeight, param.blendIndices, boneUv, pos);
	#endif
#endif // SKINNING

#if CLOTH_WIND
	ClothWindVs(pos, param, boneUv);
#endif // CLOTH_WIND

#if DESTRUCT
	// do nothing
#else
	VertexTransformCalc_Transform(pos, mvpTrans, result.pos);
#endif // DESTRUCT

#if ALPHATEST || DEPTH_PEELING || ELECTRONIZE
	result.uv0 = param.uv0; 
#endif

#if DEPTH_COLOR
	result.homoDepth = float2(result.pos.z,result.pos.w);		
#endif

	return result;
}

PsOut DepthPs(VsOut param)
{
	PsOut result;
	result.color0 = 0.0f;

#if DEPTH_PEELING || ALPHATEST
	float a = tex2D(BaseSampler, param.uv0).a;
#endif

#if DEPTH_PEELING && COLOR_SHIFTING
	clip(a - 0.99f);
#elif ALPHATEST
	AlphaTest(a);
#elif DEPTH_PEELING
	clip(a - 0.01f);
#endif

#if DEPTH_COLOR	
	DepthEncodeToColor(param.homoDepth.x/param.homoDepth.y, result.color0);
#endif
	return result;
}

#endif DEPTH

void ReadNormalGloss(sampler2D s, float2 uv, inout float3 normal, inout float gloss)
{
	float4 color = SAMPLE_TEX(s, uv);
	float2 normalxy = BiDecompress(color.rg);
	float normalz = sqrt(1.0f-dot(normalxy,normalxy));
	normal = float3(normalxy,normalz);
	normal.g *= InverseNormal;
	gloss = color.b;
}

void ReadNormalRoughness(sampler2D s, float2 uv, inout float3 normal, inout float roughness)
{
    float4 color = SAMPLE_TEX(s, uv);
    float2 normalxy = BiDecompress(color.rg);
    float normalz = sqrt(1.0f-dot(normalxy,normalxy));
    normal = float3(normalxy,normalz);
	normal.g *= InverseNormal;
    roughness = color.b;
}

//roughnessAlpha if !=0.0f, means normal from map.rgb, and roughess from alpha
//else , normal's from map.rg, roughness from map.b
//when dxt5n, ag for normal, b for roughness, r's not used
void ReadNormalRoughness(sampler2D s, float2 uv, float roughnessAlpha, inout float3 normal, inout float roughness)
{
    float4 color = SAMPLE_TEX(s, uv);

#if DXT5N
    normal.xy = BiDecompress(color.ag);
    normal.z = sqrt(1.0f - dot(normal.xy, normal.xy));
    roughness = color.b;
#else //DXT5N
    normal.xyz = BiDecompress(color.xyz);
    if (roughnessAlpha != 0.0f)
    {
        roughness = color.a;
    }
    else
    {
        //normal.xy = BiDecompress(color.ag);
        normal.z = sqrt(1.0f - dot(normal.xy, normal.xy));
        roughness = color.b;
    }
#endif//DXT5N

	normal.g *= InverseNormal;
}

#endif//QSSHADER_QSMaterialCommon_H