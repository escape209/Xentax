#ifndef AMBIENT_OCCLUSION_H
#define AMBIENT_OCCLUSION_H
//common functions
#if HBAO
sampler2D HBAOSampler;
float GetAOData(float2 uv)
{
    return saturate(tex2D(HBAOSampler, uv).r);    
}
#else
float GetAOData(float2 uv)
{
    return 1.0f;
}
#endif
#endif //AMBIENT_OCCLUSION_H