#ifndef QSHEADER_QSSNOW_H
#define QSHEADER_QSSNOW_H
#include "DX12Defines.fxh"
sampler2D IceBaseNormalMap;
sampler2D IceBubbleMaskMap;
sampler2D IceColorCrackRoughnessMap;
sampler2D IceSubsurfaceHeightSpeckleMap;
sampler2D SnowMap;

#if SNOW_ACCUMULATION
float4 SnowParam;
float4 SnowAccumulationParam;
float4 SnowColorParam;

#define SnowStrength			(SnowParam.x)
#define SnowAccFrostStrength	(SnowParam.y)
#define SnowThickness			(SnowParam.z)
#define SnowRoughness			(SnowParam.w)


#define UseSnowAccumulation		(SnowAccumulationParam.x)
#define SnowAccNormalRot		(SnowAccumulationParam.y)
#define SnowAccXRegion			(SnowAccumulationParam.z)
#define SnowMultiplier			(SnowAccumulationParam.w)

#define	SnowColor				(SnowColorParam.xyz)
#define	SnowSpecular			(SnowColorParam.w)

void SnowAccumulationApply(inout float snowMask, inout float3 diffuseColor, inout float3 specColor, inout float3 snowBumpNormal, inout float snowRoughness,
	float2 uv, float3 objNormal, float3 objPos)
{
#define FROST_THRESHOLD 0.35
#define SNOW_THRESHOLD 0.2
	if (UseSnowAccumulation != 0.0f)
	{
		float4 snowValue = tex2D(SnowMap, AnisoSrgb, uv).rgba;
		float normalFactor = saturate(dot(normalize(objNormal), 
			normalize(float3(
				0, 
				clamp(SnowAccNormalRot > 1 ? SnowAccNormalRot - 1 : SnowAccNormalRot, -1, 1), 
				SnowAccNormalRot > 1 ? -1 : 1
			))));
		float positionFactor = saturate(exp(0.2 * (SnowAccXRegion - abs(objPos.x))) - 1);
		float snowRatio = saturate(exp(3 * (normalFactor - 0.7)) - 1);
		float snowPercent = SnowStrength;
		float snowFactor = saturate(snowValue.r - (1 - (1 - SNOW_THRESHOLD) * saturate(snowPercent))) *
			(1 / (1 - SNOW_THRESHOLD)) * snowRatio;
		float frostPercent = SnowAccFrostStrength;
		float frostFactor = saturate(snowValue.a - (1 - (1 - FROST_THRESHOLD) * saturate(frostPercent))) *
			(1 / (1 - FROST_THRESHOLD)) * normalFactor * max(frostPercent, 1);
		snowMask = lerp(frostFactor, snowFactor, snowRatio) * positionFactor;
		snowMask = saturate(snowMask);
	}
	else
	{
		snowMask *= SnowStrength;
	}

	if (snowMask != 0)
	{
		//TODO add noise
		diffuseColor.xyz = lerp(diffuseColor.xyz, SnowMultiplier * SnowColor, snowMask.x);
		specColor.xyz = lerp(specColor.xyz, SnowSpecular, saturate(snowMask.x / SNOW_THRESHOLD));
		float thicknessPercent = SnowThickness;
		float dxSnow = ddx(snowMask) * thicknessPercent;
		float dySnow = ddy(snowMask) * thicknessPercent;
		float2 ddxUV = ddx(uv);
		float2 ddyUV = ddy(uv);
		snowBumpNormal = cross(float3(ddxUV, dxSnow), float3(ddyUV, dySnow));
		snowBumpNormal = normalize(snowBumpNormal) * sign(snowBumpNormal.z);
		snowRoughness = snowMask * SnowRoughness;
	}

}
#endif

#if DEFERRED_ICE || WATER_ICE

float4 IceParam;
float4 IceLightColor;
float4 IceDeepColor;
float4 IceSubsurfaceColor;
float4 IceCracksBubbleColor;
float4 IceSurfaceCrackColor;

#define IceDistributeControl	(IceParam.x)
#define IceNormalControl		(IceParam.y)
#define IceThicknessControl		(IceParam.z)
#define UseSelfFresnel					true
#define UseSubsurfaceCracks				true
#define BubbleSurfaceMaskTiling			4.0
#define BubbleTiling01					2.0
#define BubbleTiling02					4.0
#define BubbleXOffset					0.2
#define BubbleXOffset1					0.2
#define BubbleXOffset2					0.2
#define BubbleYOffset					0.0
#define BubbleYOffset1					0.0
#define BubbleYOffset2					0.0
#define BubbleOpacity					0.89
#define Crack02Tiling					1.0
#define CracksBubbleColor				IceCracksBubbleColor.xyz
//#define CracksBubbleColor				float4(0.39,0.61,0.83,1.0)
//#define DeepColor						float4(0.038,0.039,0.04,1.0)
#define DeepColor						IceDeepColor.xyz
#define FresnelOpacity					1.0
#define LightColor						IceLightColor.xyz
//#define LightColor1						float4(0.22, 0.23, 0.27, 1.0)
#define MasterTiling					1.0
#define MaxRoughness					1.0
#define MinRoughness					0.5
#define Opacity01						0.05
#define Opacity02						0.3
#define Opacity03						0.8
#define RoughnessTiling					1.0
#define SubsurafceColorTint				IceSubsurfaceColor.xyz
//#define SubsurfaceColorTint				float4(0.5, 0.7, 1.0, 1.0)
#define SubsurfaceCrackTiling			6.0
#define SubsurfaceMaskTiling			1.0
#define SubsurfacePower					2.0
#define SurfaceColorTiling				1.0
#define SurfaceColorTiling02			1.0
#define SurfaceColorTiling03			1.0
#define	SurfaceCrackColor				IceSurfaceCrackColor.xyz
//#define	SurfaceCrackColor				float4(0.15,0.39,0.70,1.0)
#define TransparencyClipDistance		512.0
#define InScatterPower					IceSubsurfaceColor.a
#if WATER_ICE
#define ColorHeightRatio0				0.05
#define	ColorHeightRatio1				0.05
#else
#define ColorHeightRatio0				0.005
#define	ColorHeightRatio1				0.005
#endif
#define SubsurafceCrackHeightRatio		

float2 BumpOffset(float2 uv, float height, float heightRatio, float refPlane, float2 viewDirXY)
{
	return uv + viewDirXY * (height * heightRatio - refPlane * heightRatio);
}

float3 FuzzyShading(float3 baseColor, float3 normal, float coreDrakness, float edgeBightness, float power, float3 viewDir)
{
	float vDotN = dot(viewDir, normal);
	return baseColor * (pow(1 - vDotN, power) * edgeBightness + (1 - vDotN * coreDrakness));
}

float GetFresnel(float3 normal, float3 viewDir, float f0, float exponent)
{
	return f0 + (1 - f0) * pow(1 - dot(normal, viewDir), exponent);
}

float3 GetIceNormal(float2 uv1, float2 uv3, float crackMask, float2 viewDirRG)
{
	uv1 = BumpOffset(MasterTiling * 10 * uv1, 1, ColorHeightRatio0, 0.05, viewDirRG.xy);
	float3 normal0 = tex2D(IceBaseNormalMap, AnisoSrgb, uv1).xyz * 2 - 1;
  
  float3 normal1 = 0;
#if WATER_ICE
  normal1 = (tex2D(IceBaseNormalMap, AnisoSrgb, uv3) * 2 - 1) * crackMask;
#endif
  return normalize((normal0 + normal1) * float3(1,1,2));
}

float GetRoughness(float2 uv, float colorMask)
{
	float roughnessmask = tex2D(IceSubsurfaceHeightSpeckleMap, AnisoSrgb,
		(uv) * RoughnessTiling * MasterTiling).b;
	float roughness = lerp(MinRoughness, MaxRoughness, roughnessmask);
	return lerp(0.1, roughness, colorMask);
}

float GetOpaqueMask(float2 uv, float3 normal, float3 viewDir, float viewDistance, inout float bubbleOpacity)
{
	float color = tex2D(IceSubsurfaceHeightSpeckleMap, AnisoSrgb,
		SubsurfaceMaskTiling * MasterTiling * uv).g;
	float fresnel = GetFresnel(normal, viewDir, 0.04, 1.0);
	float opacity = saturate(pow(fresnel * 2, 3) * color * 4);
#if WATER_ICE
	bubbleOpacity = saturate(pow(1 - fresnel, 4));
#endif
	float cameraDistanceMask = clamp(viewDistance / TransparencyClipDistance, 0.05, 1);

	opacity = lerp(Opacity01, Opacity02, opacity);
	float finalOpacity = lerp(opacity, Opacity03, cameraDistanceMask);

	return finalOpacity 
			+ saturate(FresnelOpacity * GetFresnel(normal, viewDir, 0.04, 5));
}

float GetBubbleMask(float2 uv, float colorMaskFinal, float2 viewDirRG, float bubbleOpacity)
{
	float2 uv1 = uv * MasterTiling * BubbleTiling01;
	uv1 = BumpOffset(uv1, 1, -0.2, 0.05, viewDirRG.xy);
	float bubbleMask1 = tex2D(IceBubbleMaskMap, MipMapLinear, uv1).b;

	float2 uv2 = (uv + float2(BubbleXOffset, BubbleYOffset)) * MasterTiling * BubbleTiling02;
	uv2 = BumpOffset(uv2, 1, -0.2, 0.05, viewDirRG.xy);
	float bubbleMask2 = tex2D(IceBubbleMaskMap, MipMapLinear, uv2).b;

	float2 uv3 = (uv + float2(BubbleXOffset1, BubbleYOffset1)) * MasterTiling * BubbleSurfaceMaskTiling;
	float bubbleSubsurfaceMask = tex2D(IceSubsurfaceHeightSpeckleMap, MipMapLinear, uv3).r;

	float2 uv4 = BumpOffset(uv * SubsurfaceCrackTiling * MasterTiling, 1, -0.2, 0.05, viewDirRG.xy);
	float subsurfaceCrackMask = tex2D(IceBubbleMaskMap, MipMapLinear, uv4).r;

	float bubbleMask = 
		bubbleMask1
		+ bubbleMask2 * bubbleSubsurfaceMask * 2
		+ (UseSubsurfaceCracks ? subsurfaceCrackMask : 0);

	return (1 - colorMaskFinal) * bubbleMask * bubbleOpacity;

}

void GetIceDiffuseNormalRoughnessOpacityHeight(float2 uv, float2 viewDirRG, float3 viewDir, float viewDistance, float3 normalOrigin,
	out float3 diffuse, out float3 normal, out float roughness, out float opacity, out float height)
{
  float2 uv0 = BumpOffset(MasterTiling * uv, 1, ColorHeightRatio0, 0.05, viewDirRG.xy);
  height =  pow(tex2D(IceSubsurfaceHeightSpeckleMap, AnisoSrgb, uv0).g, 1.5f);
  
  float2 uv1 = BumpOffset(MasterTiling * SurfaceColorTiling * uv, 1, ColorHeightRatio0, 0.05, viewDirRG.xy);
  float colorMask = 0;
#if WATER_ICE
  float2 uv2 = BumpOffset(MasterTiling * Crack02Tiling * uv, 1, -0.5, 0.05, viewDir.xy);
  float colorMask1 = tex2D(IceColorCrackRoughnessMap, AnisoSrgb, uv2).r;
#endif  
  float2 uv3 = BumpOffset(MasterTiling * SurfaceColorTiling03 * uv, 1, -0.02, 0.05, viewDirRG.xy);
  float2 crackMaskRG = tex2D(IceColorCrackRoughnessMap, AnisoSrgb, uv3).rg;
  
  float bubbleOpacity = 0;
  opacity = GetOpaqueMask(uv, normalOrigin, viewDir, viewDistance, bubbleOpacity);

  float colorMaskFinal = saturate(height + colorMask);
  float3 iceColor0 = lerp(DeepColor, LightColor, colorMaskFinal);
  float3 iceColor1 = 0;
#if WATER_ICE
  iceColor1 = iceColor0 * lerp(1, 3, satuirate(colorMask1));
#endif
  float3 iceColor2 = iceColor0 + iceColor1;
#if WATER_ICE
  iceColor2 = lerp(iceColor2, SurfaceCrackColor.xyz, crackMaskRG.r * crackMaskRG.g);
  float bubbleMask = GetBubbleMask(uv, colorMaskFinal, viewDirRG, bubbleOpacity);
  iceColor2 = lerp(iceColor2, CracksBubbleColor, bubbleMask);
  opacity += lerp(0, BubbleOpacity, bubbleMask);
#endif
  diffuse = iceColor2;
  normal = GetIceNormal(uv, uv3, crackMaskRG.r, viewDirRG);

  roughness = GetRoughness(uv, colorMask);
  
}

float3 GetSubsurfaceColor(float3 diffuse)
{
	return diffuse * SubsurfacePower * SubsurafceColorTint;
}

void DeferredIceApply(
	inout float3 diffuse, inout float3 normal, inout float3 specular, inout float gloss, inout float3 subsurfaceColor,
	out float opacity,
	float3 worldPos, float3 cameraPos, float iceLevel
)
{
#if WATER_ICE
	float3 viewDir = cameraPos - worldPos;
	float viewDistance = length(viewDir);
	viewDir /= viewDistance;
	float2 iceUV = worldPos.xy * 0.002;
	float2 viewDirRG = viewDir.xy;
#else
	if (iceLevel < 0.5f) return;
	float3 viewDir = cameraPos - worldPos;
	float viewDistance = length(viewDir);
	viewDir /= viewDistance;
	float3 absNormal = abs(normal);
	float maxComponent = max(max(absNormal.x, absNormal.y), absNormal.z);
	float2 selector = absNormal.xz >= maxComponent.xx ? float2(1.0, 1.0) : float2(0.0, 0.0);
	float2 tempUV = float2(lerp(worldPos.x, worldPos.y, selector.x), worldPos.z);//if x is max, then use worldPos.yz: else use worldPos.xz
	float2 iceUV = lerp(tempUV, worldPos.yx, selector.yy) * 0.0002;//if z is max then use worldpos.xy, else use tempUV(worldPos.yz or worldPos.xz); 
	
	float2 tempViewDirRG = float2(lerp(viewDir.x, viewDir.y, selector.x), viewDir.z);
	float2 viewDirRG = lerp(tempViewDirRG, viewDir.yx, selector.yy);
#endif
	float3 iceNormal = 0;
	float3 iceDiffuse = 0;
	float iceHeight = 0;
	float iceRoughness = 0;
	float iceOpacity = 0;

	GetIceDiffuseNormalRoughnessOpacityHeight(iceUV.xy, viewDirRG, viewDir, viewDistance, normal,
		iceDiffuse, iceNormal, iceRoughness, iceOpacity, iceHeight);
#if !WATER_ICE
	iceLevel = min(iceLevel  * (1.0 / 3.0), 0.8) * IceThicknessControl;//TODO
	//adjust through normal
	float normalFactor = saturate(normal.z + IceNormalControl) - IceDistributeControl;
	float iceFactor = saturate(normalFactor / (clamp(IceDistributeControl + 0.7, -1, 1) - IceDistributeControl));
	iceFactor = sqrt(iceFactor * iceFactor * (3 - 2 * iceFactor));
	float iceIntensity = saturate(iceFactor + iceLevel - 1);//?
	iceIntensity *= (3 - iceIntensity * 2) * iceIntensity;
	iceIntensity *= iceIntensity;

	float3 binormal = abs(normal.x) < 0.999 ? float3(1, 0, 0) : float3(0, 0, 1);
	float3 tangent = cross(binormal.xyz, normal.xyz);//
	float3 finalNormal = mul(iceNormal.xyz, float3x3(binormal, tangent, normal));
	normal = iceIntensity > 0 ? finalNormal.xyz : normal;lerp(normal, finalNormal.xyz, saturate(iceIntensity * IceNormalControl * iceFactor * 10));
	normal = normalize(normal);
	iceDiffuse = FuzzyShading(iceDiffuse, normal, 0.25, 0.5, 1, viewDir);
	iceOpacity *= iceIntensity;
	diffuse = iceDiffuse;lerp(diffuse, iceDiffuse, iceOpacity);
	opacity = iceOpacity;
	gloss = 1 - iceRoughness;lerp(gloss, saturate(1 - iceRoughness), saturate(iceIntensity * 5));//iceIntensity > 1e-4 ? saturate(1 - iceRoughness) : gloss;

	specular = 1.0;lerp(specular, 1.0, saturate(iceIntensity * 5));//iceIntensity > 1e-4 ? 0.5 : specular;//lerp(specular, 1.0, saturate(iceIntensity * 10));//0.9 + noiseFinal * 0.1f;//lerp(specular, noiseVec.yyy, iceIntensity);
	subsurfaceColor = GetSubsurfaceColor(iceDiffuse);iceIntensity > 1e-4 ? GetSubsurfaceColor(iceDiffuse) : subsurfaceColor;
#else
	float3 binormal = abs(normal.x) < 0.999 ? float3(1, 0, 0) : float3(0, 0, 1);
	float3 tangent = cross(binormal.xyz, normal.xyz);//
	float3 finalNormal = mul(iceNormal.xyz, float3x3(binormal, tangent, normal));
	normal = finalNormal.xyz;
	normal = normalize(normal);
	iceDiffuse = FuzzyShading(iceDiffuse, normal, 0.25, 0.5, 1, viewDir);
	diffuse = iceDiffuse;
	
	opacity = iceOpacity;
	gloss = 1 - iceRoughness;
	specular = 1.0;
	subsurfaceColor = GetSubsurfaceColor(iceDiffuse);
#endif
}

void ApplyIceSubsuraface(inout float3 color, float lDotV, float3 directionalLightColor, float3 subsurfaceColor)
{
	float InScattering = pow(saturate(lDotV), InScatterPower * 255);

	color +=
		subsurfaceColor
		* InScattering
		* directionalLightColor.rgb
		// Energy normalization, tighter lobes should be brighter
		* (InScatterPower + 2.0f) / 8.0f;
}

#endif

#if DEFERRED_SNOW
float4 SnowParam;
float4 SnowColorParam;
float4 SnowSpecularParam;
float4 SnowTillingParam;


#define SnowDistributeControl	(SnowParam.x)
#define SnowNormalControl		(SnowParam.y)
#define SnowThicknessControl	(SnowParam.z)
#define TreeSnowControl			(SnowParam.w)


#define	SnowColor				(SnowColorParam.xyz)
#define SnowSpecBase			(SnowSpecularParam.x)	
#define SnowSpecScale			(SnowSpecularParam.y)	
#define SnowRoughness			(SnowSpecularParam.w)
#define SnowTilling				(SnowTillingParam.x)

void DeferredSnowApply(
	inout float3 diffuse, inout float3 normal, inout float3 specular,inout float gloss, out float subsurface, out float snowIntensity, 
	float3 worldPos, float3 viewDir, float snowLevel
)
{
	//snowLevel = SnowParam.w < 0 ? snowLevel : SnowParam.w;
	if (snowLevel < 0.5f) return;
	float3 absNormal = abs(normal);
	float maxComponent = max(max(absNormal.x, absNormal.y), absNormal.z);
	float2 snowUV = absNormal.xz >= maxComponent.xx ? float2(1.0, 1.0) : float2(0.0, 0.0);
	float2 tempUV = float2(lerp(worldPos.x, worldPos.y, snowUV.x), worldPos.z);//if x is max, then use worldPos.yz: else use worldPos.xz
	snowUV.xy = lerp(tempUV, worldPos.yx, snowUV.yy) * SnowTilling;//if z is max then use worldpos.xy, else use tempUV(worldPos.yz or worldPos.xz); 
	float4 snow = tex2D(SnowMap, AnisoSrgb, snowUV.xy);// normal.xy, sparkle, 

	float3 viewMulNormal = viewDir * normal * 100;
	float2 snowMask = snow.zw * float2(10.000000, 0.500000);
	float3 noise = sin(viewMulNormal);
	float noiseFinal = saturate(abs(noise.x * noise.y * noise.z) * snowMask.x);
	
	snowLevel = min(snowLevel  * (1.0/3.0), 0.8) * SnowThicknessControl;
	float trackFactor = 1;// -track * 0.6;
	//adjust through normal
	float normalFactor = saturate(normal.z + SnowNormalControl) - SnowDistributeControl ;
	float snowFactor = saturate(normalFactor / (clamp(SnowDistributeControl + 0.7, -1, 1) - SnowDistributeControl));
	snowFactor = sqrt(snowFactor * snowFactor * (3 - 2 * snowFactor));
	snowIntensity = saturate(snowFactor * 1/*AO*/ - (1 - trackFactor * snowLevel)) - snow.w * 0.25;//?
	snowIntensity = saturate(snowIntensity / snowMask.y);
	snowIntensity *= (3 - snowIntensity * 2) * snowIntensity;
	snowIntensity *= snowIntensity;

	float3 binormal = abs(normal.x) < 0.999 ? float3(1, 0, 0) : float3(0, 0, 1);
	float3 tangent = cross( binormal.xyz, normal.xyz );
	float3 texNormal = float3(snow.yx * 2 - 1, 0);
	texNormal.z = sqrt(1 - dot(texNormal.xy, texNormal.xy));
	float3 snowNormal = mul(texNormal.xyz, float3x3(binormal, tangent, normal));
	normal = lerp(normal, snowNormal.xyz, snowIntensity * snowFactor);
	normal = normalize(normal);
	float3 snowColor = SnowColor * lerp((snow.x * 0.4 + 0.5), 0.5, noiseFinal);

	float2 noiseVec = noiseFinal * float2(-0.9, SnowSpecScale) + float2(0.9, SnowSpecBase);
	diffuse = lerp(diffuse, snowColor, snowIntensity);

	gloss = lerp(gloss, (1 - saturate(noiseVec.x + SnowRoughness)), snowIntensity);
	//metallic *= (1 - snowIntensity);
	specular = lerp(specular, saturate(noiseVec.yyy), snowIntensity);

	float2 snowSubsurface = float2(snowIntensity,
		(snowIntensity < 1.0f ? saturate(2 * snowIntensity - 1) : snowIntensity )* 0.03  );
	subsurface = lerp(snowSubsurface.x, saturate(snowSubsurface.y * 10), 0.498039);
	subsurface = clamp(subsurface, 1.0 / 255.0, 254.0/255.0);
}
#endif

#endif // 
