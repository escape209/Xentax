#ifndef QSSHADER_QSGameTime_H
#define QSSHADER_QSGameTime_H

float4 GameTime;

#endif //QSSHADER_QSGameTime_H
