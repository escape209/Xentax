#ifndef QSSHADER_DX12_SSSMaskFun_H
#define QSSHADER_DX12_SSSMaskFun_H
static const float kFadeoutNearDistance = 2000.0; //unit:cm
static const float kFadeoutFarDistance =  4000.0;

//
// Mask subsurface scattering effect according to sssMask value and fadeout distance(unit:cm) setting
// @return: final blend factor, between 0 to 1.
//
float SSSCalcFade(float sssFactor, float2 uv, float fadeStart, float fadeEnd)
{
	float viewDepth = GetDeviceZ(uv);
    viewDepth = CalcViewZFromDeviceZ(viewDepth);
    float fadeAlpha = 1.0==sssFactor/*is Charactor*/ ? 0 : sssFactor;	
	if(viewDepth>=fadeStart)
    {
	    fadeAlpha *= 1.0 - saturate((viewDepth-fadeStart)/(fadeEnd-fadeStart)); //fade out
    }
	return fadeAlpha;
}

//
// Mask SSS and clip pixel if alpha below zero.
//
float SSSClipAndFade(float sssFactor, float2 uv, float fadeStart, float fadeEnd)
{
    float fadeAlpha = SSSCalcFade(sssFactor, uv, fadeStart, fadeEnd);
	if(fadeAlpha>=1.0||fadeAlpha<=0.0)
	{
	    clip(-1);
	}
	return fadeAlpha;
}
#endif//QSSHADER_DX12_SSSMaskFun_H
