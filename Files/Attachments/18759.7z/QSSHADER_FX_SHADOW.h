#ifndef QSSHADER_FX_SHADOW_H
#define QSSHADER_FX_SHADOW_H

#include "QSShadow.h"

#if SCREEN_SPACE_SHADOW_MAP || SHADOW || SHADOW_RENDER || FORWARD_LIGHTING


void CalcCascadeUvLowRes(float4 screenPos, int cascadeBias, float3 distBound, float scale, float vestureBias, inout float3 lightViewPos0, inout float3 lightViewPos1, out float xBias, inout float xbias2, inout float lerpRatio)
{	
    cascadeBias = clamp(cascadeBias, 0, CSM_INUSE_NUM - 1);

	//light view pos calc
	float3 lightViewPosSrc[CSM_INUSE_NUM];	

	lightViewPosSrc[0] = (cascadeBias <= 0) ? ScreenPosToLightViewPos(screenPos, ViewToLightSpace0) : float3(0, 0, 0);
	lightViewPosSrc[1] = (cascadeBias <= 1) ? ScreenPosToLightViewPos(screenPos, ViewToLightSpace1) : float3(0, 0, 0);
	lightViewPosSrc[2] = (cascadeBias <= 2) ? ScreenPosToLightViewPos(screenPos, ViewToLightSpace2) : float3(0, 0, 0);
	#if CSM_INUSE_NUM>3
		lightViewPosSrc[3] = (cascadeBias <= 3) ? ScreenPosToLightViewPos(screenPos, ViewToLightSpace3) : float3(0, 0, 0);
	#endif//CSM_INUSE_NUM>3

	float scaleSrc[4] = {1.0f,2.0f,0.0f,3.0f+vestureBias};
	float lerpThreshold = 0.09f;
	float epsilon = 0.002f;
	float invEplison = 1.0f-epsilon;

	for(int idx=cascadeBias; idx<CSM_INUSE_NUM; idx++)
	{
		float minDelta = lightViewPosSrc[idx].x-epsilon;
		minDelta = min(minDelta, invEplison-lightViewPosSrc[idx].x);
		minDelta = min(minDelta, lightViewPosSrc[idx].y-epsilon);
		minDelta = min(minDelta, invEplison-lightViewPosSrc[idx].y);

		if(minDelta>0.0f)
		{
			xBias = scaleSrc[idx]*scale;

			lightViewPos0.yz = lightViewPosSrc[idx].yz;
			lightViewPos0.x = xBias+lightViewPosSrc[idx].x*scale;

#if CASCADE_LERP
			if(minDelta<lerpThreshold)
			{
				lerpRatio = minDelta/lerpThreshold;

				if(idx<CSM_INUSE_NUM-1)
				{
					int dstIdx = LightViewCoordValid(lightViewPosSrc[idx+1].xy) ? idx+1 : idx+2;
					dstIdx = min(dstIdx, CSM_INUSE_NUM-1);
					xbias2 = scaleSrc[dstIdx]*scale;					
					lightViewPos1.yz = lightViewPosSrc[dstIdx].yz;
					lightViewPos1.x = xbias2+lightViewPosSrc[dstIdx].x*scale;
				}
				//give an invalid value, so that we'll have 1.0f shadow
				else
				{
					xbias2 = 2.0f;
				}
			}
#endif//CASCADE_LERP

			return;
		}
	}
}

float CascadedShadowMapLowRes(float4 screenPos, int cascadeBias, out float xBias, out float2 smUv)
{
	//const	
	float unifySmRtNum = VestureSmBias.y+CSM_INUSE_NUM;
	float scale = 1.0f/unifySmRtNum;   

    float bias = 0; 

	float halfInvSmRes = CascadedInfo.x;
	float3 distBound = CascadedInfo.yzw;
	float vestureBias = VestureSmBias.x;

	float3 lightViewPos = float3(0.0f,0.0f,0.0f);
	float xbias2=0.0f, lerpRatio=1.0f;
	float3 lightViewPos2 = float3(0.0f,0.0f,0.0f);

	CalcCascadeUvLowRes(screenPos, cascadeBias, distBound, scale, vestureBias, lightViewPos, lightViewPos2, xBias, xbias2, lerpRatio);

	smUv = lightViewPos.xy;

	float result = SampleShadow(lightViewPos, halfInvSmRes, bias, xBias, scale);

#if VESTURE_LERP		
	if(xBias>=scale*(CSM_INUSE_NUM-1))
	{
		float3 dstLightViewPos = ScreenPosToLightViewPos(screenPos, ViewToLightSpace4);

		float dstXBias = xBias;
		dstXBias += VestureSmBias.x>0.0f ? -scale : scale;
		dstLightViewPos.x = dstXBias+dstLightViewPos.x*scale;
		float dstResult = SampleShadow(dstLightViewPos, halfInvSmRes, bias, dstXBias, scale);
		result = lerp(result, dstResult, VestureSmBias.z);
	}
#endif

#if CASCADE_LERP
	if(lerpRatio<1.0f)
	{
		float lerpDst;

		if(xbias2<=1.0f)
		{
			lerpDst = SampleShadow(lightViewPos2, halfInvSmRes, bias, xbias2, scale);
		}
		else
		{
			lerpDst = 1.0f;
		}
		
		result = lerp(lerpDst, result, lerpRatio);
	}
#endif//CASCADE_LERP

	return result;
}

#endif // SCREEN_SPACE_SHADOW_MAP || SHADOW || SHADOW_RENDER || FORWARD_LIGHTING

#endif // QSSHADER_FX_SHADOW_H