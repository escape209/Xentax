#ifndef QSHairWind_h__
#define QSHairWind_h__

#include "QSVertexProcessUtils.h"

#define DEBUG_HAIR_WIND 0

#if WIND
float4 GameTime;
float4		WindEnvParam;
float4		WindAmbientParam;
float4		WindGustParam;
float4		LocalWindDirectionAndSpeed;
float4		WorldWindDirectionAndViewEnhance;
float4		PivotPosParam;

#define WorldWindDirection		WorldWindDirectionAndViewEnhance.xyz
#define ViewEnhance				WorldWindDirectionAndViewEnhance.w

#define PivotPosBase			(PivotPosParam.xyz)
#define PivotPosScale			(PivotPosParam.w)

#define HeadCenter				float3(0, -10, 180)

#define WindFieldDirection		float2(0.6, 0.8)
#define WindFieldSpeed			2000

#define WindSpeed				LocalWindDirectionAndSpeed.w // 0 ~ approx 10
#define LocalWindDirection		LocalWindDirectionAndSpeed.xyz

#define ambientPhaseOffset		WindAmbientParam.x // 0.2
#define ambientIntensityBase	WindAmbientParam.y // 0.07
#define ambientIntensityIncre	WindAmbientParam.z // 0.14
#define ambientTimeOffset		WindAmbientParam.w // 0.128

#define gustPhaseOffset			WindGustParam.x // 100
#define gustIntensityBase		WindGustParam.y
#define gustIntensityIncre		WindGustParam.z // 0.02
#define gustIntensityBound		WindGustParam.w // 1.57

float4 GetRotateQuat(float3 axis, float angle)
{
	float ha = angle * 0.5;
	return float4(sin(ha) * axis, cos(ha));
}

float3 Rotate(float4 rot, float3 pos)
{
	float qs = rot.w;
	float3 qv = rot.xyz;

	//return pos + 2.0 * cross(qv, cross(qv, pos) + qs * pos);
	return (qs * qs - dot(qv, qv)) * pos + 2 * qs * cross(qv, pos) + 2 * dot(qv, pos) * qv;
}

float WindAmbient(float3 generalVc, float3 pivotWS, float time, float timeOffset, float dist)
{
	float clampedWindSpeed = clamp(WindSpeed, 0, 6);
	float noise1 = (SimplexNoise(float2(generalVc.x + generalVc.y, time)) + 1) * 0.5;

#if DEBUG_HAIR_WIND
	noise1 = 1;
#endif

#if DEBUG_HAIR_WIND
	float animation = sin(10 * time);
#else
	float animation = sin(10 * time + generalVc.x * ambientPhaseOffset + timeOffset);
#endif

	float angle = (clampedWindSpeed * ambientIntensityIncre + ambientIntensityBase) * animation * noise1;

	return angle;
}

float WindGust(float2 gustUv, float time, float dist)
{
	float clampedWindSpeed = clamp(WindSpeed, 0, 2);
	float gust = (SimplexNoise(gustUv.xy) + 1) * 0.5;
	float angle = gust * clamp((clampedWindSpeed * gustIntensityIncre + gustIntensityBase) * dist, 0, gustIntensityBound);

#if DEBUG_HAIR_WIND
	angle = 0;
#endif

	return angle;
}

float4 WindPivotCompute(float3 pos, float3 pivot, float3 pivotWS, float2 gustUv, float3 generalVc, float3 smoothNormal, float time, float timeOffset, float intensity)
{	
    float directionWeight = saturate(dot(LocalWindDirection, smoothNormal) + 1.4);

#if DEBUG_HAIR_WIND
	directionWeight = 1;
#endif  

	float3 disp = pos - pivot;
	float3 dispN = normalize(disp);
	float dist = length(disp);

	float WindAmbientAngle = WindAmbient(generalVc, pivotWS, time, timeOffset, dist);
	float windGustAngle = WindGust(gustUv, time, dist);
	float angle = (WindAmbientAngle + windGustAngle) * directionWeight * ViewEnhance * intensity;

	float3 rotAxis = normalize(cross(dispN, LocalWindDirection));
	return GetRotateQuat(rotAxis, angle);
}

void GetPivotFromVertexColor(
#if VERTEX_COMPRESSION
	int4 vertexColor, 
#else
	float3 vertexColor,
#endif
	out bool affectByWind, out float3 pivot)
{
#if VERTEX_COMPRESSION
	affectByWind = dot(vertexColor, vertexColor) > 100;
	float3 vc = DecompressColorbToFloat(vertexColor).xyz;
#else
	affectByWind = dot(vertexColor, vertexColor) > 0.01;
	float3 vc = vertexColor;
#endif

	pivot = (vc * 256 - 128) * PivotPosScale + PivotPosBase;
}

void WindSimulate(inout float3 pos, inout float3 normal, inout float3 tangent, inout float3 binormal,
    VsIn param, float4x4 worldTrans, float2 boneUv, float timeOffset, float3 headCenterLS)
{
	bool affectByWind;
	float3 generalVc;
	GetPivotFromVertexColor(param.vertexColor, affectByWind, generalVc);

    float3 pivotLS = generalVc;
    float3 pivotWS = mul(float4(pivotLS, 1), worldTrans).xyz;

#if SKINNING
    VertexTransformCalc_Skinning(pivotLS, param.blendWeight, param.blendIndices, boneUv, pivotLS);
#endif

    float2 translate = worldTrans._m30_m31;
    float3 smoothNormal = normalize(pos - headCenterLS);

    float time = GameTime.x;

    float2 gustUv = (translate + generalVc * gustPhaseOffset - WindFieldDirection * WindFieldSpeed * time) * 0.001; // span to 10m

#if HAIR_WIND_INTENSITY
	const float intensity = tex2Dlod(HairInfoSampler, float4(param.uv1, 0, 0)).y;
#else
	const float intensity = 1.0;
#endif

	if (affectByWind)
    {
		float4 rot = WindPivotCompute(pos, pivotLS, pivotWS, gustUv, generalVc, smoothNormal, time, timeOffset, intensity);

		pos = pivotLS + Rotate(rot, pos - pivotLS);
        normal = normalize(Rotate(rot, normal));
        tangent = normalize(Rotate(rot, tangent));
        binormal = normalize(Rotate(rot, binormal));
    }
}

void WindSimulate(inout float3 pos,
    VsIn param, float4x4 worldTrans, float2 boneUv, float timeOffset, float3 headCenterLS)
{
	bool affectByWind;
	float3 generalVc;
	GetPivotFromVertexColor(param.vertexColor, affectByWind, generalVc);

    float3 pivotLS = generalVc;
    float3 pivotWS = mul(float4(pivotLS, 1), worldTrans).xyz;

#if SKINNING
    VertexTransformCalc_Skinning(pivotLS, param.blendWeight, param.blendIndices, boneUv, pivotLS);
#endif

    float2 translate = worldTrans._m30_m31;
    float3 smoothNormal = normalize(pos - headCenterLS);

    float time = GameTime.x;

    float2 gustUv = (translate + generalVc * gustPhaseOffset - WindFieldDirection * WindFieldSpeed * time) * 0.001; // span to 10m

#if HAIR_WIND_INTENSITY
	const float intensity = tex2Dlod(HairInfoSampler, float4(param.uv1, 0, 0)).y;
#else
	const float intensity = 1.0;
#endif

    if (affectByWind)
	{
        float4 rot = WindPivotCompute(pos, pivotLS, pivotWS, gustUv, generalVc, smoothNormal, time, timeOffset, intensity);

        pos = pivotLS + Rotate(rot, pos - pivotLS);
	}
}
#endif // WIND

#endif // QSHairWind_h__
