#ifndef QSSHADER_QSPhysicalLightingGGX_H
#define QSSHADER_QSPhysicalLightingGGX_H
#include "QSConstant.h"
#include "FunctionLib.h"
#include "QSShaderIndirectLighting.h"

float3 DiffuseLambert(float3 diffuseColor)
{
	return diffuseColor * InvPi;//inv pi
}

// [Burley 2012, "Physically-Based Shading at Disney"]
float3 DiffuseBurley(float3 diffuseColor, float roughness, float ndv, float ndl, float vdh)
{
	float fd90 = 0.5 + 2 * vdh * vdh * roughness;
	float fdv = 1 + (fd90 - 1) * QSPow5(1 - ndv);
	float fdl = 1 + (fd90 - 1) * QSPow5(1 - ndl);
	return diffuseColor * InvPi * fdv * fdl;
}

// GGX / Trowbridge-Reitz
// [Walter et al. 2007, "Microfacet models for refraction through rough surfaces"]
float DGGX(float roughness, float ndh)
{
	float a = roughness * roughness;
	float a2 = a * a;
	float d = (ndh * a2 - ndh) * ndh + 1;  // 2 mad
	return a2 * InvPi / (d * d);
}

// [Beckmann 1963, "The scattering of electromagnetic waves from rough surfaces"]
float D_Beckmann(float roughness, float ndh)
{
	float a = roughness * roughness;
	float a2 = a * a;
	float ndh2 = ndh * ndh;
	return exp((ndh2 - 1) / (a2 * ndh2)) / (PI * a2 * ndh2 * ndh2);
}

// Appoximation of joint Smith term for GGX
// [Heitz 2014, "Understanding the Masking-Shadowing Function in Microfacet-Based BRDFs"]
float VisSmithJointApprox(float roughness, float ndv, float ndl)
{
	float a = roughness * roughness;
	float visSmithV = ndl * (ndv * (1 - a) + a);
	float visSmithL = ndv * (ndl * (1 - a) + a);
	// Note: will generate NaNs with roughness = 0, prevent roughness to be 0.
	return 0.5 / (visSmithV + visSmithL);
}

// [Schlick 1994, "An Inexpensive BRDF Model for Physically-Based Rendering"]
float3 FSchlick(float3 specularColor, float vdh)
{
	float fc = QSPow5(1 - vdh);
	return saturate(50.0 * specularColor.g) * fc + (1 - fc) * specularColor;
	//return specularColor + (1 - specularColor) * fc;
}

inline void GGXDirectLighting(inout float3 diffuseLighting, inout float3 specularLighting, out float ndl, out float ndh, float3 diffuseColor, float3 specularColor, float3 lightColor, float roughness, float3 l, float3 v, float3 n, float shadowValue)
{
	float3 h = normalize(-v - l);
	ndl = saturate(dot(n, -l));
	float ndv = saturate(abs(dot(n, -v)) + 1e-5);
	ndh = saturate(dot(n, h));
	float vdh = saturate(dot(-v, h));

	//microfacet specular
	float D = DGGX(roughness, ndh);
	float Vis = VisSmithJointApprox(roughness, ndv, ndl);
	float3 F = FSchlick(specularColor, vdh);
	specularLighting = (D * Vis) * F;

	diffuseLighting = DiffuseLambert(diffuseColor);
	float3 lightingCommon = lightColor * ndl * shadowValue;
	diffuseLighting *= lightingCommon;
	specularLighting *= lightingCommon;
}

//env lighting part
sampler2D PreIntegratedGF;
float3 EnvBRDF(float3 specularColor, float roughness, float ndv)
{
	float2 AB = tex2D(PreIntegratedGF, float2(ndv, roughness)).rg;
	// Anything less than 2% is physically impossible and is instead considered to be shadowing 
	float3 GF = specularColor * AB.x + saturate(50.0f * specularColor.g) * AB.y;
	return GF;
}

float3 EnvBRDFApprox(float3 specularColor, float roughness, float ndv)
{
	// [ Lazarov 2013, "Getting More Physical in Call of Duty: Black Ops II" ]
	// Adaptation to fit our G term.
	const half4 c0 = { -1, -0.0275, -0.572, 0.022 };
	const half4 c1 = { 1, 0.0425, 1.04, -0.04 };
	half4 r = roughness * c0 + c1;
	float a004 = min(r.x * r.x, exp2(-9.28 * ndv)) * r.x + r.y;
	half2 AB = half2(-1.04, 1.04) * a004 + r.zw;
	AB.y *= saturate(50.0f * specularColor.g);
	return specularColor * AB.x + AB.y;
}

float ComputeCubemapMipFromRoughness(float roughness, float mipCount)
{
	float level = 3 - 1.15f * log2(roughness);
	return max(mipCount - 1 - level, 0);
}

float3 SampleEnvMapLightColorMip(float3 reflectDir, float mip)
{
	float4 envMapColor = texCUBElod( EnvMap, float4( reflectDir.xzy, mip));
	return EnvMapColorDecoding(envMapColor)*EnvMapPSParam.x;	
}

float3 EnvLighting(float3 specularColor, float roughness, float3 v, float3 n, float ao)
{
    float mipNum = EnvMapPSParam.w;
    float ndv = dot(v, n);
	float3 reflectDir = 2 * ndv * n - v;
	// Point lobe in off-specular peak direction
	float a = roughness * roughness;
	float3 r = lerp(n, reflectDir, (1 - a) * (sqrt(1 - a) + a));
	float mip = ComputeCubemapMipFromRoughness(roughness, mipNum);

    float3 envSpecLighting = EnvBRDFApprox(specularColor, roughness, ndv);

    float specOcclusion = saturate( Square( ndv + ao ) - 1.0f + ao );
    envSpecLighting *= specOcclusion;

    float3 envMapColor = SampleEnvMapLightColorMip(r,mip);	
	return envMapColor.rgb * envSpecLighting;
}
#endif//QSSHADER_QSPhysicalLightingGGX_H