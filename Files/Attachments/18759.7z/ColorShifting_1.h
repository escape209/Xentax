#ifndef ColorShifting_h__
#define ColorShifting_h__

float3		ShiftingColor1;
float3	    ShiftingColor2;
float		SpecIntensity;
float		ColorShiftMode;

#define INVALID_COLOR 666.0f

void CustomColor(inout float3 color )
{
	float3 ohsl = RgbToHsl(color);
	ohsl.r = ShiftingColor1.r==INVALID_COLOR?ohsl.r: ShiftingColor1.r;
	ohsl.g = ShiftingColor1.g==INVALID_COLOR?ohsl.g:(ShiftingColor1.g*ohsl.g*(1-ColorShiftMode))+ColorShiftMode*saturate(ohsl.g+(ShiftingColor1.g-0.5f)*2.0f);
	ohsl.b = ShiftingColor1.b==INVALID_COLOR?ohsl.b:((ShiftingColor1.b*ohsl.b)*(1-ColorShiftMode))+ColorShiftMode*saturate(ohsl.b+(ShiftingColor1.b-0.5f)*2.0f);
	color = HslToRgb(ohsl); 
}
void CustomSpec(inout float3 specColor)
{
	float3 oHsl = RgbToHsl(specColor);
	oHsl.r = ShiftingColor1.r==INVALID_COLOR?oHsl.r: ShiftingColor1.r;
	oHsl.g = ShiftingColor1.g==INVALID_COLOR?oHsl.g: ShiftingColor1.g*oHsl.g;
	oHsl.b = ShiftingColor1.b==INVALID_COLOR?oHsl.b:SpecIntensity==INVALID_COLOR?oHsl.b:(SpecIntensity*oHsl.b + oHsl.b);
	specColor = HslToRgb(oHsl);
}
void CustomHue(inout float3 color )
{
	if(ShiftingColor1.r!=INVALID_COLOR )
	{
		float3 ohsl = RgbToHsl(color);
		ohsl.r = ShiftingColor1.r;
		color = HslToRgb(ohsl);
	}
}

void ShiftColor(inout float3 srcColor, int channel, float mask)
{
	if (mask > 0.5f)
	{
		float3 shiftColor = channel == 0 ? ShiftingColor1 : ShiftingColor2;
		float3 ohsl = RgbToHsl(srcColor);
		ohsl.r = shiftColor.r;
		ohsl.g = saturate(shiftColor.g);
		ohsl.b = saturate(ohsl.b * shiftColor.b);
		srcColor = HslToRgb(ohsl);
	}
}

void ShiftSpec(inout float3 srcSpec, float3 shiftColor, float mask)
{
	if (mask > 0.5f)
	{
		float3 ohsl = RgbToHsl(srcSpec);
		ohsl.r = shiftColor.r;
		ohsl.g = saturate(shiftColor.g*SpecIntensity);
		ohsl.b = saturate(ohsl.b * shiftColor.b);
		srcSpec = HslToRgb(ohsl);
	}
}
#endif // ColorShifting_h__
