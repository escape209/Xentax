#ifndef QSSHADER_QSPhysicalLighting_H
#define QSSHADER_QSPhysicalLighting_H
#include "DX12Defines.fxh"
#define LIGHTING_MODEL_TRIACE 0
#define LIGHTING_MODEL_GGX 1

#define LIGHTING_MODEL LIGHTING_MODEL_GGX

#include "FunctionLib.fxh"
#include "QSPhysicalLightingGGX.fxh"

#define USE_VISIBILITY_FUNCTION 0

float3 PhysicallyBasedImageLighting(float3 normal, float3 viewDir, float gloss, float3 specColor, float fresnelFactor, float3 lightColor)
{
	float specPower = GetSpecPowerFromGloss(gloss);	

	//const preparation
	float3 h = normal;
	float ndh = 1.0f;        
	float ndv = saturate(dot(-viewDir, normal));
	float ndl = ndv; 	
	float invGloss = 1.0f-gloss;
	float invFresFactor = 1.0f/(1.0f+fresnelFactor*invGloss);

	//distribution function:blinn phong
	float distributePhong = (specPower+2)*InvTwoPi;		

	//fresnel:schlick 	
	float3 fresnelSchlick = specColor+(1.0f-specColor)*pow(max(1-ndv, 1e-5), 5.0f)*invFresFactor;
	//fresnelSchlick = fresnelSchlick*0.0000001f+specColor;
	//fresnelSchlick = QSmin(fresnelSchlick,0.001f);

	//visibility:smith
#if USE_VISIBILITY_FUNCTION
	float a = 1.0f/sqrt(specPower*PI/4.0f+HalfPi);
	float visibilitySmith = (ndl*(1.0f-a)+a)*(ndv*(1.0f-a)+a);
	visibilitySmith = 1.0f/visibilitySmith;	
#else
	float visibilitySmith = 1.0f;
#endif

	float3 physSpecular = distributePhong*fresnelSchlick*visibilitySmith;    	

	float3 finalLighting = physSpecular*lightColor;	    


	//debug code-----------------------------------------------------------------------------------
	//float3 finalLighting = (diffuseLighting*(diffuseColor*0.000001f+0.50f)+physSpecular*SunColor.xyz)*shadow*0.0000001f;	    
	//finalLighting = finalLighting*0.000001f+visibilitySmith*distributePhong*shadow;
	//finalLighting = finalLighting*0.000001f+fresnelSchlick*shadow;
	//finalLighting.r = visibilitySmith/20.0f;
	//finalLighting = visibilitySmith/20.0f;
	//---------------------------------------------------------------------------------------------

	return finalLighting; 
}


float3 PhyLightingImageBasedSpecular(float3 normal, float3 viewDir, float gloss, float3 specColor, float fresnelFactor, float3 lightColor)
{
	//const preparation
	float edh = saturate(dot(-viewDir, normal));;
	float invGloss = 1.0f-gloss;
	float invFresFactor = 1.0f/(1.0f+fresnelFactor*invGloss);

	float3 fresnelSpec = specColor+(1.0f-specColor)*pow(max(1-edh, 1e-5), 5.0f)*invFresFactor;
	float3 spec = fresnelSpec*gloss;	

	float3 finalLighting = spec*lightColor.xyz;	

	return finalLighting;	
}



void KelemanKalosPhyDirLighting(
    //output
    out float3 diffuseLighting, out float3 specLighting, out float3 adjustedDiffuse,
	//output ndl/ndh for further calculation, save instructions
	out float ndl, out float ndh,
    //input lighting property
    float3 lightDir, float3 lightColor, 
    //input
    float3 normal, float3 viewDir, float3 diffuseColor, float gloss, float3 specColor, float fresnelFactor, float shadow)
{
    //const preparation
    float3 h = normalize(-lightDir-viewDir);
    ndh = saturate(dot(normal, h));
    ndl = saturate(dot(-lightDir, normal));        	    
    float ndv = saturate(dot(-viewDir, normal));
    float vdh = saturate(dot(-viewDir, h));

    float3 spec = 0.0f;
    float specPower = GetSpecPowerFromGloss(gloss);	
    float invGloss = 1.0f-gloss;
	
	//fresnel
	float freBase = 1.0f-vdh;
	float freExp = pow(max(freBase, 1e-5), 5.0);
	float3 freResult = freExp+specColor*(1.0f-freExp);

	//distribution
	float roughness = (1.0f-gloss);		
	float invRoughSqr = 1.0f/(roughness*roughness);

	float alpha = acos(ndh);
	float ta = tan( alpha );  
	float distribution = invRoughSqr/pow(max(ndh, 1e-5),4.0)*exp(-(ta*ta)*invRoughSqr);  

	spec = max(distribution*freResult/dot(h,h),0.0f)*ndl;    

    //diffuse calc
    adjustedDiffuse = diffuseColor*invGloss;
    float3 dif = ndl*adjustedDiffuse;

    //light calc
    float3 lighting = shadow*lightColor;

    //light result
    diffuseLighting = dif*lighting;
    specLighting = spec*lighting;	
}

void QSDirectLighting(
				//output
				out float3 finalLighting, out float3 diffuseLighting, out float3 specularLighting, out float3 adjustedDiffuse, 
				//output ndl/ndh for further calculation, save instructions
				out float ndl, out float ndh,
				//input lighting property
				float3 lightDir, float3 lightColor, 
				//input
				float3 normal, float3 viewDir, float3 diffuse, float gloss, float3 specColor, float fresnelFactor, float shadow				
				)
{
#if PHYSICAL_SKIN && !MASK_SSS
    KelemanKalosPhyDirLighting(    
        diffuseLighting, specularLighting, adjustedDiffuse, ndl, ndh,
        lightDir, lightColor, 
        normal, viewDir, diffuse, gloss, specColor, fresnelFactor, shadow);
#else
    GGXDirectLighting(diffuseLighting, specularLighting, ndl, ndh, diffuse, specColor, lightColor, 1.0f-gloss, lightDir, viewDir, normal, shadow);
    adjustedDiffuse = diffuse;    
#endif
    finalLighting = diffuseLighting + specularLighting;
}

void QSDirectLightingSeparated(
				//output
				out float3 diffuseLighting, out float3 specularLighting, out float3 adjustedDiffuse, 
				//output ndl/ndh for further calculation, save instructions
				out float ndl, out float ndh,
				//input lighting property
				float3 lightDir, float3 lightColor, 
				//input
				float3 normal, float3 viewDir, float3 diffuse, float gloss, float3 specColor, float fresnelFactor, float shadow				
				)
{
#if PHYSICAL_SKIN && !MASK_SSS
    KelemanKalosPhyDirLighting(    
        diffuseLighting, specularLighting, adjustedDiffuse, ndl, ndh,
        lightDir, lightColor, 
        normal, viewDir, diffuse, gloss, specColor, fresnelFactor, shadow);
#else
    GGXDirectLighting(diffuseLighting, specularLighting, ndl, ndh, diffuse, specColor, lightColor, 1.0f-gloss, lightDir, viewDir, normal, shadow);
    adjustedDiffuse = diffuse;    
#endif
}
#endif//QSSHADER_QSPhysicalLighting_H