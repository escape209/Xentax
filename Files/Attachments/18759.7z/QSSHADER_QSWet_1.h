#ifndef QSSHADER_QSWet_H
#define QSSHADER_QSWet_H

float4 WetFactor;//x gloss inc, y specular color inc
sampler2D	WetMaskMap;
sampler2D	SeeperHNormalMap;
sampler2D	SeeperVNormalMap;
float4      SeeperNormalTransform;
float4      SeeperReflectionCtrl;

void WetApply(inout float gloss, inout float3 specColor, float wetMask)
{
#if ENHANCE_INDIRECT_LIGHTING || CHARACTER
	float specInt = dot(specColor, 1.0f/3.0f);
	float param = saturate(1-specInt-gloss);
	gloss = min(gloss+WetFactor.x*param*wetMask, 0.98f);
	
	specColor = min(specColor+WetFactor.y*param*wetMask, 1.0f);
#else
	gloss = min(gloss+WetFactor.x*wetMask, 0.98f);
	specColor = min(specColor+WetFactor.y*wetMask, 1.0f);
#endif
}

float SeeperApply(inout float3 normal, inout float2 uv, float3 worldPos, float invDistance, float wetMask)
{
    float reflection = 0;
    if (wetMask > 0)
    {
        float3 weight = float3(normal.xy, max(0, normal.z));
        weight = weight * weight;
        float3 offsetNormal;

#if SEEPER_H
        float2 texcoord_xy = worldPos.xy * SeeperNormalTransform.w;
        float3 normal_xy = (tex2D(SeeperHNormalMap, texcoord_xy) * 2 - 1);
        offsetNormal = normal_xy.xyz * weight.z/* * wetMask + (1-wetMask) * normal * weight.z*/;
#else
        offsetNormal = normal * weight.z;
#endif

#if SEEPER_V
        float2 texcoord_xz = worldPos.xz * SeeperNormalTransform.xy + float2(0, SeeperNormalTransform.z);
        float2 texcoord_yz = worldPos.yz * SeeperNormalTransform.xy + float2(0, SeeperNormalTransform.z);
        float3 normal_xz = (tex2D(SeeperVNormalMap, texcoord_xz) * 2 - 1) * weight.y;
        float3 normal_yz = (tex2D(SeeperVNormalMap, texcoord_yz) * 2 - 1) * weight.x;
        offsetNormal += (normal_xz.xzy + normal_yz.zxy);
#else
        offsetNormal += normal * (1-weight.z);
#endif

        float reflectionPower = SeeperReflectionCtrl.x;
        float3 intensity = SeeperReflectionCtrl.yzw * wetMask;	// reflectionScale, normalIntensity, distortionIntensity

        reflection = pow(max(1.0f - abs(dot(normal, normalize(offsetNormal))), 1e-5), reflectionPower);						
        reflection *= intensity.x;		

        float normalScale = saturate(1 + normal.z);
        uv += offsetNormal.xy * intensity.z * normalScale * invDistance;	

        normal = normalize(normal + offsetNormal * intensity.y); 
    }
    return reflection;	
}

#endif//QSSHADER_QSWet_H