#ifndef QSSHADER_PostFx_H
#define QSSHADER_PostFx_H
#include "DX12Defines.fxh"

/**
*   DataStructure definition
*/
#define MAX_SCENE_COLOR 4.0f

// HDR range max clamp value 0.05f
// Average 0.0001~0.01, sky 0.001~0.06
#define RGBM_HDR_COMPRESS_MULTIPLIER 20.f

struct PosTex
{
    float4 pos:SV_Position;
    float2 tex:TEXCOORD0;
};

struct TrackTex
{
	float4 pos : SV_Position;
	float3 tex : TEXCOORD0;
};

PosTex PosTexVS(PosTex param)
{
    PosTex result;
    result.pos = float4(param.pos.xyz,1);
    result.tex = param.tex;
    return result;
}

float CalcLuminance(float3 color)
{
    const float3 lumWeight = float3(0.299f,0.587f,0.114f);
    return dot(color, lumWeight);
}

//postfx basic parameter
Texture2D SrcSampler;
Texture2D SrcSamplerLinear;
Texture2D SrcSamplerMask;

#if 1 //TODO: SHADER_PS==SHADER_TYPE
float4 BufferResolution;   //xy--resolution, zw---inv resolution
float2 SharpenIntensity;
#endif

#if USE_GRAIN_JITTER || USE_GRAIN_INTENSITY || USE_GRAIN_QUANTIZATION
float2 GrainRandomFull;
float3 GrainScaleBiasJitter;
#endif

#if USE_COLOR_FRINGE
float3 ChromaticAberrationParams;
float4 ScreenPosToScenePixel;
#endif

#if USE_VIGNETTE
float VignetteIntensity;
#endif

//some util funcs
float2 GetScreenUv(float2 vpos)
{
    return (vpos)*BufferResolution.zw;
}

#endif //QSSHADER_PostFx_H