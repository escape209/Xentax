#ifndef QSSHADER_INDIRECT_CULL_H
#define QSSHADER_INDIRECT_CULL_H

#include "HierarchyZ.fxh"

struct BoundBox
{
    float3 mMin;
    float3 mMax;
};

struct OceanSectorData
{
    float2 offset;  //xy offset, z scale, w lod
    float Scale;
    float LODInfo;	
};

struct OceanSectorPadData
{
    OceanSectorData mData;
    float4 mPadding[256/16-1];
};

//data types
struct IndirectCommand
{
    uint2 cbvAddress;
    uint4 drawArguments0;
    uint2 drawArguments1;//1 int for padding
};

void SetupBoundBoxCamSpace(inout BoundBox bb, OceanSectorData v, float baseHeight, float maxHeight)
{
    float3 basePos = float3(v.offset.xy, baseHeight);
    bb.mMin = basePos - cameraPos;
    bb.mMax = bb.mMin + float3(v.Scale, v.Scale, maxHeight);
}

void CalcBoundRect(float4 boundingBox[8], out float4 boundRect, out float instanceDepth)
{
	//space range, xy:[-1,1],z[0,1]
	//y get reversed for screen space sampling
	for(int i=0; i<8; i++)
	{
		float w = boundingBox[i].w;
		boundingBox[i].xyz /= float3(w,-w,w);
	}
			
	// Hierarchical Z-Buffer Occlusion Culling                	
	// calc min/max
	boundRect = boundingBox[0].xyxy;
	// float instanceDepth = (2 + boundingBox[0].z) % 2;	// 处理处于包围盒内�?
	instanceDepth = boundingBox[0].z;	// 处理处于包围盒内�?
			
	for (int i = 1; i < 8; ++i)
	{			
		boundRect.xy = min(boundRect.xy, boundingBox[i].xy);
		boundRect.zw = max(boundRect.zw, boundingBox[i].xy);

		//boundingBox[i].z = (2 + boundingBox[i].z) % 2;
		instanceDepth = max(instanceDepth, boundingBox[i].z);
	}
	boundRect = boundRect * 0.5 + 0.5;//to [0,1]	
}

void CalcBoundRect(in BoundBox bb, out float4 boundRect, out float instanceDepth)
{
    // transform to screen space
    //y get reversed for screen space sampling
    boundRect.x = bb.mMin.x;
    boundRect.y = -bb.mMax.y;
    boundRect.z = bb.mMax.x;
    boundRect.w = -bb.mMin.y;
    instanceDepth = bb.mMax.z;
    
	boundRect = boundRect * 0.5 + 0.5;//to [0,1]	
}

//return if frustum culled
bool Culled(float4 v)
{
	v.z /= v.w;
	bool3 b;
	b.xy = abs(v.xy)>abs(v.w);//out of range of [-w,w]
	b.z = v.z<0.0f || v.z > 1.0f;//homo z out of [0,1]
	return any(b);
}

bool FrustumCull(float4 boundingBox[8])
{
    bool4 culled;
    for(int i=0; i<4; i++)
    {
        culled[i] = Culled(boundingBox[i]);
    }
    //reuse culled can save one register
    bool result = all(culled);
    for(int i=0; i<4;i++)
    {
        culled[i] = Culled(boundingBox[i+4]);
    }
    return result && all(culled);
}

#define BB_FRUSTUM_TEST \
 negPt = float3(planeInfo.x>0 ? bb.mMax.x : bb.mMin.x, planeInfo.y>0 ? bb.mMax.y : bb.mMin.y, planeInfo.z>0 ? bb.mMax.z : bb.mMin.z);\
 if(dot(negPt, planeInfo.xyz) + planeInfo.w < 0) {return false;}\
 posPt = float3(planeInfo.x>0 ? bb.mMin.x : bb.mMax.x, planeInfo.y>0 ? bb.mMin.y : bb.mMax.y, planeInfo.z>0 ? bb.mMin.z : bb.mMax.z);\
 bool curPlaneIntersect = dot(posPt, planeInfo.xyz) + planeInfo.w < 0;\
 intersect = intersect || curPlaneIntersect;

bool InFrustum(in BoundBox bb, float4x4 m, out bool intersect, out bool intersectByNear)
{
    intersect = false;
    float4 planeInfo; //ax + by + cz + d = 0, normal point inside, > 0 means in the plane
    float3 negPt, posPt;
    //left
    {
        planeInfo = float4(m[0][3]+m[0][0], m[1][3]+m[1][0], m[2][3]+m[2][0], m[3][3]+m[3][0]);
        BB_FRUSTUM_TEST;
    }
    
    //right
    {
        planeInfo = float4(m[0][3]-m[0][0], m[1][3]-m[1][0], m[2][3]-m[2][0], m[3][3]-m[3][0]);
        BB_FRUSTUM_TEST;
    }
    
    //bottom
    {
        planeInfo = float4(m[0][3]+m[0][1], m[1][3]+m[1][1], m[2][3]+m[2][1], m[3][3]+m[3][1]);
        BB_FRUSTUM_TEST;
    }
    
    //top
    {
        planeInfo = float4(m[0][3]-m[0][1], m[1][3]-m[1][1], m[2][3]-m[2][1], m[3][3]-m[3][1]);
        BB_FRUSTUM_TEST;
    }
    
    //near
    {
        planeInfo = float4(m[0][2], m[1][2], m[2][2], m[3][2]);
        BB_FRUSTUM_TEST;
    }
    
    //far
    {
        planeInfo = float4(m[0][3]-m[0][2], m[1][3]-m[1][2], m[2][3]-m[2][2], m[3][3]-m[3][2]);
        BB_FRUSTUM_TEST;
        intersectByNear = curPlaneIntersect; //reverse z
    }
  
    return true;
}

//do occlusion in standard hiz way(log and compare 4 points)
//less computation, but not so precise
bool OcclusionCullLogBase(float4 boundingBox[8])
{
	//calc screenspace bounds
	float4 boundRect;
	float instanceDepth;
	CalcBoundRect(boundingBox, boundRect, instanceDepth);
			
	// Calculate the bounding rectangle size in viewport coordinates
	int2 hizBufferResolution = HiZBufferInfo[0].xy;
	float2 viewSize = (boundRect.zw - boundRect.xy) * hizBufferResolution;

	// Calculate the texture LOD used for lookup in the depth buffer texture
	int lod = clamp(ceil(log2(max(viewSize.x, viewSize.y) * 0.5)), 0, MaxHiZBufferLevel-1);		

	// Fetch the depth texture using explicit LOD lookups
	float4 hizDepth;
	hizDepth.x = ReadHizData(boundRect.xy, lod);
	hizDepth.y = ReadHizData(boundRect.xw, lod);
	hizDepth.z = ReadHizData(boundRect.zw, lod);
	hizDepth.w = ReadHizData(boundRect.zy, lod);

	float depthMin = GetMin(hizDepth);
	float hizDepthCenter = ReadHizData((boundRect.zw + boundRect.xy) / 2, lod);		
	depthMin = min(depthMin, hizDepthCenter);

	return instanceDepth < depthMin;
}

//do depth comparison based on range
//cost more alu
bool OcclusionCullRangeBase(in BoundBox bb)
{
	//calc screenspace bounds
	float4 boundRect;
	float instanceDepth;
	CalcBoundRect(bb, boundRect, instanceDepth);
			
	// Calculate the bounding rectangle size in viewport coordinates
	int2 hizBufferResolution = HiZBufferInfo[0].xy;
	float2 viewSize = (boundRect.zw - boundRect.xy) * hizBufferResolution;

	// Calculate the texture LOD used for lookup in the depth buffer texture
	int lod = clamp(ceil(log2(max(viewSize.x, viewSize.y) * 0.5)), 0, MaxHiZBufferLevel-1);		

	// Fetch the depth texture using explicit LOD lookups
	float depthMin = GetMinHizDataInRange(boundRect.xy, boundRect.zw, lod);

	return instanceDepth < depthMin;
}

void SetupHomospaceBoundBox(in BoundBox bb, out float4 boundingBox[8])
{
    boundingBox[0] = mul(float4(bb.mMin.x, bb.mMax.y, bb.mMin.z, 1.0), curPartialViewProj);
	boundingBox[1] = mul(float4(bb.mMin.x, bb.mMax.y, bb.mMax.z, 1.0), curPartialViewProj);
	boundingBox[2] = mul(float4(bb.mMax.x, bb.mMax.y, bb.mMax.z, 1.0), curPartialViewProj);
	boundingBox[3] = mul(float4(bb.mMax.x, bb.mMax.y, bb.mMin.z, 1.0), curPartialViewProj);
	boundingBox[4] = mul(float4(bb.mMax.x, bb.mMin.y, bb.mMin.z, 1.0), curPartialViewProj);
	boundingBox[5] = mul(float4(bb.mMax.x, bb.mMin.y, bb.mMax.z, 1.0), curPartialViewProj);
	boundingBox[6] = mul(float4(bb.mMin.x, bb.mMin.y, bb.mMax.z, 1.0), curPartialViewProj);
	boundingBox[7] = mul(float4(bb.mMin.x, bb.mMin.y, bb.mMin.z, 1.0), curPartialViewProj);
}

#define AABB_CAL boundingBox = mul(boundingBox, 1 / boundingBox.w); \
                 bbOut.mMin = min(bbOut.mMin, boundingBox.xyz); \
                 bbOut.mMax = max(bbOut.mMax, boundingBox.xyz);
void SetupHomospaceBoundBox(in BoundBox bb,float4x4 partialViewProj, out BoundBox bbOut)
{
    float4 boundingBox;
    boundingBox = mul(float4(bb.mMin.x, bb.mMax.y, bb.mMin.z, 1.0), partialViewProj); 
    boundingBox = mul(boundingBox, 1 / boundingBox.w); 
    bbOut.mMin = bbOut.mMax = boundingBox.xyz;
    
	boundingBox = mul(float4(bb.mMin.x, bb.mMax.y, bb.mMax.z, 1.0), partialViewProj);
    AABB_CAL;  
	boundingBox = mul(float4(bb.mMax.x, bb.mMax.y, bb.mMax.z, 1.0), partialViewProj);
    AABB_CAL;
	boundingBox = mul(float4(bb.mMax.x, bb.mMax.y, bb.mMin.z, 1.0), partialViewProj);
    AABB_CAL;
	boundingBox = mul(float4(bb.mMax.x, bb.mMin.y, bb.mMin.z, 1.0), partialViewProj);
    AABB_CAL;
	boundingBox = mul(float4(bb.mMax.x, bb.mMin.y, bb.mMax.z, 1.0), partialViewProj);
    AABB_CAL;
	boundingBox = mul(float4(bb.mMin.x, bb.mMin.y, bb.mMax.z, 1.0), partialViewProj);
    AABB_CAL;
	boundingBox = mul(float4(bb.mMin.x, bb.mMin.y, bb.mMin.z, 1.0), partialViewProj);
    AABB_CAL;    
}
//frustum culling zone-------------------------

#endif//QSSHADER_INDIRECT_CULL_H