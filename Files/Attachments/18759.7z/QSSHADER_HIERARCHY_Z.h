#ifndef QSSHADER_HIERARCHY_Z_H
#define QSSHADER_HIERARCHY_Z_H

#define MaxHiZBufferLevel 9
#define MaxFloat 1e10

RWStructuredBuffer<float> HizDepthBuffer;
int4 HiZBufferInfo[MaxHiZBufferLevel];//xy resolution, z offset, for 4 level, make sure to use array instead of matrix, as the row/colum major's not what u think

float ReadHizData(float2 uv, int mip)
{
    mip = clamp(mip, 0, MaxHiZBufferLevel-1);
    int4 hizInfo = HiZBufferInfo[mip];
    int2 pos = clamp(int2(uv * hizInfo.xy), int2(0,0), hizInfo.xy - int2(1,1));
    int bufferAddr = hizInfo.z;
    bufferAddr += pos.y*hizInfo.x+pos.x;
    return HizDepthBuffer[bufferAddr];
}

float GetMinHizDataInRange(float2 startUV, float2 endUV, int mip)
{
    mip = clamp(mip, 0, MaxHiZBufferLevel-1);
    int4 hizInfo = HiZBufferInfo[mip];
    int2 startPos = clamp(int2(floor(startUV * hizInfo.xy)), int2(0,0), hizInfo.xy - int2(1,1));
    int2 endPos = clamp(int2(ceil(endUV * hizInfo.xy)), int2(0,0), hizInfo.xy - int2(1,1));
    float minData = MaxFloat;
    for(int x = startPos.x; x <= endPos.x; ++x)
    {
        for(int y = startPos.y; y <= endPos.y; ++y)
        {
            minData = min(minData, HizDepthBuffer[hizInfo.z + y * hizInfo.x + x]);
        }
    }
    return minData;
}

float GetMin(float4 v)
{
    float2 a = min(v.xy, v.zw);
    return min(a.x, a.y);
}

int GetBufferOffset(int lod)
{
    return HiZBufferInfo[lod].z;
}

int2 GetBufferResolution(int lod)
{
    return HiZBufferInfo[lod].xy;
}
#endif//QSSHADER_HIERARCHY_Z_H