#ifndef QSSHADER_QSShaderIndirectLighting_H
#define QSSHADER_QSShaderIndirectLighting_H

/*
 *	EnvMap related stuff	
 */
float4 EnvMapPSParam;//x brighness factor, y radius sqr, z inv fading gap sqr, w mipmap value of envmap for gloss sampling
float4 EnvMapProbePos;//pos in world space, w fresnel factor
samplerCUBE EnvMap;

#define ENV_MAP_NORMALIZE_ENCODING 0
float3 EnvMapColorDecoding(float4 src)
{
#if ENV_MAP_NORMALIZE_ENCODING
	if(src.w==1.0f)
	{
		return src.xyz;
	}
	else
	{
		return src.xyz*src.w*255.0f;
	}

	//return src.xyz;
#else
	return src.xyz;
#endif
}

float4 EnvMapColorEncoding(float3 src)
{
	float4 result = float4(src.xyz,1.0f/255.0f);
#if ENV_MAP_NORMALIZE_ENCODING
	float intensity = length(src.xyz);
	if(intensity>1.0f)
	{
		intensity = ceil(min(255.0f,intensity));
		result.xyz = src.xyz/intensity;
		result.w = intensity/255.0f;
	}
#endif
	return result;
}

float3 SampleEnvMapLightColor(float3 viewDir, float3 normal, float gloss)
{
	float3 reflectDir = reflect( viewDir, normal );		
	float4 envMapColor = texCUBElod( EnvMap, float4( reflectDir.xzy, EnvMapPSParam.w*( 1.0f-gloss ) ) );
	float3 lightColor = EnvMapColorDecoding(envMapColor)*EnvMapPSParam.x;	
	return lightColor;
}

float3 SampleEnvMapLightColor(float3 reflectDir, float invGloss)
{
	float4 envMapColor = texCUBElod( EnvMap, float4( reflectDir.xzy, EnvMapPSParam.w*invGloss));
	return EnvMapColorDecoding(envMapColor)*EnvMapPSParam.x;	
}


#endif//QSSHADER_QSShaderIndirectLighting_H
