#ifndef QSSHADER_AMBIENTOCCLUSIONCOMMON_H
#define QSSHADER_AMBIENTOCCLUSIONCOMMON_H
#include "DX12Defines.fxh"
#include "QSConstant.fxh"
#include "FunctionLib.fxh"
#include "PostFx.fxh"
#include "PostFxColor.fxh"
#include "QSScreenSpaceDepth.fxh"
#include "QSDeferredLighting.fxh"

#if HBAO_HALFRES
#define KERNEL_RADIUS 8
#else
#define KERNEL_RADIUS 4
#endif

#define InterleaveBlockSize 4
#define InterLeaveVPOSMask 3
#define InterleaveSplitOutTargetNum 8
Texture2D SrcTexture;
Texture2DArray DepthTextureArray;
float4 InterleaveParam;
float4 InterleavedBufferResolution; //lowResSize, 1.0/lowResSize, 

#define  InterleavedPixelIndex	InterleaveParam.x
#define  InterleavedPixelPercent InterleaveParam.y
#define  InterleavedUVFix		InterleaveParam.zw

float4 RandJitter;
float4 RadiusParam;
float4 ScaleParam;
float4 SpaceInfo; //x range, y fade range
				 //consts
float4 FadeParam;
float4 BlurParam;
float4 SampleShapeParam;
Texture2D JitterTexture;
#define  SmallScaleAOAmount		ScaleParam.x
#define  LargeScaleAOAmount		ScaleParam.y
#define	 Intensity				ScaleParam.z
#define	 HalfProjectScale		ScaleParam.w

#define  PowExponent			BlurParam.x
#define  BlurSharpness			BlurParam.y

#define  FarFadeOutThreshold	SpaceInfo.x
#define  FarFadeOutRange		SpaceInfo.y
#define  NearFadeInBegin		SpaceInfo.z
#define  NearFadeInEnd			SpaceInfo.w

#define  SampleAspectRatio		SampleShapeParam.x
#define  FarIntensity			SampleShapeParam.y
#if HBAO_COARSE
#ifndef VIEW_PROJ
#define VIEW_PROJ
float4x4 view;
#endif
#endif

float2 RotateDirection(float2 V, float2 RotationCosSin)
{
    // RotationCosSin is (cos(alpha),sin(alpha)) where alpha is the rotation angle
    // A 2D rotation matrix is applied (see https://en.wikipedia.org/wiki/Rotation_matrix)
    return float2(V.x * RotationCosSin.x - V.y * RotationCosSin.y, V.x * RotationCosSin.y + V.y * RotationCosSin.x);
}


float3 GetViewPosFromViewZHbao(float2 uv, float viewSpaceZ)
{
    float3 viewPos;
    viewPos.z = viewSpaceZ;
    viewPos.x = (uv.x * 2 - 1) * viewSpaceZ * ProjParam.x;
    viewPos.y = -(uv.y * 2 - 1) * viewSpaceZ * ProjParam.y;
    return viewPos;
}

float3 GetViewPos(float2 screenUv)
{
    float depth = DepthSampler.SampleLevel(NoMipMapPointClamp, screenUv, 0).r;
#if HBAO_HALFRES
	float viewSpaceZ = depth;
#else
	float viewSpaceZ = CalcViewZFromDeviceZ(depth);
#endif
	return GetViewPosFromViewZHbao(screenUv, viewSpaceZ);
}

float3 DeriveGeomeryViewNormal(float2 uv, float3 viewPos)
{
    float2 uvX0 = uv + float2(-BufferResolution.z, 0);
    float2 uvX1 = uv + float2(BufferResolution.z, 0);
    float2 uvY0 = uv + float2(0, -BufferResolution.w);
    float2 uvY1 = uv + float2(0, BufferResolution.w);

    float3 X0 = GetViewPos(uvX0);
    float3 X1 = GetViewPos(uvX1);
    float3 Y0 = GetViewPos(uvY0);
    float3 Y1 = GetViewPos(uvY1);

    float3 vecX0P = viewPos - X0;
    float3 vecPX1 = X1 - viewPos;
    float3 vecY0P = viewPos - Y0;
    float3 vecPY1 = Y1 - viewPos;

    float3 vecX = length(vecX0P) < length(vecPX1) ? vecX0P : vecPX1;
    float3 vecY = length(vecY0P) < length(vecPY1) ? vecY0P : vecPY1;

    return normalize(cross(vecX, vecY));
}
//----------------------------------------------------------------------------------
#define ResFactor 1.0f
#define NearRadius			(RadiusParam.x)
#define FarRadius			(RadiusParam.y)
#define NearHorizonFallOff	(RadiusParam.z)
#define FarHorizonFallOff	(RadiusParam.w)

#define NearThckness		(FadeParam.x)
#define FarThckness			(FadeParam.y)
#define FadeStart			(FadeParam.z)
#define FadeSpeed			(FadeParam.w)



#if HBAO_QUALITY_ULTRA
	#define NUM_DIRECTIONS 4
	#define NUM_STEPS 16
#elif HBAO_QUALITY_HIGH
	#define NUM_DIRECTIONS 2
	#define NUM_STEPS 16
#elif HBAO_QUALITY_MEDIUM
	//as the normal will affect the GTAO , only one sample will cause the ground be over occluded
	#define NUM_DIRECTIONS 2
	#define NUM_STEPS 8
#else
	#define NUM_DIRECTIONS 2
	#define NUM_STEPS 4
#endif


float ComputeDistanceFade(float distance)
{
    return saturate(max(0, distance - FadeStart) * FadeSpeed);
}

float IntegrateArcCosWeight(float2 h, float n)
{
    float2 Arc = -cos(2 * h - n) + cos(n) + 2 * h * sin(n);
    return 0.25 * (Arc.x + Arc.y);
}

float IntegrateArcUniformWeightArc(float2 h)
{
    half2 Arc = 1 - cos(h);
    return Arc.x + Arc.y;
}

float IntegrateArcUniformWeight(float2 cosh)
{
    half2 Arc = 1 - cosh;
    return Arc.x + Arc.y;
}

float IntegrateArcCosWeight(float2 h, float n, float cosn, float sinn)
{
    float2 Arc = -cos(2 * h - n) + cosn + 2 * h * sinn;
    return 0.25 * (Arc.x + Arc.y);
}

float IntegrateArcUniformWeight(float4 cosh)
{
    return 1 - cosh;
}

float GTAOFastSqrt(float x)
{
    //[Drobot2014a] Low Level Optimizations for GCN
	return asfloat(0x1FBD1DF5 + (asint(x) >> 1));
}

float2 GTAOFastSqrt(float2 x)
{
    //[Drobot2014a] Low Level Optimizations for GCN
    return asfloat(0x1FBD1DF5 + (asint(x) >> 1));
}

float GTAOFastAcos(float x)
{
    // [Eberly2014] GPGPU Programming for Games and Science
    float res = -0.156583 * abs(x) + PI / 2.0;
    res *= GTAOFastSqrt(1.0 - abs(x));
    return x >= 0 ? res : PI - res;
}

float2 GTAOFastAcos(float2 x)
{
    // [Eberly2014] GPGPU Programming for Games and Science
    float2 res = -0.156583 * abs(x) + PI / 2.0;
    res *= GTAOFastSqrt(1.0 - abs(x));
    return x >= 0 ? res : PI - res;
}

float ComputeCoarseAO(float2 FullResUV, float2 vPos, float2 pixelPercent, float3 ViewPosition, float3 ViewNormal)
{
    // Divide by NUM_STEPS+1 so that the farthest samples are not fully attenuated
      
    float2 invQuarterRes = BufferResolution.zw * ResFactor; //frankan todo, use full res ao fist
    float3 paramFade = lerp(float3(NearRadius, NearThckness, NearHorizonFallOff), float3(FarRadius, FarThckness, FarHorizonFallOff), ComputeDistanceFade(ViewPosition.z));
    const float radius = paramFade.x;
    const float thickness = paramFade.y;
    const float fallOffDivRadius2 = paramFade.z / (radius * radius);
    float StepSizePixels = max(min(radius * HalfProjectScale / ViewPosition.z, 512), NUM_STEPS) / (NUM_STEPS + 1);

    float3 BentNormal = 0;
    float Occlusion = 0;
    float distance = length(ViewPosition);
    float3 ViewDirection = -ViewPosition / distance;
    float BentCone = 0;

    const float Alpha = PI / NUM_DIRECTIONS;

	const float AlphaOffset = Alpha * pixelPercent.x;
    float TotalWeight = 0;
    [unroll]
    for (float DirectionIndex = 0; DirectionIndex < NUM_DIRECTIONS; ++DirectionIndex)
    {
		float Angle = Alpha * DirectionIndex + AlphaOffset ;

        // Compute normalized 2D direction
        float3 SliceDirection = float3(float2(cos(Angle), sin(Angle)), 0);
        //float3(normalize(RotateDirection(float2(cos(Angle), sin(Angle)), Rand.xy)), 0);
        float Weight = length(SliceDirection * float3(1, SampleAspectRatio, 0));
        // Jitter starting sample within thde first step
#if INTERLEAVED
		//use 4 pixel at leat to avoid self occlusion
		float RayPixels = (pixelPercent.y * StepSizePixels + InterleaveBlockSize);
#else
		float RayPixels = (pixelPercent.y * StepSizePixels + 1.0);
#endif
        //float t = -dot(ViewNormal, SliceDirection) / dot(ViewNormal, ViewDirection);
        //t /= sqrt(1 + t * t);
        float2 CosHorizon = -1;
        //float2(t, -t);
        float2 ScreenDirection = float2(SliceDirection.x, -SliceDirection.y); //trap!!!

        [loop]
        for (float StepIndex = 0; StepIndex < NUM_STEPS; ++StepIndex)
        {
            float2 UVOffset = round(RayPixels * ScreenDirection);
            float4 SnappedVPos = vPos.xyxy + float4(UVOffset.xy, -UVOffset.xy);
            float4 SnappedUV = SnappedVPos * invQuarterRes.xyxy;
#if INTERLEAVED
			float4 SnappedVPosInterleaved = ((int4(SnappedVPos)>>2) + 0.5f) *  InterleavedBufferResolution.zwzw;
			float depth1 = DepthTextureArray.SampleLevel(NoMipMapPointClamp, float3(SnappedVPosInterleaved.xy, InterleavedPixelIndex), 0).r;
            float depth2 = DepthTextureArray.SampleLevel(NoMipMapPointClamp, float3(SnappedVPosInterleaved.zw, InterleavedPixelIndex), 0).r;

			//float depth1 = DepthSampler.SampleLevel(NoMipMapPointClamp, SnappedUV.xy, 0).r;//use this code to test if fulluv is correct
            //float depth2 = DepthSampler.SampleLevel(NoMipMapPointClamp, SnappedUV.zw, 0).r;
#else
            float depth1 = DepthSampler.SampleLevel(NoMipMapPointClamp, SnappedUV.xy, 0).r;
            float depth2 = DepthSampler.SampleLevel(NoMipMapPointClamp, SnappedUV.zw, 0).r;
#endif
            const float4 projXY = (SnappedUV * 2 - 1) * float2(ProjParam.x, -ProjParam.y).xyxy;
            float3 viewPos1 = float3(projXY.xy, 1);
            float3 viewPos2 = float3(projXY.zw, 1);
#if	HBAO_HALFRES
            float2 viewSpaceZ12 = float2(depth1, depth2);
#else
			float2 viewSpaceZ12 = DepthParam.x / (DepthParam.y - float2(depth1, depth2) * DepthParam.z);
#endif
            float3 h1 = viewPos1 * viewSpaceZ12.x - ViewPosition;
            float3 h2 = viewPos2 * viewSpaceZ12.y - ViewPosition;

            float2 h1h2 = float2(dot(h1, h1), dot(h2, h2));
            float2 h1h2Length = rsqrt(h1h2);

            float2 falloff =
            saturate(h1h2 * fallOffDivRadius2); //close to r,-> stable

            float2 H = float2(dot(h1, ViewDirection), dot(h2, ViewDirection)) * h1h2Length;
            CosHorizon.xy = lerp(H, CosHorizon, H.xy > CosHorizon.xy ? falloff : thickness);
            RayPixels += StepSizePixels;
        }
        float3 sliceNormal = normalize(cross(SliceDirection, ViewDirection));
        float3 sliceTangent = normalize(cross(ViewDirection, sliceNormal));
        float3 ViewNormalProjectToSlice = ViewNormal - sliceNormal * dot(ViewNormal, sliceNormal);
        float VnPSLength = length(ViewNormalProjectToSlice);
        ViewNormalProjectToSlice /= VnPSLength;
        float CosVNPSwithView = clamp(dot(ViewNormalProjectToSlice, ViewDirection), -1, 1);
        float CosVNPSwithTangent = dot(ViewNormalProjectToSlice, sliceTangent);
        float AngleVNPSwithView = GTAOFastAcos(CosVNPSwithTangent) - PI / 2;
        float SinVNPSwithView = -CosVNPSwithTangent;
		//sign(dot(Direction, ViewDirection) - dot(Direction, ViewNormalProjectToSlice))
		//-sign(dot(ViewNormalProjectToSlice, sliceTangent)) * acos(CosVNPSwithView);

        CosHorizon = GTAOFastAcos(clamp(CosHorizon, -1, 1)) * float2(-1, 1);
        CosHorizon.x = AngleVNPSwithView + max(CosHorizon.x - AngleVNPSwithView, -PI / 2);
        CosHorizon.y = AngleVNPSwithView + min(CosHorizon.y - AngleVNPSwithView, PI / 2);
        BentCone += abs(CosHorizon.x - CosHorizon.y);
#if !GTAO
        Occlusion += 0.5 * IntegrateArcUniformWeightArc(CosHorizon) * Weight;
#else 
        float BentAngle = (CosHorizon.x + CosHorizon.y) * 0.5;
        BentNormal += ViewDirection * cos(BentAngle) - sliceTangent * sin(BentAngle); //rotate a bent angle from view direction
        Occlusion += VnPSLength * IntegrateArcCosWeight(CosHorizon, AngleVNPSwithView, CosVNPSwithView, SinVNPSwithView) * Weight;
#endif
        TotalWeight += Weight;
    }

    BentNormal = normalize(normalize(BentNormal) - ViewDirection * 0.5);
    Occlusion /= TotalWeight;NUM_DIRECTIONS;
    BentCone /= NUM_DIRECTIONS;
    return 1 - Occlusion;
}

//Temporal filter params
float4 PreDepthParam;
float4 TempralFilterParam;
float4x4 ClipToPrevClip;
Texture2D HistoryAOTexture;
Texture2D ContinueMaskTexture;

#define DefaultSharpen TempralFilterParam.x
#define TargetSharpen TempralFilterParam.y
#define DisocclusionThreashold TempralFilterParam.z
#define DiscontinuityThreshold TempralFilterParam.w
bool CheckContinuity(float2 uv, float3 viewPos)
{	
	float3 Neighbors[4];
	Neighbors[0] = GetViewPos(uv + float2(0, -BufferResolution.w)); // down pixel
	Neighbors[1] = GetViewPos(uv + float2(-BufferResolution.z, 0)); // left pixel
	Neighbors[2] = GetViewPos(uv + float2(BufferResolution.z, 0)); // right pixel
	Neighbors[3] = GetViewPos(uv + float2(0, BufferResolution.w)); // up pixel	
	float neighbourLength[4];
	[unroll]
	for (int i = 0; i < 4; i++)
	{
		neighbourLength[i] = length(Neighbors[i] - viewPos);
	}
	
	float MinDeltaX = min(neighbourLength[1], neighbourLength[2]);
	float MinDeltaY = min(neighbourLength[0], neighbourLength[3]);
	float threshold = DiscontinuityThreshold / saturate(viewPos.z * 0.005f);
	return MinDeltaX < threshold && MinDeltaY < threshold;
}

bool FinalCheckContinuity(float2 uv)
{
	return ContinueMaskTexture.SampleLevel(NoMipMapPointClamp, uv, 0).r > 0.01;
}

float2 SampleHistory(float2 UV)
{
	return HistoryAOTexture.SampleLevel(NoMipMapLinearClamp, UV, 0).rg;
}

float2 FilterHistoryAO(float2 ScreenPosition)
{
	float2 UV = ScreenPosition * float2(0.5f, -0.5f) + 0.5f; //Half pixel offset	
	return SampleHistory(UV);
}

float SampleCurrent(float2 uv)
{
	return SrcSampler.SampleLevel(NoMipMapPointClamp, uv, 0).r;
}

float FilterCurrentAO(in float2 uv)
{
	return SampleCurrent(uv);
}

float2 ViewportUVtoScreen(in float2 UV)
{
	return (UV - 0.5) * float2(2.0, -2.0);
}

void TemporalResolve(in float2 uv, in float depth, in float current, out float ao, out float historyAO)
{
    // ------------------------------------------------------------------------------
	// Reconstruct moving position according neighbor depth, this will avoid broken edge issue when moving
	float3 PosN; // Position of this pixel, possibly later nearest pixel in neighborhood.
	PosN.xy = ViewportUVtoScreen(uv);
	PosN.z = depth;
	
	// Screen position of minimum depth.
	float2 VelocityOffset = float2(0.0, 0.0);
	// Camera motion for pixel or nearest pixel (in ScreenPos space).
	bool OffScreen = false;
	float Velocity = 0;
	float2 HistoryScreenPosition = PosN.xy;
	float PrevViewZ = 0;
	{
		float2 BackN;	
		{
            // Static velocity using matrix to transform.
			float4 ThisClip = float4(PosN.xy, PosN.z, 1);
			float4 PrevClip = mul(ThisClip, ClipToPrevClip);
			float3 PrevScreen = PrevClip.xyz / PrevClip.w;
			BackN = PosN.xy - PrevScreen.xy;
			//reconstruct corrent point's view depth in previous view
			PrevViewZ = CalcViewZFromDeviceZ(PrevScreen.z, PreDepthParam);
		}
		
		float2 BackTemp = BackN * BufferResolution.xy;
		Velocity = length(BackTemp);
        // Easier to do off screen check before conversion.
		// BackN is in units of 2pixels/viewportWidthInPixels
		// This converts back projection vector to [-1 to 1] offset in viewport.		
		HistoryScreenPosition = PosN.xy - BackN;
		
		// Detect if HistoryBufferUV would be outside of the viewport.
		OffScreen = max(abs(HistoryScreenPosition.x), abs(HistoryScreenPosition.y)) >= 1.0;
	}
	
	float CurrentFilteredAO = current;

	float2 HistoryFilteredAOZ = FilterHistoryAO(HistoryScreenPosition);
	float HistoryViewZ = HistoryFilteredAOZ.g;
	// Whether the feedback needs to be reset.
	//gdc2012 Stable SSAO in Battlefield 3 with Selective Temporal Filtering
	float Disocclusion = abs(1 - PrevViewZ / HistoryViewZ);
	bool IgnoreHistory = OffScreen || Disocclusion > DisocclusionThreashold;
	// Offscreen or disocclusion.
	if (IgnoreHistory)
	{
		ao = historyAO = CurrentFilteredAO;
		return;
	}
	float ClampedHistory = HistoryFilteredAOZ.r;
	
	// COMPUTE BLEND AMOUNT 
	// ------------------------------------------------------------------------------
	
	float BlendFinal = DefaultSharpen; // By default, using current default blend weight
    BlendFinal = saturate(lerp(BlendFinal, TargetSharpen, saturate(Velocity / 20.0f))); // Calculate blend according to velocity
	
    // DO FINAL BLEND BETWEEN HISTORY AND FILTERED COLOR
	// ------------------------------------------------------------------------------
	historyAO = lerp(ClampedHistory, CurrentFilteredAO, BlendFinal);
	ao = historyAO;
}


#endif