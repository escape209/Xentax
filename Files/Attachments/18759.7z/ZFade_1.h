#ifndef ZFade_h__
#define ZFade_h__

//zFadeParam: x-- blendBegin, y--blendEnd, z--worldToCamLen, w--ScreenZ
float4 ZFade(float4 zFadeParam, float4 srcColor, float4 fadeoutColor)
{
	float beginDepth = zFadeParam.x;
	float endDepth = zFadeParam.y;
	float4 finalColor = srcColor;

	if(zFadeParam.z >= beginDepth)
	{
		float deltaZ = (zFadeParam.z-beginDepth)/(endDepth - beginDepth);
		
		deltaZ *= deltaZ;
		deltaZ = min(1, deltaZ);
		finalColor = lerp(srcColor, fadeoutColor, deltaZ);
	}

	return finalColor;
}

float CalcZFadeRatio(float invZFadeRangeSqr, float zFadeStartSqr, float distSqr)
{
    float ratio = saturate( (distSqr-zFadeStartSqr)*invZFadeRangeSqr );
    return ratio*ratio;
}

float3 ZFade(float invZFadeRangeSqr, float zFadeStartSqr, float distSqr, float3 sceneColor, float3 backGroundColor)
{
	float ratio = CalcZFadeRatio(invZFadeRangeSqr, zFadeStartSqr, distSqr);
	return lerp(sceneColor, backGroundColor, ratio);
}

float ZFade(float4 zFadeParam)
{
	float start = zFadeParam.x;
	float end = zFadeParam.y;
	float result = saturate((zFadeParam.z-start)/(end-start));
	return result*result;
}

#endif // ZFade_h__