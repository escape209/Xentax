#ifndef QSSHADER_QSDeferredLighting_H
#define QSSHADER_QSDeferredLighting_H

#include "FunctionLib.h"

#define BEST_FIT_NORMAL 1

sampler2D BestFitNormalTex;

//structure
struct GBufferPSOut
{
    float4 diffuseGBuf:COLOR0;
    float4 normalGBuf:COLOR1;
    float4 specGBuf:COLOR2;
};

//constants
sampler2D GBufferDiffuse; //xyz diffuse color
sampler2D GBufferNormal;  //xyz normal compressed
sampler2D GBufferSpecular;//x gloss, y spec intensity, z material id

//unpacking gbuffer
void GetDiffuseGBufferInfo(float2 uv, out float3 diffuse)
{
    float4 color = tex2D(GBufferDiffuse,uv);
    diffuse = color.xyz;	
}

void GetDiffuseGBufferInfo(float2 uv, out float4 diffuse)
{
    diffuse = tex2D(GBufferDiffuse,uv);	
}

void GetNormalGBufferInfo(float2 uv, out float3 normal, out float gloss)
{
    float4 src = tex2D(GBufferNormal, uv);	
    normal = normalize(src.xyz*2.0f-1.0f);
    gloss = src.w;
}

void GetSpecGBufferInfo(float2 uv, out float3 specColor)
{
    float4 src = tex2D(GBufferSpecular, uv);
    specColor = src.xyz;	
}

void GetSpecGBufferInfo(float2 uv, out float4 specColor)
{
    specColor = tex2D(GBufferSpecular, uv);	
}


//packing

//from sig2010 of crytek's share "CryENGINE 3: reaching the speed of light"
void BestFitNormalEncode(inout float3 normal)
{
	// get unsigned normal for cubemap lookup (note the full float presision is required)
	float3 normalUn = abs(normal.rgb);

	// get the main axis for cubemap lookup
	float maxNAbs = max(normalUn.z, max(normalUn.x, normalUn.y));

	// get texture coordinates in a collapsed cubemap
	float2 texcoord = normalUn.z < maxNAbs ? (normalUn.y < maxNAbs?normalUn.yz : normalUn.xz) : normalUn.xy;
	texcoord = texcoord.x < texcoord.y ? texcoord.yx : texcoord.xy;
	texcoord.y /= texcoord.x;

	// fit normal into the edge of unit cube
	normal.rgb /= maxNAbs;

	// look-up fitting length and scale the normal to get the best fit
	float fitScale = tex2D(BestFitNormalTex,texcoord).a;

	// scale the normal to get the best fit
	normal.rgb *= fitScale;
}

void PackGBufferWithGloss(out float4 difRt, out float4 normRt, out float4 specRt, float3 diffuse, float3 normal, float3 specColor, float gloss)
{
    difRt = float4(diffuse, 1.0f);
    normRt = float4(normal*0.5f+0.5f, gloss);
    specRt = float4(specColor, 0.0f);
}

void PackGBufferNormalFit(out float4 difRt, out float4 normRt, out float4 specRt, float3 diffuse, float3 normal, float3 specColor, float gloss)
{
    difRt = float4(diffuse, 1.0f);

#if BEST_FIT_NORMAL
    BestFitNormalEncode(normal);
#endif

    normRt = float4(normal*0.5f+0.5f, gloss);
    specRt = float4(specColor, 0.0f);
}

void PackGBufferWithGloss(out float4 difRt, out float4 normRt, out float4 specRt, float4 diffuse, float3 normal, float3 specColor, float gloss, float deferredSnowLevel = 0)
{
    difRt = diffuse;
    normRt = float4(normal*0.5f+0.5f, gloss);
    specRt = float4(specColor, deferredSnowLevel);
}

void PackGBufferNormalFit(out float4 difRt, out float4 normRt, out float4 specRt, float4 diffuse, float3 normal, float3 specColor, float gloss, float deferredSnowLevel = 0)
{
    difRt = diffuse;
#if BEST_FIT_NORMAL
    BestFitNormalEncode(normal);
#endif
    normRt = float4(normal*0.5f+0.5f, gloss);
    specRt = float4(specColor, deferredSnowLevel);
}

//this is for terrain related
void PackGBufferWithGlossNoNormPack(out float4 difRt, out float4 normRt, out float4 specRt, float3 diffuse, float3 normal, float3 specColor, float gloss)
{
    difRt = float4(diffuse, 1.0f);
    normRt = float4(normal, gloss);
    specRt = float4(specColor, 0.0f);
}

void PackGBufferWithGlossNoNormPack(out float4 difRt, out float4 normRt, out float4 specRt, float4 diffuse, float3 normal, float3 specColor, float gloss)
{
    difRt = float4(diffuse.xyz,1);
    normRt = float4(normal, gloss);
    specRt = float4(specColor, 0.0f);
}

void PackGBufferWithGlossNoNormPack(out float4 difRt, out float4 normRt, out float4 specRt, float4 diffuse, float3 normal, float3 specColor, float gloss, float dirLightingRatio)
{
    difRt = float4(diffuse.xyz,1);
    normRt = float4(normal, gloss);
    specRt = float4(specColor, dirLightingRatio);
}
#endif//QSSHADER_QSDeferredLighting_H
