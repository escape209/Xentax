#ifndef QSSHADER_TerrainHeight_H
#define QSSHADER_TerrainHeight_H
sampler2D		HeightMapSampler;
sampler2D		NormalMapSampler;   
float4 			TerrainUvFactor;	//xy--bias, zw--mutiplier
float4 			TerrainGeoInfo; 	//x--map len factor, y--halfInvTileRes, z--halfInvMapRes, w--tileLen
float4			TerrainTileUvFactor;//xy:tile uv start, z:tile uv multiplier, w:tileNum factor   tileUv = (xy+uv)*z
float4          LodInfo;			//x:uv delta, y:lod transition ratio z:deltaFactor, w:sizeX
float4          TerrainHeightInfo;  //x peak height, y invPeakHeight
float4          TerrainSkirtInfo;   //xy bias on pos, zw mirror info
float4			TerrainPosBias;		//xy terrain pos bias on xy
float			SplitMaterialMaskTexel;

//static const float TerrainPeakHeight = 120000.0f;
//static const float InvTerrainPeakHeight = 1.0f/120000.0f;

float GetHeight(float2 uv, sampler2D heightMap)
{
    float TerrainPeakHeight = TerrainHeightInfo.x;
	return tex2Dlod(heightMap, float4(uv,0,0)).x*TerrainHeightInfo.x;
}

float GetHeightFromPos(float2 xy, float invTerrainSize)
{
    float TerrainPeakHeight = TerrainHeightInfo.x;
	float2 uv = xy*invTerrainSize;
	return tex2Dlod(HeightMapSampler, float4(uv,0,0)).x*TerrainPeakHeight;
}

void GetHeight(float2 uv, sampler2D heightMap, out float worldHeight, out float heightMapHeight)
{
    float TerrainPeakHeight = TerrainHeightInfo.x;
	heightMapHeight = tex2Dlod(heightMap, float4(uv,0,0)).x;
	worldHeight = heightMapHeight*TerrainPeakHeight;
}

float3 CalcNormal(float2 uv, float delta, sampler2D heightmap)
{
	//const
	float tileLen = TerrainGeoInfo.w;
	
	float2 uvLeft = uv+float2(-delta,0.0f);
	float2 uvRight = uv+float2(delta, 0.0f);
	float2 uvUp = uv+float2(0.0f, delta);
	float2 uvDown = uv+float2(0.0f,-delta);

	float heightLeft = GetHeight(uvLeft, heightmap);
	float heightRight = GetHeight(uvRight, heightmap);
	float heightUp = GetHeight(uvUp, heightmap);
	float heightDown = GetHeight(uvDown, heightmap);

	float3 vecRight = float3(delta*tileLen*2.0f, 0.0f, heightRight-heightLeft);
	vecRight = normalize(vecRight);
	float3 vecUp = float3(0.0f, delta*tileLen*2.0f, heightUp-heightDown);
	vecUp = normalize(vecUp);
	return cross(vecRight, vecUp);
}

float3 CalcNormal(float2 uv, float2 delta, float gridLen, sampler2D heightmap)
{
    //const
    float2 uvLeft = uv+float2(-delta.x,0.0f);
    float2 uvRight = uv+float2(delta.x, 0.0f);
    float2 uvUp = uv+float2(0.0f, delta.y);
    float2 uvDown = uv+float2(0.0f,-delta.y);

    float heightLeft = GetHeight(uvLeft, heightmap);
    float heightRight = GetHeight(uvRight, heightmap);
    float heightUp = GetHeight(uvUp, heightmap);
    float heightDown = GetHeight(uvDown, heightmap);

    float3 vecRight = float3(gridLen*2.0f, 0.0f, heightRight-heightLeft);
    vecRight = normalize(vecRight);
    float3 vecUp = float3(0.0f, gridLen*2.0f, heightUp-heightDown);
    vecUp = normalize(vecUp);
    return cross(vecRight, vecUp);
}

float2 GetTileUvFromGlobalUv(float2 globalUv)
{
	return (globalUv-TerrainTileUvFactor.xy)*TerrainTileUvFactor.zw;
}

float2 GetTilePointUvFromSectorUv(float2 uv)
{
	return (uv+TerrainTileUvFactor.xy)*TerrainTileUvFactor.z;
}

float2 GetTileGridUvFromSectorUv(float2 uv)
{
	return (uv+TerrainTileUvFactor.xy)*TerrainTileUvFactor.w;
}

void CalcLodHeightNormalTes(sampler2D heightMap, float2 globalUv, float2 sectorUv, float delta, float lodRatio, float uvLen, 
	out float3 worldPos, out float heightMapHeight, out float3 normal, out float2 resultSectorUv)
{
	//tesselation the lod info
	int2 uvLod = floor(globalUv*LodInfo.w);
	uvLod/=LodInfo.z;

	float2 resultGlobalUv = globalUv;
	resultSectorUv = sectorUv;

	if(sectorUv.x==0.0f||sectorUv.x==1.0f||sectorUv.y==0.0f||sectorUv.y==1.0f)
	{

	}
	else
	{
		if(uvLod.x%2==1)
		{
			if(((uvLod.x-1)/2)%2==0)
			{
				resultGlobalUv.x = globalUv.x-delta*lodRatio;    
				resultSectorUv.x -= lodRatio*LodInfo.z/32;
			}
			else
			{
				resultGlobalUv.x = globalUv.x+delta*lodRatio;    
				resultSectorUv.x += lodRatio*LodInfo.z/32;
			}
		}

		if(uvLod.y%2==1)
		{

			if(((uvLod.y-1)/2)%2==0)
			{
				resultSectorUv.y -= lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y-delta*lodRatio;
			}
			else
			{
				resultSectorUv.y += lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y+delta*lodRatio;
			}
		}
	}

	//tile const
	float2 resultTileUv = GetTilePointUvFromSectorUv(resultSectorUv);

	//calc normal

	float normDelta = delta*(1.0f+lodRatio); 
	float tileLen = TerrainGeoInfo.w;
	float2 uvLeft = resultTileUv+float2(-normDelta,0.0f);
	float2 uvRight = resultTileUv+float2(normDelta, 0.0f);
	float2 uvUp = resultTileUv+float2(0.0f, normDelta);
	float2 uvDown = resultTileUv+float2(0.0f,-normDelta);

	float heightLeft = GetHeight(uvLeft, heightMap);
	float heightRight = GetHeight(uvRight, heightMap);
	float heightUp = GetHeight(uvUp, heightMap);
	float heightDown = GetHeight(uvDown, heightMap);

	float3 vecRight = float3(normDelta*tileLen, 0.0f, heightRight-heightLeft);
	vecRight = normalize(vecRight);
	float3 vecUp = float3(0.0f, normDelta*tileLen, heightUp-heightDown);
	vecUp = normalize(vecUp);
	normal = cross(vecRight, vecUp);	

	//world pos
	GetHeight(resultTileUv+TerrainGeoInfo.y, heightMap, worldPos.z, heightMapHeight);
	worldPos.xy = resultGlobalUv * uvLen;
}

void CalcHeight(sampler2D heightMap, float2 globalUv, float2 sectorUv, float delta, float lodRatio, float uvLen, 
	out float3 worldPos, out float heightMapHeight, out float2 resultSectorUv)
{
	resultSectorUv = sectorUv;

	float2 resultTileUv = GetTilePointUvFromSectorUv(resultSectorUv);

	//world pos
	GetHeight(resultTileUv+TerrainGeoInfo.y, heightMap, worldPos.z, heightMapHeight);
	worldPos.xy = globalUv * uvLen;
}

void CalcLodHeightTes(sampler2D heightMap, float2 globalUv, float2 sectorUv, float delta, float lodRatio, float uvLen, 
	out float3 worldPos, out float heightMapHeight, out float2 resultSectorUv)
{
	//tesselation the lod info
	int2 uvLod = floor(globalUv*LodInfo.w);
	uvLod/=LodInfo.z;

	float2 resultGlobalUv = globalUv;
	resultSectorUv = sectorUv;

	if(sectorUv.x==0.0f||sectorUv.x==1.0f||sectorUv.y==0.0f||sectorUv.y==1.0f)
	{

	}
	else
	{
		if(uvLod.x%2==1)
		{
			if(((uvLod.x-1)/2)%2==0)
			{
				resultGlobalUv.x = globalUv.x-delta*lodRatio;    
				resultSectorUv.x -= lodRatio*LodInfo.z/32;
			}
			else
			{
				resultGlobalUv.x = globalUv.x+delta*lodRatio;    
				resultSectorUv.x += lodRatio*LodInfo.z/32;
			}
		}

		if(uvLod.y%2==1)
		{

			if(((uvLod.y-1)/2)%2==0)
			{
				resultSectorUv.y -= lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y-delta*lodRatio;
			}
			else
			{
				resultSectorUv.y += lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y+delta*lodRatio;
			}
		}
	}

	//world pos
	//tile const
	float2 resultTileUv = GetTilePointUvFromSectorUv(resultSectorUv);

	//world pos
	GetHeight(resultTileUv+TerrainGeoInfo.y, heightMap, worldPos.z, heightMapHeight);
	worldPos.xy = resultGlobalUv * uvLen;
}

float2 CalcSkirtUv(float2 uv, float2 skirtInfo)
{
    float2 result;
    result.x = skirtInfo.x>0.0f?1.0f-uv.x:uv.x;
    result.y = skirtInfo.y>0.0f?1.0f-uv.y:uv.y;
    return result;
}

//skirtInfo:xy pos bias, zw mirror info
void CalcLodHeightTesSKirt(sampler2D heightMap, float2 globalUv, float2 sectorUv, float delta, float lodRatio, float uvLen, float4 skirtInfo,
    out float3 worldPos, out float heightMapHeight, out float2 resultSectorUv)
{
    //tesselation the lod info
    int2 uvLod = floor(globalUv*LodInfo.w);
    uvLod/=LodInfo.z;

    float2 resultGlobalUv = globalUv;
    resultSectorUv = sectorUv;

    if(sectorUv.x==0.0f||sectorUv.x==1.0f||sectorUv.y==0.0f||sectorUv.y==1.0f)
    {

    }
    else
    {
        if(uvLod.x%2==1)
        {
            if(((uvLod.x-1)/2)%2==0)
            {
                resultGlobalUv.x = globalUv.x-delta*lodRatio;    
                resultSectorUv.x -= lodRatio*LodInfo.z/32;
            }
            else
            {
                resultGlobalUv.x = globalUv.x+delta*lodRatio;    
                resultSectorUv.x += lodRatio*LodInfo.z/32;
            }
        }

        if(uvLod.y%2==1)
        {

            if(((uvLod.y-1)/2)%2==0)
            {
                resultSectorUv.y -= lodRatio*LodInfo.z/32;
                resultGlobalUv.y = globalUv.y-delta*lodRatio;
            }
            else
            {
                resultSectorUv.y += lodRatio*LodInfo.z/32;
                resultGlobalUv.y = globalUv.y+delta*lodRatio;
            }
        }
    }

    //world pos
    //tile const
    float2 resultTileUv = GetTilePointUvFromSectorUv(resultSectorUv);

    //world pos
    GetHeight(resultTileUv+TerrainGeoInfo.y, heightMap, worldPos.z, heightMapHeight);
    worldPos.xy = resultGlobalUv*uvLen;
    	
	if(skirtInfo.z!=0.0f || skirtInfo.w!=0.0f)
	{
		float2 amplifyUv = resultGlobalUv;
		if(skirtInfo.x>0.0f)
		{
			amplifyUv.x = 1.0f-amplifyUv.x;
		}
		if(skirtInfo.y>0.0f)
		{
			amplifyUv.y = 1.0f-amplifyUv.y;
		}

		float amplifyFactor = 0.0f;
		float amplifyDst = 0.0f;

		if(skirtInfo.z!=0.0f)
		{
			amplifyFactor = amplifyUv.x;
			amplifyDst = skirtInfo.z;
			worldPos.x = -worldPos.x;	
		}

		if(skirtInfo.w!=0.0f)
		{
			amplifyFactor = max(amplifyUv.y,amplifyFactor);
			amplifyDst = skirtInfo.w;
			worldPos.y = -worldPos.y;
		}
		
        amplifyFactor = pow(amplifyFactor, 1.0f / 100.0f);
		amplifyFactor = lerp(1.0f,amplifyDst, amplifyFactor);
		worldPos.z *= amplifyFactor;
	}

    worldPos.xy += skirtInfo.xy;
}

void CalcLodHeightTesSKirtWithoutMap( float heightData, float2 globalUv, float2 sectorUv, float delta, float lodRatio, float uvLen, float4 skirtInfo,
	out float3 worldPos, out float2 resultSectorUv)
{
	//tesselation the lod info
	int2 uvLod = floor(globalUv*LodInfo.w);
	uvLod/=LodInfo.z;

	float2 resultGlobalUv = globalUv;
	resultSectorUv = sectorUv;

	if(sectorUv.x==0.0f||sectorUv.x==1.0f||sectorUv.y==0.0f||sectorUv.y==1.0f)
	{

	}
	else
	{
		if(uvLod.x%2==1)
		{
			if(((uvLod.x-1)/2)%2==0)
			{
				resultGlobalUv.x = globalUv.x-delta*lodRatio;    
				resultSectorUv.x -= lodRatio*LodInfo.z/32;
			}
			else
			{
				resultGlobalUv.x = globalUv.x+delta*lodRatio;    
				resultSectorUv.x += lodRatio*LodInfo.z/32;
			}
		}

		if(uvLod.y%2==1)
		{

			if(((uvLod.y-1)/2)%2==0)
			{
				resultSectorUv.y -= lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y-delta*lodRatio;
			}
			else
			{
				resultSectorUv.y += lodRatio*LodInfo.z/32;
				resultGlobalUv.y = globalUv.y+delta*lodRatio;
			}
		}
	}

	//world pos
	//tile const
	float2 resultTileUv = GetTilePointUvFromSectorUv(resultSectorUv);

	//world pos
	worldPos.z = heightData;
	worldPos.xy = resultGlobalUv*uvLen;

	if(skirtInfo.z!=0.0f || skirtInfo.w!=0.0f)
	{
		float2 amplifyUv = resultGlobalUv;
		if(skirtInfo.x>0.0f)
		{
			amplifyUv.x = 1.0f-amplifyUv.x;
		}
		if(skirtInfo.y>0.0f)
		{
			amplifyUv.y = 1.0f-amplifyUv.y;
		}

		float amplifyFactor = 0.0f;
		float amplifyDst = 0.0f;

		if(skirtInfo.z!=0.0f)
		{
			amplifyFactor = amplifyUv.x;
			amplifyDst = skirtInfo.z;
			worldPos.x = -worldPos.x;	
		}

		if(skirtInfo.w!=0.0f)
		{
			amplifyFactor = max(amplifyUv.y,amplifyFactor);
			amplifyDst = skirtInfo.w;
			worldPos.y = -worldPos.y;
		}

		amplifyFactor = lerp(1.0f,amplifyDst, amplifyFactor);
		worldPos.z *= amplifyFactor;
	}

	worldPos.xy += skirtInfo.xy;
}
#endif//QSSHADER_TerrainHeight_H