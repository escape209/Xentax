#ifndef QSSHADER_PostFxToneMap_H
#define QSSHADER_PostFxToneMap_H

float3 ACESToneMapApproximate(float3 x, float4 param0, float param1)
{
    const float a = param0.x; //2.51
    const float b = param0.y; //0.03
    const float c = param0.z; //2.43
    const float d = param0.w; //0.59
    const float e = param1; //0.14
    return saturate((x * (a * x + b)) / (x * (c * x + d) + e));
}

//tone map operator with default param
float3 ACESToneMapApproximate(float3 x)
{
    const float a = 2.51;
    const float b = 0.03;
    const float c = 2.43;
    const float d = 0.59;
    const float e = 0.14;

    return ACESToneMapApproximate(x, float4(a, b, c, d), e);
}

#endif 