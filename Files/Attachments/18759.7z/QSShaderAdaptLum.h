#ifndef QSShaderAdaptLum_H
#define QSShaderAdaptLum_H

sampler2D CurrentLumSampler;
float4 EyeAdaptParam;//x adapt balancer, y adapt ratio
float EyeAdaption(float lum)
{
    float adaptBalanceFactor = EyeAdaptParam.x;
    float adaptRatio = EyeAdaptParam.y;

    return lerp(adaptBalanceFactor, lum, adaptRatio);
}
float EyeAdaptionScale(float lum, float exposure)
{
    float adaptLum = EyeAdaption(lum);
    float scale = exposure / (1.e-6 + adaptLum);
    return scale;
}
void EyeAdaptSceneColor(inout float3 sceneColor, float lum, float exposure)
{
    float scale = EyeAdaptionScale(lum, exposure);
    sceneColor *= scale;
}

float GetAdaptScalePS(float exposure)
{
    float4 adaptLum = tex2D(CurrentLumSampler, float2(0.5f, 0.5f));
    return EyeAdaptionScale(adaptLum, exposure);    
}

float GetAdaptScaleVS(float exposure)
{
    float4 adaptLum = tex2Dlod(CurrentLumSampler, float4(0.5f, 0.5f, 0, 0));
    return EyeAdaptionScale(adaptLum, exposure);
}

#endif //QSShaderAdaptLum_H