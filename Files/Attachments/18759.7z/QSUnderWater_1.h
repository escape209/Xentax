#ifndef QSUnderWater_H
#define QSUnderWater_H

#include "DX12Defines.fxh"
#include "QSConstant.fxh"
#include "QSScreenSpaceDepth.fxh"
#include "QSShaderAtmosphere.fxh"
#include "QSUtils.fxh"

sampler2D CausticTex;
sampler2D GodRayTex;
float4x4 WorldToLight;
float4 UnderwaterData0;	
float4 UnderwaterData1;		
float4 UnderwaterData2;	
float4 UnderwaterData3;	
float3 RefractSunOrMoonDir;

#define UnderWaterFogColor		UnderwaterData0.xyz
#define CausticSize				UnderwaterData0.w
#define WaterHeight				UnderwaterData1.x
#define FogStartDistance		UnderwaterData1.y
#define FogDensity				UnderwaterData1.z
#define LightAttenuationHight	UnderwaterData1.w
#define WaveSpeed				UnderwaterData2.x
#define WaveSize				UnderwaterData2.y
#define WaveIntensity			UnderwaterData2.z
#define UnderwaterCausticIntensity		UnderwaterData2.w

// Mie phase function
float MiePhase(float angle, float g)
{
	float phase = (1 - g * g) / pow((1 + g * g - 2 * g * angle), 1.5);
	return phase;
}

float3 UnderWaterEffect(float2 refractUv, float fogStartDistance, float2 screenUv, float2 IndoorLight)
{
	float2 uvOffset = screenUv * WaveSize;
	uvOffset = sin(uvOffset * 2 + cos(uvOffset.yx + WaveSpeed)) * WaveIntensity;	
	float2 ssUv = refractUv + uvOffset;
	float depth = tex2D(DepthSampler, NoMipMapPointClamp, ssUv).r;
	float viewSpaceZ = CalcViewZFromDeviceZ(depth);

	// for distortion bug
	if (viewSpaceZ < fogStartDistance)
	{
		ssUv = screenUv;
		depth = tex2D(DepthSampler, NoMipMapPointClamp, ssUv).r;
		viewSpaceZ = CalcViewZFromDeviceZ(depth);
	}

	float3 worldPos = GetWorldPosFromViewZ(ssUv, viewSpaceZ);
	float3 viewDir = normalize(worldPos - cameraPos);
	float3 viewPoint = cameraPos + viewDir * fogStartDistance;

	float surfacePointToWaterPlaneHeight = WaterHeight - worldPos.z;
	float viewPointToWaterPlaneHeight = WaterHeight - viewPoint.z;
	
	// for lake
#if !OCEAN
	if (surfacePointToWaterPlaneHeight < 0)	
	{
		viewSpaceZ = (WaterHeight - cameraPos.z) / viewDir.z;
	}
#endif

	float distance = clamp(viewSpaceZ - fogStartDistance, 0, viewSpaceZ);
	float3 attenuation = saturate(exp(-float3(surfacePointToWaterPlaneHeight * LightAttenuationHight, viewPointToWaterPlaneHeight * LightAttenuationHight, distance * FogDensity)));

	float3 finalColor = tex2D(SrcSampler, NoMipMapPointClamp, ssUv);
	finalColor *= saturate(attenuation.x + IndoorLight.x * (1 - saturate(distance * IndoorLight.y)));

#if CAUSTIC
	float heightFade = saturate((surfacePointToWaterPlaneHeight - 50) * 0.01);
	if (depth < 0.9999 && heightFade > 0)
	{	
		float4 caustic_pos = mul(float4(worldPos.xyz, 1.0f), WorldToLight);
		float2 causticUv = caustic_pos.xy / caustic_pos.w;
		causticUv *= CausticSize;
		float4 color = tex2D(CausticTex, MipMapLinear, causticUv) * UnderwaterCausticIntensity;
		finalColor = finalColor + finalColor * color.r * 4 * heightFade;
	}
#endif
	// fog
	float angle = -dot(RefractSunOrMoonDir, viewDir);
	float g = 0.9 - 0.9 * attenuation.y;
	float phase = MiePhase(angle, g);
	{
  		float3 fogColor = phase * UnderWaterFogColor * attenuation.y;
  		finalColor = lerp(fogColor, finalColor, attenuation.z);
	}
#if GODRAY
	{
		float3 shafts = tex2D(GodRayTex, NoMipMapLinearClamp, refractUv);  
		float fade = cos(saturate(-GetCamDir().z)* PI) + 1;
		finalColor += shafts * phase * fade * (1 - attenuation.z);
	}
#endif
	return finalColor;
}

#endif //QSUnderWater_H
