#ifndef QSSHADER_AtmosphereUtil_H
#define QSSHADER_AtmosphereUtil_H
#include "DX12Defines.fxh"
#include "Atmosphere.fxh"

const float EarthScale = 0.00001f;  // ��Ϸ��1��λ����ɹ���

float Brightness;
float3 SunDir;

float4 CamPosRCamera;
#define CamPos			 (CamPosRCamera.xyz)
#define RCamera			 (CamPosRCamera.w)
float MusCamera;

////////////////////////////////////////////////////////////////////////////

float GetMu(float3 viewDir) 
{ 
    return dot(CamPos, viewDir) / RCamera;	// cos����ʼ�㴦�Ϸ������ӷ���нǣ�
}

float GetNu(float3 viewDir) 
{ 
	return dot(viewDir, -SunDir);	// cos���ӷ��������ⷽ��нǣ�
} 

////////////////////////////////////////////////////////////////////////////
// ת��������������ϵ

float3 ConvertEarthCoord(float3 pos) 
{ 
	pos.z = max(pos.z, 100);
	pos *= EarthScale;
	pos.z += Rg;
	return pos;
}

////////////////////////////////////////////////////////////////////////////

float PhaseFunctionM(float mu, float mieG) 
{
    return 1.5 * 1.0 / (4.0 * PI) * (1.0 - mieG*mieG) * pow(1.0 + (mieG*mieG) - 2.0*mieG*mu, -3.0/2.0) * (1.0 + mu * mu) / (2.0 + mieG*mieG);
}

////////////////////////////////////////////////////////////////////////////

float3 ConvertInscatteredLight(float4 inscatter, float nu, float mieG) 
{ 
    float phaseR = PhaseFunctionR(nu); 
    float phaseM = PhaseFunctionM(nu, mieG); 
    float3 inscatteredLight = (inscatter.rgb * phaseR + GetMie(inscatter)* phaseM); 
    return inscatteredLight * Brightness; 
}

////////////////////////////////////////////////////////////////////////////
// �õ������ɫ

float3 GetSkyColor(float3 viewDir, float mieG) 
{ 
    const float r = /*RCamera*/6360.01f; 
    const float mu = GetMu(viewDir);
    const float mus = MusCamera; 
    const float nu = GetNu(viewDir);  
        
//         float minAngle = -sqrt(1.0 - (Rg * Rg)/(r * r));
//         if (mu < minAngle)
//         {
//             mu = minAngle;
//         }
    
    float4 inscatter = Texture4D(InscatterMap, NoMipMapLinearClamp, r, mu, mus, nu); 			
    float3 scatterColor = ConvertInscatteredLight(inscatter, nu, mieG);
    return scatterColor;
}


#endif //QSSHADER_AtmosphereUtil_H