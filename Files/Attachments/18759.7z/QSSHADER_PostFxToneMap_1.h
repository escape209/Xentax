#ifndef QSSHADER_PostFxToneMap_H
#define QSSHADER_PostFxToneMap_H

//check qsengine's wiki for details and deprecated code
#include "DX12Defines.fxh"
//tonemap pass common param
#if POSTFX_BLOOM_ENABLE
Texture2D BloomSampler;
#endif

#if POSTFX_DOF_ENABLE
Texture2D DOFSampler;
#endif

float4 bloomScale;                       //x:bloom scale, y:exposure divider, zw:half pixel bias param

#if POSTFX_GODRAY_ENABLE || POSTFX_GODRAYMASK || POSTFX_LIGHTSHAFT_BLUR

Texture2D LightShaftSampler;

float4 LightShaftParameters;
//Parameter for Light Shaft
float2 TextureSpaceBlurOrigin;
float4 AspectRatioAndInvAspectRatio;
float BloomBlendThreshold;
/** 1.0f / OcclusionDepthRange in x, BloomScale in y, RadialBlurPercent / 100 in z, OcclusionMaskDarkness in w. */
float  LightShaftIntensity;
/** Tint in rgb, threshold in a. */
float4 BloomTintAndThreshold;

float4 ApplyLightShaft( float2 tex, float4 sceneColor )
{
	float4 outColor;
	float2 InSourceUV = tex;
	
	half4 LightShaftColorAndMask = LightShaftSampler.Sample(MipMapLinearClamp, InSourceUV);
	
	// Expand from the [0, 1] range stored by the radial blur step
	LightShaftColorAndMask.rgb *= MAX_SCENE_COLOR;

	// LightShaftParameters.w is OcclusionMaskDarkness, use that to control what an occlusion value of 0 maps to
	// Lerp an occlusion value of 1 to a multiplier greater than one to balance out the brightness of the scene
	float SceneColorMultiplier = lerp(LightShaftParameters.w, 1.5 - .5f * LightShaftParameters.w, LightShaftColorAndMask.w * LightShaftColorAndMask.w);
	// Setup a mask based on where the blur origin is
	float BlurOriginDistanceMask = saturate(length(TextureSpaceBlurOrigin.xy - InSourceUV * AspectRatioAndInvAspectRatio.zw) * 0.5f);
	// Fade out occlusion over distance away from the blur origin
	SceneColorMultiplier = lerp(SceneColorMultiplier, 1, BlurOriginDistanceMask);
	// Fade to no darkening based on distance from the light for point lights
	//SceneColorMultiplier = lerp(SceneColorMultiplier, 1, DistanceFade * DistanceFade * DistanceFade);

	half Luminance = dot(sceneColor, half3(.3f, .59f, .11f));
	// Use an exponential function that converges on 0 slowly
	// This minimizes the halo created by the screen blend when the source image is a bright gradient
	half BloomScreenBlendFactor = saturate(BloomBlendThreshold * exp2(-3 * Luminance));
	SceneColorMultiplier = lerp(1.0f,SceneColorMultiplier,LightShaftIntensity);

	// Use a screen blend to apply bloom to scene color, darken scene color by the occlusion factor
	outColor = half4(sceneColor* SceneColorMultiplier + LightShaftColorAndMask.rgb * BloomTintAndThreshold.rgb * BloomScreenBlendFactor,0.0);

	return outColor;
}
#endif

#if TONE_MAP||POSTFX_HDR_FINAL
float4 HdrFinalParam0;//x:shoulderStrength, y:linearStrength, z:linearAngle, w:toeStrength
float4 HdrFinalParam1;//y : color scale w:exposure
#define GammaScale (HdrFinalParam1.y)

#endif

#if TONE_MAP
struct ToneMapVsOut
{
    float4 pos:SV_Position;
    float3 tex:TEXCOORD0; //xy for pp
#if POSTFX_BLOOM_ENABLE || (POSTFX_DOF_ENABLE && POSTFX_DOF_HALF_DEPTH)	
	float4 bloomAndDofUv:TEXCOORD1;
#endif//POSTFX_BLOOM_ENABLE || (POSTFX_DOF_ENABLE && POSTFX_DOF_HALF_DEPTH)	
#if USE_VIGNETTE
    float2 vignetteUv:TEXCOORD2;
#endif
#if USE_GRAIN_JITTER || USE_GRAIN_INTENSITY || USE_GRAIN_QUANTIZATION
    float4 grainUv:TEXCOORD3;
#endif
#if USE_COLOR_FRINGE
    float2 screenPos:TEXCOORD4;
#endif
};
#endif//TONE_MAP

//==============util functions=============================================
float3 ACESToneMapApproximate(float3 x, float4 param0, float param1)
{
    const float a = param0.x; //2.51
	const float b = param0.y; //0.03
	const float c = param0.z; //2.43
	const float d = param0.w; //0.59
	const float e = param1; //0.14
    return saturate((x * (a * x + b)) / (x * (c * x + d) + e));
}

//tone map operator with default param
float3 ACESToneMapApproximate(float3 x)
{
	const float a = 2.51;
	const float b = 0.03;
	const float c = 2.43;
	const float d = 0.59;
	const float e = 0.14;

    return ACESToneMapApproximate(x, float4(a,b,c,d), e);
}

#endif //QSSHADER_PostFxToneMap_H