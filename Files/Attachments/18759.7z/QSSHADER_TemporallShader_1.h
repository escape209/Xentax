#ifndef QSSHADER_TemporallShader_H
#define QSSHADER_TemporallShader_H

sampler2D HistorySampler;
sampler2D VelocitySampler;

#endif //QSSHADER_TemporallShader_H