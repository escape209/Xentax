#ifndef QSSHADER_QSConstant_H
#define QSSHADER_QSConstant_H

//float4x4 worldMatrix;
//float4x4 worldViewProj;     //it maybe a jittering matrix when TAA enabled
//float4x4 view;
//float4x4 invView;
//float4x4 PartialViewProj;
//float4x4 invPartialViewProj;
float3	 cameraPos;
#if FORWARD_LIGHTING || SCREEN_DOOR
float	 TransFactor;
#endif

#if WRITE_VELOCITY
float4x4 curWorldViewProj;
float4x4 preWorldViewProj;
float4x4 curPartialViewProj;
float4x4 prePartialViewProj;
#endif

#define PI						3.1415926f
#define InvPi					0.31830988614f
#define TwoPi					6.28312530f
#define InvTwoPi				0.15915646310f
#define HalfPi					1.5707963f
#define SSS_SCALE_FACTOR		4.0f
#define INV_SSS_SCALE_FACTOR	0.25f
#define DielectricSpec          float4(0.04f,0.04f,0.04f,0.96f)

#endif //QSSHADER_QSConstant_H
