#ifndef QSSHADER_FXPARTICLEEMIT_H
#define QSSHADER_FXPARTICLEEMIT_H

#include "FxParticle.h"

float4 EmitterDimensions;
float4 EmitterInfo;
sampler2D PosSampler;

//////////////////////////////////////////////////////////////
float3 EmitterSphere(float2 vPos)
{
	float r = EmitterDimensions.x;
#if !EMITTER_SURFACEONLY
    r = GetRandom12(0.0f, r, PSEUDO_RANDOM_2);
#endif

    float3 pos = GetRandom32(-1, 1, PSEUDO_RANDOM_1);
    pos = normalize(pos);
    pos *= r;
    return pos;
}
//////////////////////////////////////////////////////////////
float3 EmitterBox(float2 vPos)
{
	float3 pos;
    float3 random = GetRandom32(PSEUDO_RANDOM_1);

#if EMITTER_SURFACEONLY 
    float nAxis = GetRandom12(PSEUDO_RANDOM_2);
	if (nAxis < 0.3333)
	{
        pos.x = random.x < 0.5f? -EmitterDimensions.x : EmitterDimensions.x;
        pos.yz = random.yz * (EmitterDimensions.yz + EmitterDimensions.yz) - EmitterDimensions.yz;
	}
	else if (nAxis < 0.6666)
	{
        pos.y = random.y < 0.5f? -EmitterDimensions.y : EmitterDimensions.y;
        pos.xz = random.xz * (EmitterDimensions.xz + EmitterDimensions.xz) - EmitterDimensions.xz;
	}
	else
	{
	    pos.xy = random.xy * (EmitterDimensions.xy + EmitterDimensions.xy) - EmitterDimensions.xy;
        pos.z = random.z < 0.5f? -EmitterDimensions.z : EmitterDimensions.z;
	}
#else
    pos.xyz = random * (EmitterDimensions.xyz + EmitterDimensions.xyz) - EmitterDimensions.xyz;
#endif
	return pos;
}
//////////////////////////////////////////////////////////////
float3 EmitterCylinder(float2 vPos)
{
	float radius = EmitterDimensions.x;
	const float height = EmitterDimensions.y;
	const float sweepAngleX = EmitterDimensions.z;
	const float sweepAngleY = EmitterDimensions.w;

#if !EMITTER_SURFACEONLY
	radius = GetRandom12(0.0f, radius, PSEUDO_RANDOM_2);
#endif

    // Generate a particle within a cylinder
    float2 random = GetRandom22(PSEUDO_RANDOM_1);
    float rotation = random.x * (sweepAngleY - sweepAngleX) + sweepAngleX;
        
    float3 pos;
    pos.x = sin(rotation) * radius;
    pos.y = random.y * (height + height) - height;
    pos.z = cos(rotation) * radius;
	return pos;
}
//////////////////////////////////////////////////////////////
float3 EmitterLine(float2 vPos)
{
	const float emitPosCount = EmitterDimensions.w;
    float3 vFixedLineStartOffset = -EmitterDimensions.xyz * 0.5f;
    float3 vFixedLineAxisSegment = EmitterDimensions.xyz * (1 /emitPosCount);
    return vFixedLineStartOffset + vFixedLineAxisSegment * ceil(GetRandom12(0, emitPosCount-0.000001f, PSEUDO_RANDOM_1));
}
//////////////////////////////////////////////////////////////
float3 EmitterCircle(float2 vPos)
{
	const float3 upAxis = EmitterInfo.xyz;
	const float fSegment = EmitterInfo.w;
    const float3 beginPos = EmitterDimensions.xyz;
	const float emitPosCount = EmitterDimensions.w;
	const float currentEmitPosIndex = ceil(GetRandom12(0, emitPosCount-0.000001f, PSEUDO_RANDOM_1));

    float3x3 rotation;
    SetRotate(rotation, upAxis, fSegment * currentEmitPosIndex);

	return mul(beginPos, rotation);
}
//////////////////////////////////////////////////////////////
// xyz:pos, w:beginTimeMask
float4 EmitterTexture(out float order, float2 vPos, float2 random)
{
    int maxPixelCount = EmitterInfo.z;
    int width = EmitterInfo.x;
    int height = EmitterInfo.y;

#if POS_RANDOM
	order = GetRandom12(PSEUDO_RANDOM_8 + random);
#else
	order = ((vPos.y * 1024 + vPos.x - ParticleSystemBeginIndex) / ParticleSystemMaxCount);   
#endif
	int index = order * maxPixelCount;
    float2 uv;
    uv.x = ((index % width) + 0.5f) * float(1.0/width);
    uv.y = ((index / width) + 0.5f) * float(1.0/height);

 	float4 color = tex2D(PosSampler, uv);
	color.xyz -= 0.5f;

#if POS_OFFSET
	color.xyz += GetRandom32(-EmitterDimensions.w, EmitterDimensions.w, PSEUDO_RANDOM_1 + random);
#endif

 	return float4(color.xyz * EmitterDimensions.xyz, color.a);
}

#endif//QSSHADER_FXPARTICLEEMIT_H