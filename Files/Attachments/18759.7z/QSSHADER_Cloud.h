#ifndef QSSHADER_Cloud_H
#define QSSHADER_Cloud_H
#include "DX12Defines.fxh"
#include "QSConstant.fxh"
#include "QSShaderAtmosphere.fxh"

sampler2D	Cloud0Map0;
sampler2D	Cloud0Map1;
sampler2D	Cloud0Map2;
sampler2D	Cloud1Map0;
sampler2D	Cloud1Map1;
sampler2D	Cloud1Map2;

float4		CloudCtrl;			
float3      CloudLightColor;
float4		CloudLighteness;    
float2      CloudTransform;     // offset
float3      HaloCtrl;           // x:1/Radius�� y:Intensity, z:power
float3		HaloColor;

sampler2D	LightningCloud_0Sampler;
sampler2D	LightningCloud_1Sampler;
sampler2D	LightningCloud_2Sampler;
float4		LightningPos[3];        // xyz:pos, w:Intensity
float3		LightningBright;
float3		LightningColor;
float		CloudStepSize;		// ��������������0.004[0,1]
float3		Cloud0LayerRatio;
float3		Cloud1LayerRatio;

#define Cloud0Intensity		CloudCtrl.x
#define Cloud1Intensity		CloudCtrl.y
#define Cloud0Saturation	CloudCtrl.z
#define Cloud1Saturation	CloudCtrl.w

#define CloudBright			CloudLighteness.x
#define CloudDark			CloudLighteness.y
#define Cloud0Alpha			CloudLighteness.z
#define Cloud0Attenuation	CloudLighteness.w		// ����͸���ƵĹ�ǿ˥��,ֵԽ���Ƶ���ӰԽ��1.0[0,5]

struct VSIn
{
    float3 pos		: POSITION;   
    float2 tex		: TEXCOORD0;

#if (CLOUD0_LIGHTING)
    float3 tangent	: TANGENT;
    float3 binormal	: BINORMAL;
#endif

};

struct VSCloudOut
{
    float4 cloudTex		: TEXCOORD5;
#if CLOUD0_LIGHTING
    #if DOUBLE_LIGHTING
        float4 toLight		: TEXCOORD6;
    #else
        float2 toLight		: TEXCOORD6;
    #endif  
#endif

#if LIGHTNING1
    float2 toLightning1_2   : TEXCOORD7;
#elif LIGHTNING2
    float4 toLightning1_2   : TEXCOORD7;
#elif LIGHTNING3
    float4 toLightning1_2   : TEXCOORD7;
    float2 toLightning3     : TEXCOORD8;
#endif
};


void CloudVS(in VSIn param, out VSCloudOut result)
{
    result.cloudTex.y = param.tex.y;
    result.cloudTex.x = (param.tex.x + CloudTransform.x) * 2;

    result.cloudTex.w = param.tex.y;
    result.cloudTex.z = (param.tex.x + CloudTransform.y) * 2;

#if CLOUD0_LIGHTING
    float3x3 objToTangentSpace;
    objToTangentSpace[0] = param.tangent;
    objToTangentSpace[1] = param.binormal;
    objToTangentSpace[2] = param.pos.xyz;

    result.toLight.xy = mul(objToTangentSpace, LightDir).xy; 
    result.toLight.x = -result.toLight.x;

    #if DOUBLE_LIGHTING
        result.toLight.zw = mul(objToTangentSpace, LightDirSecond).xy; 
        result.toLight.z = -result.toLight.z;
    #endif 

    #if LIGHTNING1 || LIGHTNING2 || LIGHTNING3
        result.toLightning1_2.xy = mul(objToTangentSpace, LightningPos[0].xyz).xy + 0.5f;
    #endif
    #if LIGHTNING2 || LIGHTNING3
        result.toLightning1_2.zw = mul(objToTangentSpace, LightningPos[1].xyz).xy + 0.5f;
    #endif
    #if LIGHTNING3
        result.toLightning3.xy = mul(objToTangentSpace, LightningPos[2].xyz).xy + 0.5f;
    #endif

#endif//CLOUD0_LIGHTING

}

////////////////////////////////////////////////////////////////////////////
// ��������ɫ

float4 GetCloud0Color(float2 uv, float2 lightDir, float stepSize)
{
#if CLOUD0_LAYER1
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
#elif CLOUD0_LAYER2
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud0Map1,NoMipMapLinearWrapU, uv);
#elif CLOUD0_LAYER3
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud0Map1,NoMipMapLinearWrapU, uv);
	float4 L2 = tex2D(Cloud0Map2,NoMipMapLinearWrapU, uv);
#endif


	float2 sampleDir = lightDir * stepSize;
	const int c_numSamples = 8;
	for( int i = 1; i < c_numSamples; ++i )
	{
		float2 uvs = uv + i * sampleDir;

#if CLOUD0_LAYER1
		L0.r += tex2D(Cloud0Map0,NoMipMapLinearWrapU, uvs).r;
#elif CLOUD0_LAYER2
		L0.r += tex2D(Cloud0Map0,NoMipMapLinearWrapU, uvs).r;
		L1.r += tex2D(Cloud0Map1,NoMipMapLinearWrapU, uvs).r;
#elif CLOUD0_LAYER3
		L0.r += tex2D(Cloud0Map0,NoMipMapLinearWrapU, uvs).r;
		L1.r += tex2D(Cloud0Map1,NoMipMapLinearWrapU, uvs).r;
		L2.r += tex2D(Cloud0Map2,NoMipMapLinearWrapU, uvs).r;
#endif
	}

#if CLOUD0_LAYER1
	return L0;
#elif CLOUD0_LAYER2
	return lerp(L0, L1, Cloud0LayerRatio.g);
#elif CLOUD0_LAYER3
	return lerp(lerp(L0, L1, Cloud0LayerRatio.g), L2, Cloud0LayerRatio.b);
#else
	return 0;
#endif
}

float4 GetCloud0Color(float2 uv)
{
#if CLOUD0_LAYER1
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
	return L0;
#elif CLOUD0_LAYER2
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud0Map1,NoMipMapLinearWrapU, uv);
	return lerp(L0, L1, Cloud0LayerRatio.g);
#elif CLOUD0_LAYER3
	float4 L0 = tex2D(Cloud0Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud0Map1,NoMipMapLinearWrapU, uv);
	float4 L2 = tex2D(Cloud0Map2,NoMipMapLinearWrapU, uv);
	return lerp(lerp(L0, L1, Cloud0LayerRatio.g), L2, Cloud0LayerRatio.b);
#else
	return 0;
#endif
}

float4 GetCloud1Color(float2 uv)
{
#if CLOUD1_LAYER1
	float4 L0 = tex2D(Cloud1Map0,NoMipMapLinearWrapU, uv);
	return L0;
#elif CLOUD1_LAYER2
	float4 L0 = tex2D(Cloud1Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud1Map1,NoMipMapLinearWrapU, uv);
	return lerp(L0, L1, Cloud1LayerRatio.g);
#elif CLOUD1_LAYER3
	float4 L0 = tex2D(Cloud1Map0,NoMipMapLinearWrapU, uv);
	float4 L1 = tex2D(Cloud1Map1,NoMipMapLinearWrapU, uv);
	float4 L2 = tex2D(Cloud1Map2,NoMipMapLinearWrapU, uv);
	return lerp(lerp(L0, L1, Cloud1LayerRatio.g), L2, Cloud1LayerRatio.b);
#else
	return 0;
#endif
}

////////////////////////////////////////////////////////////////////////////
// ������������ɫ
#if LIGHTNING1 || LIGHTNING2 || LIGHTNING3

float2 GetLightningBright(in VSCloudOut param)
{
    float2 result;
    {
        float4 c = tex2D(LightningCloud_0Sampler,MipMapLinearBorder, param.toLightning1_2.xy).r * LightningPos[0].w;
        result.x = c.r;
        result.y = c.a * LightningBright.x;         
    }

#if LIGHTNING2 || LIGHTNING3
    {
        float4 c = tex2D(LightningCloud_1Sampler,MipMapLinearBorder, param.toLightning1_2.zw).r * LightningPos[1].w;
        result.x += c.r;
        result.y += c.a * LightningBright.y;   
    }
#endif

#if LIGHTNING3
    {
        float4 c = tex2D(LightningCloud_2Sampler,MipMapLinearBorder, param.toLightning3.xy).r * LightningPos[2].w;
        result.x += c.r;
        result.y += c.a * LightningBright.z;   
    }
#endif
    return result;
}

#endif

////////////////////////////////////////////////////////////////////
// return cloudMask
float CloudPS(inout float3 skyColor, in VSCloudOut param, in float3 viewDir)
{
    float cloudMask = 0;
    float3 sunLight = CloudLightColor * (1.0 + dot(viewDir, -LightDir));

#if CLOUD0_LIGHTING

    float2 toLight= clamp(param.toLight.xy, -0.15f, 0.15f);
    float4 clouds0 = GetCloud0Color(param.cloudTex.xy, toLight, CloudStepSize);
    cloudMask = clouds0.a;
    clouds0.a = clouds0.g;

    float3 darkCol = skyColor * CloudDark;
    float3 brightCol = 0.1 + sunLight * CloudBright;
    {
        float toLightLength = saturate(1- length(param.toLight.xy) * HaloCtrl.x);
        float haloBright = pow(toLightLength, HaloCtrl.z);
#if DOUBLE_LIGHTING
        toLightLength = saturate(1- length(param.toLight.zw) * HaloCtrl.x);
        haloBright += pow(toLightLength, HaloCtrl.z);
#endif
		skyColor = skyColor + (haloBright * saturate(viewDir.z * 4)) * HaloColor;
        brightCol *= (1 + haloBright * HaloCtrl.y);		
    }

#if LIGHTNING1 || LIGHTNING2 || LIGHTNING3

    float2 lightningBright = GetLightningBright(param);
    clouds0.r *= 1 - lightningBright.x;
    brightCol += lightningBright.y * LightningColor;

#endif

    clouds0.r = exp2(-Cloud0Attenuation * clouds0.r);
    clouds0.rgb = lerp(darkCol, brightCol, clouds0.r);
#else
    float4 clouds0 = GetCloud0Color(param.cloudTex.xy);
    cloudMask = clouds0.a;
    clouds0.a = clouds0.r;
	float3 generalCloudCol = 0.01 + sunLight * CloudDark;
    clouds0.rgb = generalCloudCol * Cloud0Intensity;

#endif //CLOUD0_LIGHTING
    float4 clouds1 = GetCloud1Color(param.cloudTex.zw);

    clouds0.a = clouds0.a == 0 ? 0 : pow(clouds0.a, Cloud0Saturation) * Cloud0Alpha;
    clouds1.r = clouds1.r == 0 ? 0 : pow(clouds1.r, Cloud1Saturation);

    skyColor += clouds1.r * Cloud1Intensity * sunLight;
    skyColor = lerp(skyColor, clouds0.rgb, clouds0.a);
    return cloudMask;
}

#endif //QSSHADER_Cloud_H
