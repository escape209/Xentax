#ifndef QSSHADER_DepthUtil_H
#define QSSHADER_DepthUtil_H

float4 EncodeFloatToRGBA8(float v)
{
	float topValue = ((255.0f*256.0f+255.0f)*256.0f+255.0f)*256.0f+255.0f;
	v *= topValue;

	float d = fmod(v,256.0f);
	v-=d;
	v/=256.0f;

	float c = fmod(v,256.0f);
	v-=c;
	v/=256.0f;

	float b = fmod(v,256.0f);
	v-=b;
	v/=256.0f;

	float a = v;
	
	return float4(b,c,d,a)/255.0f;
}

float DecodeRgba8ToFloat(float4 v)
{
	float4 srcFactor = float4(256*256, 256, 1, 256*256*256);
	float multiplier = 1.0f/(1.0f+256.0f+256*256+256*256*256);

	return dot(v, srcFactor)*multiplier;
}

float3 EncodeFloatToRGB8(float v)
{
	float topValue = (255.0f*256.0f+255.0f)*256.0f+255.0f;
	v *= topValue;

	float c = fmod(v,256.0f);
	v-=c;
	v/=256.0f;

	float b = fmod(v,256.0f);
	v-=b;
	v/=256.0f;

	float a = v;

	return float3(c,b,a)/255.0f;
}

float DecodeRgb8IntoFloat(float3 v)
{
	float3 srcFactor = float3(1.0f,256.0f,256.0f*256.0f);
	float multiplier = 1.0f/(1.0f+256.0f+256.0f*256.0f);
	return dot(v,srcFactor)*multiplier;
}

float ShaderDepthBias(float z)
{
	float result = z+0.000003f;
	result += fwidth(z)*1.5f; 
	return result;
}

float ShaderDepthBias(float z, float depthBias, float slopeBias)
{
	float result = z+depthBias;
	result += fwidth(z)*slopeBias; 
	return result;
}

#define SHADOW_ENCODING_4 2

void DepthEncoding(float depth, out float4 color)
{
#if SHADOW_ENCODING_4==0	//use 4 channel
	color = EncodeFloatToRGBA8(depth);
#elif SHADOW_ENCODING_4==1  //use 3 channel
	color.xyz = EncodeFloatToRGB8(depth);
	color.w = 1.0f;
#elif SHADOW_ENCODING_4==2 //use 1 channel
	color = depth;
#endif
}

void ShadowDecoding(out float depth, float4 color)
{
#if SHADOW_ENCODING_4==0	//use 4 channel
	depth = DecodeRgba8ToFloat(color);
#elif SHADOW_ENCODING_4==1  //use 3 channel
	depth = DecodeRgb8IntoFloat(color);
#elif SHADOW_ENCODING_4==2 //use 1 channel
	depth = color.x;
#endif
}

void DepthEncodeToColor(float depth, out float4 color)
{
#if DEPTH_BIAS
	depth = ShaderDepthBias(depth);
#endif
	color = depth.xxxx;
}
#endif//QSSHADER_DepthUtil_H