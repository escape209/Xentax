
Ultimate Unwrap3D v3.50.14 Plugin
=================================

INSTALLATION
============
1. Place plugin file in the Ultimate Unwrap3D subdirectory called PLUGINS.
2. Restart or run Ultimate Unwrap3D.


NOTES
=====
Plugins are designed to provide greater interoperability between
different software packages.  In the case of game file formats,
these plugins are recommended for personal use only.


DISCLAIMER
==========
THIS PLUGIN IS UNSUPPORTED.
THE AUTHOR SHALL NOT BE HELD RESPONSIBLE FOR ANY DAMAGES, DIRECT
OR CONSEQUENTIAL, CAUSED BY THE PLUGIN.
BY DOWNLOADING, INSTALLING, OR USING THIS PLUGIN, YOU MUST AGREE
TO RESPECT AND PROTECT THE COPYRIGHTS OF COPYRIGHTED MATERIAL.
IF YOU DO NOT AGREE TO THESE TERMS, THEN YOU MUST DELETE THIS 
PLUGIN FROM YOUR COMPUTER.
USE AT YOUR OWN RISK.


IMPORTING
=========
The plugin can import meshSet files from the games:
Need For Speed The Run (2011)
Need For Speed Rivals (2013)
Need For Speed 2016

Geometry, materials, textures, UV coordinates, and multiple UVsets can be imported. 

Necessary files:
- meshSet = stores LOD, mesh, and bone information
- chunk   = stores vertex data (vertices, UVs)

NOTE: Mesh files are packed inside .CAS files. 

All necessary files must be extracted first before they can be imported.
THIS PLUGIN DOES NOT EXTRACT FILES.

Note that all textures must be located in the same directory as the meshSet file, 
otherwise they will not be found.


Chunk Directory
---------------
Set this to the directory where all the extracted chunks are located. 


Mesh Chunk
----------
If a meshSet file stores its vertex data externally, this will be the GUID of the 
chunk where it's stored.


Additional Meshes
-----------------
A single or multiple .meshSet files can be imported.


Car Script
----------
Custom .xml script to position wheels.  See included sample script for more information.


Scaling Options
---------------
Choose a scaling factor to scale the model.


TROUBLE-SHOOTING
================
Q: No mesh was imported.
A: See "Chunk Directory".  Make sure it is set correctly.


All trademarks and trade names are the property of their respective owners.
Copyright � 2016.  All Rights Reserved.


